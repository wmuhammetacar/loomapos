--
-- PostgreSQL database dump
--

\restrict 0MCQuMa9HPFSd3ZUHSe7fDt5B9RGCGlchRJ2OCVNkDZjLAsux8Kk7DvVd4PxMwa

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hangfire; Type: SCHEMA; Schema: -; Owner: loomapos
--

CREATE SCHEMA hangfire;


ALTER SCHEMA hangfire OWNER TO loomapos;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: aggregatedcounter; Type: TABLE; Schema: hangfire; Owner: loomapos
--

CREATE TABLE hangfire.aggregatedcounter (
    id bigint NOT NULL,
    key text NOT NULL,
    value bigint NOT NULL,
    expireat timestamp with time zone
);


ALTER TABLE hangfire.aggregatedcounter OWNER TO loomapos;

--
-- Name: aggregatedcounter_id_seq; Type: SEQUENCE; Schema: hangfire; Owner: loomapos
--

CREATE SEQUENCE hangfire.aggregatedcounter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hangfire.aggregatedcounter_id_seq OWNER TO loomapos;

--
-- Name: aggregatedcounter_id_seq; Type: SEQUENCE OWNED BY; Schema: hangfire; Owner: loomapos
--

ALTER SEQUENCE hangfire.aggregatedcounter_id_seq OWNED BY hangfire.aggregatedcounter.id;


--
-- Name: counter; Type: TABLE; Schema: hangfire; Owner: loomapos
--

CREATE TABLE hangfire.counter (
    id bigint NOT NULL,
    key text NOT NULL,
    value bigint NOT NULL,
    expireat timestamp with time zone
);


ALTER TABLE hangfire.counter OWNER TO loomapos;

--
-- Name: counter_id_seq; Type: SEQUENCE; Schema: hangfire; Owner: loomapos
--

CREATE SEQUENCE hangfire.counter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hangfire.counter_id_seq OWNER TO loomapos;

--
-- Name: counter_id_seq; Type: SEQUENCE OWNED BY; Schema: hangfire; Owner: loomapos
--

ALTER SEQUENCE hangfire.counter_id_seq OWNED BY hangfire.counter.id;


--
-- Name: hash; Type: TABLE; Schema: hangfire; Owner: loomapos
--

CREATE TABLE hangfire.hash (
    id bigint NOT NULL,
    key text NOT NULL,
    field text NOT NULL,
    value text,
    expireat timestamp with time zone,
    updatecount integer DEFAULT 0 NOT NULL
);


ALTER TABLE hangfire.hash OWNER TO loomapos;

--
-- Name: hash_id_seq; Type: SEQUENCE; Schema: hangfire; Owner: loomapos
--

CREATE SEQUENCE hangfire.hash_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hangfire.hash_id_seq OWNER TO loomapos;

--
-- Name: hash_id_seq; Type: SEQUENCE OWNED BY; Schema: hangfire; Owner: loomapos
--

ALTER SEQUENCE hangfire.hash_id_seq OWNED BY hangfire.hash.id;


--
-- Name: job; Type: TABLE; Schema: hangfire; Owner: loomapos
--

CREATE TABLE hangfire.job (
    id bigint NOT NULL,
    stateid bigint,
    statename text,
    invocationdata jsonb NOT NULL,
    arguments jsonb NOT NULL,
    createdat timestamp with time zone NOT NULL,
    expireat timestamp with time zone,
    updatecount integer DEFAULT 0 NOT NULL
);


ALTER TABLE hangfire.job OWNER TO loomapos;

--
-- Name: job_id_seq; Type: SEQUENCE; Schema: hangfire; Owner: loomapos
--

CREATE SEQUENCE hangfire.job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hangfire.job_id_seq OWNER TO loomapos;

--
-- Name: job_id_seq; Type: SEQUENCE OWNED BY; Schema: hangfire; Owner: loomapos
--

ALTER SEQUENCE hangfire.job_id_seq OWNED BY hangfire.job.id;


--
-- Name: jobparameter; Type: TABLE; Schema: hangfire; Owner: loomapos
--

CREATE TABLE hangfire.jobparameter (
    id bigint NOT NULL,
    jobid bigint NOT NULL,
    name text NOT NULL,
    value text,
    updatecount integer DEFAULT 0 NOT NULL
);


ALTER TABLE hangfire.jobparameter OWNER TO loomapos;

--
-- Name: jobparameter_id_seq; Type: SEQUENCE; Schema: hangfire; Owner: loomapos
--

CREATE SEQUENCE hangfire.jobparameter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hangfire.jobparameter_id_seq OWNER TO loomapos;

--
-- Name: jobparameter_id_seq; Type: SEQUENCE OWNED BY; Schema: hangfire; Owner: loomapos
--

ALTER SEQUENCE hangfire.jobparameter_id_seq OWNED BY hangfire.jobparameter.id;


--
-- Name: jobqueue; Type: TABLE; Schema: hangfire; Owner: loomapos
--

CREATE TABLE hangfire.jobqueue (
    id bigint NOT NULL,
    jobid bigint NOT NULL,
    queue text NOT NULL,
    fetchedat timestamp with time zone,
    updatecount integer DEFAULT 0 NOT NULL
);


ALTER TABLE hangfire.jobqueue OWNER TO loomapos;

--
-- Name: jobqueue_id_seq; Type: SEQUENCE; Schema: hangfire; Owner: loomapos
--

CREATE SEQUENCE hangfire.jobqueue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hangfire.jobqueue_id_seq OWNER TO loomapos;

--
-- Name: jobqueue_id_seq; Type: SEQUENCE OWNED BY; Schema: hangfire; Owner: loomapos
--

ALTER SEQUENCE hangfire.jobqueue_id_seq OWNED BY hangfire.jobqueue.id;


--
-- Name: list; Type: TABLE; Schema: hangfire; Owner: loomapos
--

CREATE TABLE hangfire.list (
    id bigint NOT NULL,
    key text NOT NULL,
    value text,
    expireat timestamp with time zone,
    updatecount integer DEFAULT 0 NOT NULL
);


ALTER TABLE hangfire.list OWNER TO loomapos;

--
-- Name: list_id_seq; Type: SEQUENCE; Schema: hangfire; Owner: loomapos
--

CREATE SEQUENCE hangfire.list_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hangfire.list_id_seq OWNER TO loomapos;

--
-- Name: list_id_seq; Type: SEQUENCE OWNED BY; Schema: hangfire; Owner: loomapos
--

ALTER SEQUENCE hangfire.list_id_seq OWNED BY hangfire.list.id;


--
-- Name: lock; Type: TABLE; Schema: hangfire; Owner: loomapos
--

CREATE TABLE hangfire.lock (
    resource text NOT NULL,
    updatecount integer DEFAULT 0 NOT NULL,
    acquired timestamp with time zone
);


ALTER TABLE hangfire.lock OWNER TO loomapos;

--
-- Name: schema; Type: TABLE; Schema: hangfire; Owner: loomapos
--

CREATE TABLE hangfire.schema (
    version integer NOT NULL
);


ALTER TABLE hangfire.schema OWNER TO loomapos;

--
-- Name: server; Type: TABLE; Schema: hangfire; Owner: loomapos
--

CREATE TABLE hangfire.server (
    id text NOT NULL,
    data jsonb,
    lastheartbeat timestamp with time zone NOT NULL,
    updatecount integer DEFAULT 0 NOT NULL
);


ALTER TABLE hangfire.server OWNER TO loomapos;

--
-- Name: set; Type: TABLE; Schema: hangfire; Owner: loomapos
--

CREATE TABLE hangfire.set (
    id bigint NOT NULL,
    key text NOT NULL,
    score double precision NOT NULL,
    value text NOT NULL,
    expireat timestamp with time zone,
    updatecount integer DEFAULT 0 NOT NULL
);


ALTER TABLE hangfire.set OWNER TO loomapos;

--
-- Name: set_id_seq; Type: SEQUENCE; Schema: hangfire; Owner: loomapos
--

CREATE SEQUENCE hangfire.set_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hangfire.set_id_seq OWNER TO loomapos;

--
-- Name: set_id_seq; Type: SEQUENCE OWNED BY; Schema: hangfire; Owner: loomapos
--

ALTER SEQUENCE hangfire.set_id_seq OWNED BY hangfire.set.id;


--
-- Name: state; Type: TABLE; Schema: hangfire; Owner: loomapos
--

CREATE TABLE hangfire.state (
    id bigint NOT NULL,
    jobid bigint NOT NULL,
    name text NOT NULL,
    reason text,
    createdat timestamp with time zone NOT NULL,
    data jsonb,
    updatecount integer DEFAULT 0 NOT NULL
);


ALTER TABLE hangfire.state OWNER TO loomapos;

--
-- Name: state_id_seq; Type: SEQUENCE; Schema: hangfire; Owner: loomapos
--

CREATE SEQUENCE hangfire.state_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE hangfire.state_id_seq OWNER TO loomapos;

--
-- Name: state_id_seq; Type: SEQUENCE OWNED BY; Schema: hangfire; Owner: loomapos
--

ALTER SEQUENCE hangfire.state_id_seq OWNED BY hangfire.state.id;


--
-- Name: __ef_migrations_history; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.__ef_migrations_history (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


ALTER TABLE public.__ef_migrations_history OWNER TO loomapos;

--
-- Name: abuse_flags; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.abuse_flags (
    id uuid NOT NULL,
    tenant_id uuid,
    flag_type character varying(80) NOT NULL,
    severity character varying(20) NOT NULL,
    summary character varying(300) NOT NULL,
    status character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.abuse_flags OWNER TO loomapos;

--
-- Name: accounting_export_items; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.accounting_export_items (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    source_type character varying(40) NOT NULL,
    source_id character varying(120) NOT NULL,
    event_code character varying(80) NOT NULL,
    payload_json text NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    exported_at timestamp with time zone,
    failure_reason character varying(600),
    CONSTRAINT ck_accounting_export_items_source_type CHECK (((source_type)::text = ANY ((ARRAY['sale'::character varying, 'sale_reversal'::character varying, 'cash_movement'::character varying, 'purchase_receipt'::character varying, 'customer_collection'::character varying, 'customer_account_adjustment'::character varying])::text[]))),
    CONSTRAINT ck_accounting_export_items_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'exported'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.accounting_export_items OWNER TO loomapos;

--
-- Name: activation_events; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.activation_events (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    device_activation_id uuid NOT NULL,
    event_type character varying(80) NOT NULL,
    payload_json text DEFAULT '{}'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.activation_events OWNER TO loomapos;

--
-- Name: admin_action_approvals; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.admin_action_approvals (
    id uuid NOT NULL,
    admin_action_request_id uuid NOT NULL,
    approved_by_internal_user_id uuid NOT NULL,
    decision character varying(30) NOT NULL,
    note character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_action_approvals OWNER TO loomapos;

--
-- Name: admin_action_requests; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.admin_action_requests (
    id uuid NOT NULL,
    requested_by_internal_user_id uuid NOT NULL,
    action_code character varying(120) NOT NULL,
    target_type character varying(80) NOT NULL,
    target_id character varying(120) NOT NULL,
    reason character varying(500) NOT NULL,
    status character varying(30) DEFAULT 'recorded'::character varying NOT NULL,
    requires_approval boolean DEFAULT false NOT NULL,
    metadata_json text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_action_requests OWNER TO loomapos;

--
-- Name: alert_events; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.alert_events (
    id uuid NOT NULL,
    alert_rule_id uuid,
    environment character varying(40) NOT NULL,
    severity character varying(20) NOT NULL,
    summary character varying(300) NOT NULL,
    status character varying(30) NOT NULL,
    triggered_at timestamp with time zone NOT NULL,
    acknowledged_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.alert_events OWNER TO loomapos;

--
-- Name: alert_rules; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.alert_rules (
    id uuid NOT NULL,
    environment character varying(40) NOT NULL,
    code character varying(120) NOT NULL,
    severity character varying(20) NOT NULL,
    threshold_summary character varying(300) NOT NULL,
    status character varying(30) NOT NULL,
    runbook_code character varying(120),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.alert_rules OWNER TO loomapos;

--
-- Name: analytics_report_schedules; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.analytics_report_schedules (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(180) NOT NULL,
    report_code character varying(80) NOT NULL,
    frequency character varying(30) NOT NULL,
    format character varying(20) NOT NULL,
    timezone character varying(80) NOT NULL,
    recipients_json text NOT NULL,
    filters_json text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_run_at timestamp with time zone,
    next_run_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.analytics_report_schedules OWNER TO loomapos;

--
-- Name: analytics_saved_views; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.analytics_saved_views (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    customer_account_id uuid,
    scope character varying(30) NOT NULL,
    name character varying(180) NOT NULL,
    view_code character varying(80) NOT NULL,
    filters_json text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.analytics_saved_views OWNER TO loomapos;

--
-- Name: app_releases; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.app_releases (
    id uuid NOT NULL,
    platform character varying(30) NOT NULL,
    channel character varying(30) DEFAULT 'stable'::character varying NOT NULL,
    version character varying(40) NOT NULL,
    release_date date NOT NULL,
    release_notes_markdown text NOT NULL,
    install_guide_markdown text NOT NULL,
    minimum_requirements text NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.app_releases OWNER TO loomapos;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.audit_logs (
    id bigint NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    action character varying(100) NOT NULL,
    entity character varying(100) NOT NULL,
    entity_id character varying(100) NOT NULL,
    payload_json text DEFAULT '{}'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO loomapos;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: loomapos
--

CREATE SEQUENCE public.audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO loomapos;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: loomapos
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: backup_runs; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.backup_runs (
    id uuid NOT NULL,
    environment character varying(40) NOT NULL,
    backup_type character varying(40) NOT NULL,
    status character varying(30) NOT NULL,
    region character varying(60) NOT NULL,
    retention_policy character varying(120) NOT NULL,
    artifact_reference character varying(240),
    started_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.backup_runs OWNER TO loomapos;

--
-- Name: bill_of_material_lines; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.bill_of_material_lines (
    id uuid NOT NULL,
    bom_id uuid NOT NULL,
    component_product_id uuid NOT NULL,
    quantity numeric(18,4) NOT NULL,
    CONSTRAINT ck_bom_line_quantity_positive CHECK ((quantity > (0)::numeric))
);


ALTER TABLE public.bill_of_material_lines OWNER TO loomapos;

--
-- Name: bill_of_materials; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.bill_of_materials (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    product_id uuid NOT NULL,
    code character varying(80),
    version integer NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_bom_version_positive CHECK ((version > 0))
);


ALTER TABLE public.bill_of_materials OWNER TO loomapos;

--
-- Name: billing_profiles; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.billing_profiles (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    customer_account_id uuid,
    company_name character varying(200) NOT NULL,
    billing_email character varying(320) NOT NULL,
    phone character varying(40),
    tax_office character varying(120),
    tax_number character varying(50),
    address_line character varying(500),
    city character varying(120),
    country character varying(8) DEFAULT 'TR'::character varying NOT NULL,
    locale character varying(20) DEFAULT 'tr-TR'::character varying NOT NULL,
    status character varying(30) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.billing_profiles OWNER TO loomapos;

--
-- Name: branches; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.branches (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    phone character varying(40),
    tax_number character varying(50),
    settings_json text
);


ALTER TABLE public.branches OWNER TO loomapos;

--
-- Name: capacity_snapshots; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.capacity_snapshots (
    id uuid NOT NULL,
    environment character varying(40) NOT NULL,
    resource_type character varying(60) NOT NULL,
    scope character varying(120) NOT NULL,
    utilization_summary character varying(300) NOT NULL,
    headroom_state character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.capacity_snapshots OWNER TO loomapos;

--
-- Name: cash_transactions; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.cash_transactions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    type character varying(20) NOT NULL,
    amount numeric(18,2) NOT NULL,
    reason character varying(150) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.cash_transactions OWNER TO loomapos;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.categories (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    parent_id uuid
);


ALTER TABLE public.categories OWNER TO loomapos;

--
-- Name: checkout_sessions; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.checkout_sessions (
    id uuid NOT NULL,
    tenant_id uuid,
    company_name character varying(200) NOT NULL,
    email character varying(320) NOT NULL,
    plan_code character varying(50) NOT NULL,
    billing_cycle character varying(20) NOT NULL,
    reseller_code character varying(50),
    amount numeric(18,2) NOT NULL,
    currency character varying(8) DEFAULT 'TRY'::character varying NOT NULL,
    status character varying(30) DEFAULT 'created'::character varying NOT NULL,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    customer_account_id uuid,
    subscription_id uuid,
    billing_profile_id uuid,
    license_id uuid,
    checkout_reference character varying(80) NOT NULL,
    contact_name character varying(200) NOT NULL,
    phone character varying(40),
    provider character varying(40) NOT NULL,
    provider_session_id character varying(150),
    provider_payment_reference character varying(150),
    coupon_code character varying(50),
    tax_amount numeric(18,2) DEFAULT 0 NOT NULL,
    payment_status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    checkout_payload_json text DEFAULT '{}'::text NOT NULL,
    billing_payload_json text DEFAULT '{}'::text NOT NULL,
    idempotency_key character varying(120),
    provisioned_at timestamp with time zone,
    error text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.checkout_sessions OWNER TO loomapos;

--
-- Name: commissions; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.commissions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    reseller_id uuid NOT NULL,
    subscription_id uuid NOT NULL,
    invoice_id uuid NOT NULL,
    rate numeric(8,4) NOT NULL,
    amount numeric(18,2) NOT NULL,
    status character varying(30) DEFAULT 'accrued'::character varying NOT NULL,
    accrued_at timestamp with time zone DEFAULT now() NOT NULL,
    paid_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.commissions OWNER TO loomapos;

--
-- Name: contact_ledger; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.contact_ledger (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    contact_id uuid NOT NULL,
    amount_delta numeric(18,2) NOT NULL,
    reason character varying(150) NOT NULL,
    ref_type character varying(100) NOT NULL,
    ref_id character varying(100) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.contact_ledger OWNER TO loomapos;

--
-- Name: contacts; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.contacts (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    type character varying(20) NOT NULL,
    name character varying(200) NOT NULL,
    phone character varying(40),
    email character varying(320),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.contacts OWNER TO loomapos;

--
-- Name: customer_account_entries; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.customer_account_entries (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    customer_id uuid NOT NULL,
    type character varying(40) NOT NULL,
    amount numeric(18,2) NOT NULL,
    ref_type character varying(100) NOT NULL,
    ref_id character varying(120) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    note character varying(500),
    CONSTRAINT ck_customer_account_entries_ref_id CHECK ((length(TRIM(BOTH FROM ref_id)) > 0)),
    CONSTRAINT ck_customer_account_entries_ref_type CHECK ((length(TRIM(BOTH FROM ref_type)) > 0)),
    CONSTRAINT ck_customer_account_entries_type CHECK (((type)::text = ANY ((ARRAY['sale_charge'::character varying, 'collection'::character varying, 'adjustment'::character varying, 'refund_credit'::character varying])::text[])))
);


ALTER TABLE public.customer_account_entries OWNER TO loomapos;

--
-- Name: customer_accounts; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.customer_accounts (
    id uuid NOT NULL,
    email character varying(320) NOT NULL,
    password_hash text NOT NULL,
    full_name character varying(200) NOT NULL,
    phone character varying(40),
    account_status character varying(30) DEFAULT 'active'::character varying NOT NULL,
    email_verified_at timestamp with time zone,
    last_login_at timestamp with time zone,
    password_reset_token_hash text,
    password_reset_expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    email_verification_token_hash text,
    email_verification_expires_at timestamp with time zone
);


ALTER TABLE public.customer_accounts OWNER TO loomapos;

--
-- Name: customer_current_accounts; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.customer_current_accounts (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    customer_id uuid NOT NULL,
    balance numeric(18,2) DEFAULT 0 NOT NULL,
    currency character varying(10) DEFAULT 'TRY'::character varying NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_customer_current_accounts_currency CHECK ((length(TRIM(BOTH FROM currency)) > 0))
);


ALTER TABLE public.customer_current_accounts OWNER TO loomapos;

--
-- Name: dependency_status_records; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.dependency_status_records (
    id uuid NOT NULL,
    environment character varying(40) NOT NULL,
    dependency_code character varying(80) NOT NULL,
    status character varying(30) NOT NULL,
    last_error_summary character varying(300),
    last_success_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dependency_status_records OWNER TO loomapos;

--
-- Name: deployment_records; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.deployment_records (
    id uuid NOT NULL,
    environment character varying(40) NOT NULL,
    service_name character varying(80) NOT NULL,
    version character varying(40) NOT NULL,
    commit_sha character varying(80) NOT NULL,
    status character varying(30) NOT NULL,
    release_channel character varying(30) NOT NULL,
    artifact_type character varying(30) NOT NULL,
    correlation_id character varying(120),
    metadata_json text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.deployment_records OWNER TO loomapos;

--
-- Name: device_activations; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.device_activations (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    device_id uuid NOT NULL,
    device_name character varying(150) NOT NULL,
    platform character varying(40) NOT NULL,
    app_version character varying(40),
    activation_source character varying(40) DEFAULT 'desktop'::character varying NOT NULL,
    activated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    license_id uuid,
    status character varying(30) DEFAULT 'active'::character varying NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.device_activations OWNER TO loomapos;

--
-- Name: devices; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.devices (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    name character varying(150) NOT NULL,
    type character varying(50) NOT NULL,
    last_seen_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.devices OWNER TO loomapos;

--
-- Name: download_accesses; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.download_accesses (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    downloadable_asset_id uuid NOT NULL,
    subscription_id uuid,
    license_id uuid,
    status character varying(30) DEFAULT 'active'::character varying NOT NULL,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.download_accesses OWNER TO loomapos;

--
-- Name: downloadable_assets; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.downloadable_assets (
    id uuid NOT NULL,
    app_release_id uuid NOT NULL,
    label character varying(150) NOT NULL,
    platform character varying(30) NOT NULL,
    visibility character varying(20) DEFAULT 'portal'::character varying NOT NULL,
    download_url character varying(500) NOT NULL,
    checksum character varying(128) NOT NULL,
    requires_active_license boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.downloadable_assets OWNER TO loomapos;

--
-- Name: email_notifications; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.email_notifications (
    id uuid NOT NULL,
    tenant_id uuid,
    customer_account_id uuid,
    event_code character varying(80) NOT NULL,
    to_email character varying(320) NOT NULL,
    subject character varying(200) NOT NULL,
    body_markdown text NOT NULL,
    status character varying(30) DEFAULT 'queued'::character varying NOT NULL,
    sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.email_notifications OWNER TO loomapos;

--
-- Name: environment_configs; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.environment_configs (
    id uuid NOT NULL,
    environment character varying(40) NOT NULL,
    config_key character varying(120) NOT NULL,
    value_kind character varying(30) NOT NULL,
    is_secret_reference boolean DEFAULT false NOT NULL,
    value_preview character varying(200),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.environment_configs OWNER TO loomapos;

--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.feature_flags (
    id uuid NOT NULL,
    code character varying(80) NOT NULL,
    name character varying(150) NOT NULL,
    description character varying(500) NOT NULL,
    is_public boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.feature_flags OWNER TO loomapos;

--
-- Name: incident_records; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.incident_records (
    id uuid NOT NULL,
    environment character varying(40) NOT NULL,
    severity character varying(20) NOT NULL,
    title character varying(180) NOT NULL,
    status character varying(30) NOT NULL,
    category character varying(60) NOT NULL,
    impact_summary character varying(600),
    owner character varying(120),
    linked_runbook_code character varying(120),
    opened_at timestamp with time zone NOT NULL,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.incident_records OWNER TO loomapos;

--
-- Name: incident_timeline_events; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.incident_timeline_events (
    id uuid NOT NULL,
    incident_record_id uuid NOT NULL,
    event_type character varying(60) NOT NULL,
    summary character varying(500) NOT NULL,
    metadata_json text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.incident_timeline_events OWNER TO loomapos;

--
-- Name: internal_sessions; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.internal_sessions (
    id uuid NOT NULL,
    internal_user_id uuid NOT NULL,
    access_token_hash character varying(128) NOT NULL,
    refresh_token_hash character varying(128) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    refresh_expires_at timestamp with time zone NOT NULL,
    user_agent character varying(400),
    ip_address character varying(120),
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.internal_sessions OWNER TO loomapos;

--
-- Name: internal_user_roles; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.internal_user_roles (
    id uuid NOT NULL,
    internal_user_id uuid NOT NULL,
    role_code character varying(80) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.internal_user_roles OWNER TO loomapos;

--
-- Name: internal_users; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.internal_users (
    id uuid NOT NULL,
    email character varying(320) NOT NULL,
    display_name character varying(200) NOT NULL,
    password_hash character varying(500) NOT NULL,
    status character varying(30) DEFAULT 'active'::character varying NOT NULL,
    require_mfa boolean DEFAULT false NOT NULL,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.internal_users OWNER TO loomapos;

--
-- Name: invoice_lines; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.invoice_lines (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    invoice_id uuid NOT NULL,
    description character varying(500) NOT NULL,
    quantity numeric(18,2) DEFAULT 1 NOT NULL,
    unit_amount numeric(18,2) DEFAULT 0 NOT NULL,
    tax_amount numeric(18,2) DEFAULT 0 NOT NULL,
    total_amount numeric(18,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.invoice_lines OWNER TO loomapos;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.invoices (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    subscription_id uuid NOT NULL,
    invoice_no character varying(80) NOT NULL,
    total numeric(18,2) NOT NULL,
    currency character varying(8) DEFAULT 'TRY'::character varying NOT NULL,
    status character varying(30) NOT NULL,
    issued_at timestamp with time zone NOT NULL,
    paid_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    billing_profile_id uuid,
    description character varying(500) NOT NULL,
    subtotal numeric(18,2) DEFAULT 0 NOT NULL,
    tax_amount numeric(18,2) DEFAULT 0 NOT NULL,
    due_at timestamp with time zone,
    billing_period_start timestamp with time zone,
    billing_period_end timestamp with time zone,
    provider_invoice_reference character varying(150),
    pdf_url character varying(500),
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.invoices OWNER TO loomapos;

--
-- Name: license_events; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.license_events (
    id bigint NOT NULL,
    tenant_id uuid NOT NULL,
    license_id uuid NOT NULL,
    event_type character varying(80) NOT NULL,
    payload_json text DEFAULT '{}'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.license_events OWNER TO loomapos;

--
-- Name: license_events_id_seq; Type: SEQUENCE; Schema: public; Owner: loomapos
--

CREATE SEQUENCE public.license_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.license_events_id_seq OWNER TO loomapos;

--
-- Name: license_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: loomapos
--

ALTER SEQUENCE public.license_events_id_seq OWNED BY public.license_events.id;


--
-- Name: licenses; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.licenses (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    subscription_id uuid NOT NULL,
    plan_code character varying(50) NOT NULL,
    license_token text NOT NULL,
    features_json text NOT NULL,
    device_limit integer,
    issued_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    grace_days integer DEFAULT 7 NOT NULL,
    status character varying(30) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    license_key character varying(120) NOT NULL,
    signature character varying(256) NOT NULL
);


ALTER TABLE public.licenses OWNER TO loomapos;

--
-- Name: migration_runs; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.migration_runs (
    id uuid NOT NULL,
    environment character varying(40) NOT NULL,
    migration_name character varying(180) NOT NULL,
    status character varying(30) NOT NULL,
    verification_summary character varying(500),
    started_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.migration_runs OWNER TO loomapos;

--
-- Name: ops_audit_logs; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.ops_audit_logs (
    id uuid NOT NULL,
    actor_email character varying(320) NOT NULL,
    action character varying(120) NOT NULL,
    target_type character varying(80) NOT NULL,
    target_id character varying(120) NOT NULL,
    reason character varying(500),
    metadata_json text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ops_audit_logs OWNER TO loomapos;

--
-- Name: payment_attempts; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.payment_attempts (
    id uuid NOT NULL,
    checkout_session_id uuid NOT NULL,
    payment_transaction_id uuid,
    provider character varying(40) NOT NULL,
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    failure_reason character varying(500),
    metadata_json text DEFAULT '{}'::text NOT NULL,
    attempted_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payment_attempts OWNER TO loomapos;

--
-- Name: payment_transactions; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.payment_transactions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    subscription_id uuid,
    invoice_id uuid,
    checkout_session_id uuid,
    provider character varying(40) NOT NULL,
    provider_payment_id character varying(150) NOT NULL,
    provider_customer_reference character varying(150),
    amount numeric(18,2) DEFAULT 0 NOT NULL,
    tax_amount numeric(18,2) DEFAULT 0 NOT NULL,
    currency character varying(8) DEFAULT 'TRY'::character varying NOT NULL,
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    payment_method_summary character varying(120) DEFAULT 'card'::character varying NOT NULL,
    metadata_json text DEFAULT '{}'::text NOT NULL,
    paid_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payment_transactions OWNER TO loomapos;

--
-- Name: payment_webhooks; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.payment_webhooks (
    id uuid NOT NULL,
    provider character varying(40) NOT NULL,
    event_id character varying(150) NOT NULL,
    payload_json text NOT NULL,
    status character varying(30) DEFAULT 'received'::character varying NOT NULL,
    error text,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    processed_at timestamp with time zone
);


ALTER TABLE public.payment_webhooks OWNER TO loomapos;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.payments (
    id uuid NOT NULL,
    sale_id uuid NOT NULL,
    method character varying(20) NOT NULL,
    amount numeric(18,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payments OWNER TO loomapos;

--
-- Name: payouts; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.payouts (
    id uuid NOT NULL,
    reseller_id uuid NOT NULL,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    total numeric(18,2) NOT NULL,
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    paid_at timestamp with time zone
);


ALTER TABLE public.payouts OWNER TO loomapos;

--
-- Name: plan_feature_flags; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.plan_feature_flags (
    id uuid NOT NULL,
    subscription_plan_id uuid NOT NULL,
    feature_flag_id uuid NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.plan_feature_flags OWNER TO loomapos;

--
-- Name: plan_prices; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.plan_prices (
    id uuid NOT NULL,
    subscription_plan_id uuid NOT NULL,
    billing_period character varying(20) NOT NULL,
    currency character varying(8) DEFAULT 'TRY'::character varying NOT NULL,
    amount numeric(18,2) NOT NULL,
    promo_amount numeric(18,2),
    external_price_id character varying(150),
    trial_days integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.plan_prices OWNER TO loomapos;

--
-- Name: plans; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.plans (
    id uuid NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(150) NOT NULL,
    monthly_price numeric(18,2) DEFAULT 0 NOT NULL,
    yearly_price numeric(18,2) DEFAULT 0 NOT NULL,
    max_branches integer,
    max_users integer,
    max_devices integer,
    features_json text DEFAULT '[]'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.plans OWNER TO loomapos;

--
-- Name: portal_sessions; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.portal_sessions (
    id uuid NOT NULL,
    customer_account_id uuid,
    reseller_account_id uuid,
    tenant_id uuid,
    portal_type character varying(30) NOT NULL,
    role_code character varying(50) NOT NULL,
    access_token_hash text NOT NULL,
    refresh_token_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    refresh_expires_at timestamp with time zone NOT NULL,
    user_agent character varying(500),
    ip_address character varying(80),
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.portal_sessions OWNER TO loomapos;

--
-- Name: processed_events; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.processed_events (
    event_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    device_id uuid NOT NULL,
    processed_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.processed_events OWNER TO loomapos;

--
-- Name: product_barcodes; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.product_barcodes (
    product_id uuid NOT NULL,
    barcode character varying(64) NOT NULL
);


ALTER TABLE public.product_barcodes OWNER TO loomapos;

--
-- Name: product_variants; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.product_variants (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    product_id uuid NOT NULL,
    name character varying(160) NOT NULL,
    sku character varying(100),
    barcode character varying(64),
    attributes_json text DEFAULT '{}'::text NOT NULL,
    price_delta numeric(18,2) DEFAULT 0 NOT NULL,
    stock_tracking_enabled boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.product_variants OWNER TO loomapos;

--
-- Name: production_orders; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.production_orders (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    bom_id uuid,
    finished_product_id uuid NOT NULL,
    planned_quantity numeric(18,4) NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_production_order_planned_quantity_positive CHECK ((planned_quantity > (0)::numeric)),
    CONSTRAINT ck_production_order_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'planned'::character varying, 'canceled'::character varying])::text[])))
);


ALTER TABLE public.production_orders OWNER TO loomapos;

--
-- Name: products; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.products (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    sku character varying(100),
    barcode character varying(64),
    unit character varying(20) NOT NULL,
    tax_rate numeric(18,4) DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    category_id uuid,
    sale_price numeric(18,2) DEFAULT 1 NOT NULL,
    purchase_price numeric(18,2) DEFAULT 0 NOT NULL,
    stock_tracking_enabled boolean DEFAULT true NOT NULL,
    min_stock numeric(18,4) DEFAULT 0 NOT NULL
);


ALTER TABLE public.products OWNER TO loomapos;

--
-- Name: purchase_order_lines; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.purchase_order_lines (
    id uuid NOT NULL,
    purchase_order_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity numeric(18,4) NOT NULL,
    unit_cost numeric(18,4) NOT NULL,
    CONSTRAINT ck_purchase_order_lines_qty CHECK ((quantity > (0)::numeric)),
    CONSTRAINT ck_purchase_order_lines_unit_cost CHECK ((unit_cost >= (0)::numeric))
);


ALTER TABLE public.purchase_order_lines OWNER TO loomapos;

--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.purchase_orders (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    supplier_id uuid NOT NULL,
    warehouse_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    received_at timestamp with time zone,
    CONSTRAINT ck_purchase_order_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'ordered'::character varying, 'received'::character varying, 'canceled'::character varying])::text[])))
);


ALTER TABLE public.purchase_orders OWNER TO loomapos;

--
-- Name: rate_limit_policies; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.rate_limit_policies (
    id uuid NOT NULL,
    policy_code character varying(120) NOT NULL,
    scope character varying(60) NOT NULL,
    target character varying(120) NOT NULL,
    limit_summary character varying(240) NOT NULL,
    status character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.rate_limit_policies OWNER TO loomapos;

--
-- Name: reseller_accounts; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.reseller_accounts (
    id uuid NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    email character varying(320) NOT NULL,
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    commission_rate numeric(8,4) DEFAULT 0.10 NOT NULL,
    approved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    company_name character varying(200),
    city character varying(120),
    phone character varying(40),
    website_or_social_proof character varying(500),
    experience text,
    message text,
    password_hash text,
    last_login_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reseller_accounts OWNER TO loomapos;

--
-- Name: reseller_codes; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.reseller_codes (
    id uuid NOT NULL,
    reseller_account_id uuid NOT NULL,
    code character varying(50) NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reseller_codes OWNER TO loomapos;

--
-- Name: reseller_commission_events; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.reseller_commission_events (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    reseller_account_id uuid NOT NULL,
    subscription_id uuid,
    invoice_id uuid,
    rate numeric(8,4) DEFAULT 0 NOT NULL,
    amount numeric(18,2) DEFAULT 0 NOT NULL,
    status character varying(30) DEFAULT 'accrued'::character varying NOT NULL,
    event_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reseller_commission_events OWNER TO loomapos;

--
-- Name: reseller_customer_links; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.reseller_customer_links (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    reseller_account_id uuid NOT NULL,
    customer_account_id uuid,
    subscription_id uuid,
    referral_code character varying(50) NOT NULL,
    linked_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reseller_customer_links OWNER TO loomapos;

--
-- Name: reseller_customers; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.reseller_customers (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    reseller_id uuid NOT NULL,
    referred_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reseller_customers OWNER TO loomapos;

--
-- Name: reseller_referrals; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.reseller_referrals (
    id uuid NOT NULL,
    reseller_account_id uuid NOT NULL,
    checkout_session_id uuid NOT NULL,
    tenant_id uuid,
    referral_code character varying(50) NOT NULL,
    status character varying(30) DEFAULT 'attached'::character varying NOT NULL,
    commission_eligible boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reseller_referrals OWNER TO loomapos;

--
-- Name: restore_validation_runs; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.restore_validation_runs (
    id uuid NOT NULL,
    backup_run_id uuid,
    environment character varying(40) NOT NULL,
    status character varying(30) NOT NULL,
    validation_type character varying(50) NOT NULL,
    findings_json text,
    started_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.restore_validation_runs OWNER TO loomapos;

--
-- Name: retention_policies; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.retention_policies (
    id uuid NOT NULL,
    policy_code character varying(120) NOT NULL,
    data_class character varying(80) NOT NULL,
    hot_retention character varying(80) NOT NULL,
    archive_retention character varying(80) NOT NULL,
    disposal_policy character varying(200) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.retention_policies OWNER TO loomapos;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.roles OWNER TO loomapos;

--
-- Name: rollout_records; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.rollout_records (
    id uuid NOT NULL,
    environment character varying(40) NOT NULL,
    channel character varying(30) NOT NULL,
    target_type character varying(40) NOT NULL,
    target_version character varying(40) NOT NULL,
    status character varying(30) NOT NULL,
    compatibility_window character varying(120),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.rollout_records OWNER TO loomapos;

--
-- Name: runbook_records; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.runbook_records (
    id uuid NOT NULL,
    code character varying(120) NOT NULL,
    title character varying(180) NOT NULL,
    category character varying(60) NOT NULL,
    severity character varying(20) NOT NULL,
    markdown_path character varying(260) NOT NULL,
    status character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.runbook_records OWNER TO loomapos;

--
-- Name: sale_lines; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.sale_lines (
    id uuid NOT NULL,
    sale_id uuid NOT NULL,
    product_id uuid NOT NULL,
    qty numeric(18,4) NOT NULL,
    unit_price numeric(18,2) NOT NULL,
    discount numeric(18,2) NOT NULL,
    tax numeric(18,2) NOT NULL,
    line_total numeric(18,2) NOT NULL
);


ALTER TABLE public.sale_lines OWNER TO loomapos;

--
-- Name: sales; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.sales (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    device_id uuid NOT NULL,
    receipt_no character varying(80) NOT NULL,
    status character varying(20) NOT NULL,
    subtotal numeric(18,2) NOT NULL,
    discount numeric(18,2) NOT NULL,
    tax numeric(18,2) NOT NULL,
    total numeric(18,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sales OWNER TO loomapos;

--
-- Name: secret_references; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.secret_references (
    id uuid NOT NULL,
    environment character varying(40) NOT NULL,
    secret_name character varying(120) NOT NULL,
    provider character varying(40) NOT NULL,
    rotation_policy character varying(80) NOT NULL,
    last_rotated_at timestamp with time zone,
    status character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.secret_references OWNER TO loomapos;

--
-- Name: security_events; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.security_events (
    id uuid NOT NULL,
    environment character varying(40) NOT NULL,
    event_type character varying(80) NOT NULL,
    severity character varying(20) NOT NULL,
    summary character varying(300) NOT NULL,
    status character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.security_events OWNER TO loomapos;

--
-- Name: service_versions; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.service_versions (
    id uuid NOT NULL,
    environment character varying(40) NOT NULL,
    service_name character varying(80) NOT NULL,
    version character varying(40) NOT NULL,
    minimum_supported_version character varying(40) NOT NULL,
    rollout_state character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.service_versions OWNER TO loomapos;

--
-- Name: slo_definitions; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.slo_definitions (
    id uuid NOT NULL,
    environment character varying(40) NOT NULL,
    service_name character varying(80) NOT NULL,
    slo_code character varying(120) NOT NULL,
    objective character varying(160) NOT NULL,
    measurement_window character varying(40) NOT NULL,
    alert_policy character varying(240) NOT NULL,
    status character varying(30) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.slo_definitions OWNER TO loomapos;

--
-- Name: stock_balances; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.stock_balances (
    tenant_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    product_id uuid NOT NULL,
    qty numeric(18,4) DEFAULT 0 NOT NULL
);


ALTER TABLE public.stock_balances OWNER TO loomapos;

--
-- Name: stock_by_warehouse; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.stock_by_warehouse (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    product_id uuid NOT NULL,
    warehouse_id uuid NOT NULL,
    quantity numeric(18,4) DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.stock_by_warehouse OWNER TO loomapos;

--
-- Name: stock_moves; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.stock_moves (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    product_id uuid NOT NULL,
    qty_delta numeric(18,4) NOT NULL,
    reason character varying(150) NOT NULL,
    ref_type character varying(100) NOT NULL,
    ref_id character varying(100) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    warehouse_id uuid
);


ALTER TABLE public.stock_moves OWNER TO loomapos;

--
-- Name: subscription_payments; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.subscription_payments (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    subscription_id uuid NOT NULL,
    invoice_id uuid NOT NULL,
    provider character varying(40) NOT NULL,
    payment_ref character varying(120) NOT NULL,
    status character varying(30) NOT NULL,
    amount numeric(18,2) NOT NULL,
    currency character varying(8) DEFAULT 'TRY'::character varying NOT NULL,
    paid_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscription_payments OWNER TO loomapos;

--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.subscription_plans (
    id uuid NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(150) NOT NULL,
    description character varying(500) NOT NULL,
    branch_limit integer,
    user_limit integer,
    device_limit integer,
    support_tier character varying(60) NOT NULL,
    reseller_commission_eligibility boolean DEFAULT false NOT NULL,
    is_public boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    highlight_label character varying(120) DEFAULT ''::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscription_plans OWNER TO loomapos;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.subscriptions (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    plan_code character varying(50) NOT NULL,
    billing_cycle character varying(20) NOT NULL,
    status character varying(30) NOT NULL,
    current_period_start timestamp with time zone NOT NULL,
    current_period_end timestamp with time zone NOT NULL,
    reseller_code character varying(50),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    billing_profile_id uuid,
    renewal_date timestamp with time zone,
    cancel_at_period_end boolean DEFAULT false NOT NULL,
    trial_ends_at timestamp with time zone,
    grace_ends_at timestamp with time zone,
    canceled_at timestamp with time zone,
    provider_subscription_id character varying(150),
    provider_customer_reference character varying(150),
    plan_snapshot_json text DEFAULT '{}'::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subscriptions OWNER TO loomapos;

--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.suppliers (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    tax_number character varying(50),
    phone character varying(40),
    email character varying(320),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.suppliers OWNER TO loomapos;

--
-- Name: support_access_sessions; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.support_access_sessions (
    id uuid NOT NULL,
    internal_user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    access_mode character varying(40) NOT NULL,
    reason character varying(500) NOT NULL,
    status character varying(30) DEFAULT 'active'::character varying NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    ended_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.support_access_sessions OWNER TO loomapos;

--
-- Name: support_case_links; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.support_case_links (
    id uuid NOT NULL,
    support_case_id uuid NOT NULL,
    entity_type character varying(80) NOT NULL,
    entity_id character varying(120) NOT NULL,
    label character varying(200),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.support_case_links OWNER TO loomapos;

--
-- Name: support_case_messages; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.support_case_messages (
    id uuid NOT NULL,
    support_case_id uuid NOT NULL,
    author_type character varying(40) NOT NULL,
    author_internal_user_id uuid,
    author_customer_account_id uuid,
    body character varying(8000) NOT NULL,
    is_internal boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.support_case_messages OWNER TO loomapos;

--
-- Name: support_case_notes; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.support_case_notes (
    id uuid NOT NULL,
    support_case_id uuid NOT NULL,
    internal_user_id uuid NOT NULL,
    note character varying(4000) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.support_case_notes OWNER TO loomapos;

--
-- Name: support_cases; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.support_cases (
    id uuid NOT NULL,
    tenant_id uuid,
    customer_account_id uuid,
    reseller_account_id uuid,
    source character varying(40) NOT NULL,
    category character varying(60) NOT NULL,
    priority character varying(30) NOT NULL,
    status character varying(40) NOT NULL,
    title character varying(260) NOT NULL,
    summary character varying(4000) NOT NULL,
    contact_preference character varying(60),
    assignee_email character varying(320),
    escalation_level character varying(40),
    first_response_at timestamp with time zone,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.support_cases OWNER TO loomapos;

--
-- Name: tenant_users; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.tenant_users (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    customer_account_id uuid NOT NULL,
    role_code character varying(50) NOT NULL,
    is_owner boolean DEFAULT false NOT NULL,
    status character varying(30) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tenant_users OWNER TO loomapos;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.tenants (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    settings_json text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    tenant_code character varying(80) NOT NULL,
    billing_email character varying(320) NOT NULL,
    tax_office character varying(120),
    tax_number character varying(50),
    country character varying(8) NOT NULL,
    default_locale character varying(20) NOT NULL,
    status character varying(30) NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tenants OWNER TO loomapos;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role_id uuid NOT NULL
);


ALTER TABLE public.user_roles OWNER TO loomapos;

--
-- Name: users; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    email character varying(320) NOT NULL,
    name character varying(200) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    branch_id uuid,
    phone character varying(40)
);


ALTER TABLE public.users OWNER TO loomapos;

--
-- Name: warehouse_transfer_lines; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.warehouse_transfer_lines (
    id uuid NOT NULL,
    transfer_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity numeric(18,4) NOT NULL,
    CONSTRAINT ck_warehouse_transfer_line_quantity CHECK ((quantity > (0)::numeric))
);


ALTER TABLE public.warehouse_transfer_lines OWNER TO loomapos;

--
-- Name: warehouse_transfers; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.warehouse_transfers (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    from_warehouse_id uuid NOT NULL,
    to_warehouse_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT ck_warehouse_transfer_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'in_transit'::character varying, 'completed'::character varying, 'canceled'::character varying])::text[]))),
    CONSTRAINT ck_warehouse_transfer_warehouses_distinct CHECK ((from_warehouse_id <> to_warehouse_id))
);


ALTER TABLE public.warehouse_transfers OWNER TO loomapos;

--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: loomapos
--

CREATE TABLE public.warehouses (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(150) NOT NULL,
    type character varying(30) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.warehouses OWNER TO loomapos;

--
-- Name: aggregatedcounter id; Type: DEFAULT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.aggregatedcounter ALTER COLUMN id SET DEFAULT nextval('hangfire.aggregatedcounter_id_seq'::regclass);


--
-- Name: counter id; Type: DEFAULT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.counter ALTER COLUMN id SET DEFAULT nextval('hangfire.counter_id_seq'::regclass);


--
-- Name: hash id; Type: DEFAULT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.hash ALTER COLUMN id SET DEFAULT nextval('hangfire.hash_id_seq'::regclass);


--
-- Name: job id; Type: DEFAULT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.job ALTER COLUMN id SET DEFAULT nextval('hangfire.job_id_seq'::regclass);


--
-- Name: jobparameter id; Type: DEFAULT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.jobparameter ALTER COLUMN id SET DEFAULT nextval('hangfire.jobparameter_id_seq'::regclass);


--
-- Name: jobqueue id; Type: DEFAULT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.jobqueue ALTER COLUMN id SET DEFAULT nextval('hangfire.jobqueue_id_seq'::regclass);


--
-- Name: list id; Type: DEFAULT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.list ALTER COLUMN id SET DEFAULT nextval('hangfire.list_id_seq'::regclass);


--
-- Name: set id; Type: DEFAULT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.set ALTER COLUMN id SET DEFAULT nextval('hangfire.set_id_seq'::regclass);


--
-- Name: state id; Type: DEFAULT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.state ALTER COLUMN id SET DEFAULT nextval('hangfire.state_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: license_events id; Type: DEFAULT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.license_events ALTER COLUMN id SET DEFAULT nextval('public.license_events_id_seq'::regclass);


--
-- Data for Name: aggregatedcounter; Type: TABLE DATA; Schema: hangfire; Owner: loomapos
--

COPY hangfire.aggregatedcounter (id, key, value, expireat) FROM stdin;
\.


--
-- Data for Name: counter; Type: TABLE DATA; Schema: hangfire; Owner: loomapos
--

COPY hangfire.counter (id, key, value, expireat) FROM stdin;
\.


--
-- Data for Name: hash; Type: TABLE DATA; Schema: hangfire; Owner: loomapos
--

COPY hangfire.hash (id, key, field, value, expireat, updatecount) FROM stdin;
\.


--
-- Data for Name: job; Type: TABLE DATA; Schema: hangfire; Owner: loomapos
--

COPY hangfire.job (id, stateid, statename, invocationdata, arguments, createdat, expireat, updatecount) FROM stdin;
\.


--
-- Data for Name: jobparameter; Type: TABLE DATA; Schema: hangfire; Owner: loomapos
--

COPY hangfire.jobparameter (id, jobid, name, value, updatecount) FROM stdin;
\.


--
-- Data for Name: jobqueue; Type: TABLE DATA; Schema: hangfire; Owner: loomapos
--

COPY hangfire.jobqueue (id, jobid, queue, fetchedat, updatecount) FROM stdin;
\.


--
-- Data for Name: list; Type: TABLE DATA; Schema: hangfire; Owner: loomapos
--

COPY hangfire.list (id, key, value, expireat, updatecount) FROM stdin;
\.


--
-- Data for Name: lock; Type: TABLE DATA; Schema: hangfire; Owner: loomapos
--

COPY hangfire.lock (resource, updatecount, acquired) FROM stdin;
\.


--
-- Data for Name: schema; Type: TABLE DATA; Schema: hangfire; Owner: loomapos
--

COPY hangfire.schema (version) FROM stdin;
21
\.


--
-- Data for Name: server; Type: TABLE DATA; Schema: hangfire; Owner: loomapos
--

COPY hangfire.server (id, data, lastheartbeat, updatecount) FROM stdin;
anonymous:102918:a3972bc1-bff4-4555-b382-5f809fc46dd4	{"Queues": ["default"], "StartedAt": "2026-04-01T23:45:15.4110471Z", "WorkerCount": 20}	2026-04-02 00:54:16.711809+00	0
\.


--
-- Data for Name: set; Type: TABLE DATA; Schema: hangfire; Owner: loomapos
--

COPY hangfire.set (id, key, score, value, expireat, updatecount) FROM stdin;
\.


--
-- Data for Name: state; Type: TABLE DATA; Schema: hangfire; Owner: loomapos
--

COPY hangfire.state (id, jobid, name, reason, createdat, data, updatecount) FROM stdin;
\.


--
-- Data for Name: __ef_migrations_history; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.__ef_migrations_history ("MigrationId", "ProductVersion") FROM stdin;
20260302180000_InitialSchema	9.0.4
20260305190000_ProductAndOpsFields	9.0.4
20260305203000_IdentityBranchUserOpsFields	9.0.4
20260305220000_CommerceLicensingReseller	9.0.4
20260306113000_ResellerLeadDetails	9.0.4
20260307143000_Phase2CommerceCore	9.0.4
20260310103000_InternalAdminAndProductionOps	9.0.4
20260310120000_CommerceAuthHardening	9.0.4
20260311110000_SupportCaseLifecycle	9.0.4
20260311123000_AnalyticsSchedulesAndSavedViews	9.0.4
20260329193000_WarehouseFoundation	9.0.4
20260330010500_WarehouseTransfers	9.0.4
20260330014000_PurchasingFoundation	9.0.4
20260330190000_CustomerCurrentAccounts	9.0.4
20260330194000_AccountingBridgeFoundation	9.0.4
20260330213000_ManufacturingPreparationFoundation	9.0.4
20260401120000_PaymentWebhookUniquenessHardening	9.0.4
\.


--
-- Data for Name: abuse_flags; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.abuse_flags (id, tenant_id, flag_type, severity, summary, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: accounting_export_items; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.accounting_export_items (id, tenant_id, source_type, source_id, event_code, payload_json, status, created_at, exported_at, failure_reason) FROM stdin;
\.


--
-- Data for Name: activation_events; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.activation_events (id, tenant_id, device_activation_id, event_type, payload_json, created_at) FROM stdin;
b9414e27-d589-4958-b1cc-8743184f5054	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	device_activated	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","DeviceName":"Kasa-4D10D9C3","Platform":"desktop","AppVersion":"0.1.0"}	2026-03-29 16:35:53.764989+00
73c07e8e-86fb-4662-a09e-25a5cbeee2db	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"0.1.0"}	2026-03-29 16:36:21.119063+00
86c642f0-da5b-4ed8-86dd-80088d2cacd9	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	device_activated	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","DeviceName":"Kasa-4D10D9C3","Platform":"desktop","AppVersion":"0.1.0"}	2026-03-29 16:40:47.120696+00
0478347b-e239-4367-bb27-78bfa305aeda	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	device_activated	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","DeviceName":"Kasa-4D10D9C3","Platform":"desktop","AppVersion":"33.4.11"}	2026-03-29 16:43:47.490623+00
95940f32-0401-4a78-9320-2d9e70cea94c	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-29 16:43:47.573252+00
7bc1e76f-52a1-47eb-a436-9f5eac238784	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-29 16:43:47.847367+00
666102ab-de4a-47fa-81ec-672f2ab0b7f5	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-29 16:43:47.847367+00
4492ffdd-4a79-405d-8e5b-752b18767e91	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-29 16:44:07.248579+00
0d36dc5d-6862-4e03-834e-c6af91ce2ee9	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-29 16:44:07.258059+00
a694dfc4-8d7a-4391-a604-bc0da726ac8c	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-29 16:45:31.192642+00
55fd6bbc-1d96-4911-9d47-2a52f5b586ac	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-29 16:45:31.300314+00
5c53ab00-2fda-4fb6-8e85-ad3bc45e5a94	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-29 16:45:31.300387+00
863160ac-5b48-402e-a551-e4b3e057b8d7	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-29 16:45:57.92994+00
31cfd78f-6eb7-4e65-9666-16b8dfc6249b	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-29 16:45:58.047172+00
15633e4c-4959-4a02-86c1-c91da107d0c4	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-29 16:45:58.048132+00
af7171fe-4ace-458f-84ab-ae45f929b182	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	device_activated	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","DeviceName":"Kasa-4D10D9C3","Platform":"desktop","AppVersion":"0.1.0"}	2026-03-29 17:15:02.952531+00
45b6c43a-e3c3-4498-a77e-0a0dddec2984	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"0.1.0"}	2026-03-29 17:15:02.975056+00
1c0e4a36-8074-42f9-8f25-3ef863124c0d	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-29 17:38:02.019744+00
4e167f13-54a9-422e-afa6-f226e01b303a	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-29 17:38:02.019756+00
f38ddd35-5b28-4260-a9ff-9ed5c88dbb79	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"0.1.0"}	2026-03-29 17:39:59.399184+00
46e72845-e3f4-46f4-88f4-8f225a1bbfb9	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-29 17:40:27.254467+00
6933d75d-70b5-41e3-b1eb-24eebd41530e	4d6b1960-9470-47fd-afeb-9b172fe8b408	5c63647f-fb03-46d2-84c9-7621b1a20ed9	device_activated	{"DeviceId":"84d4e6a9-245a-447f-982b-37720e3bc50d","DeviceName":"mobile-84d4e6a9","Platform":"mobile","AppVersion":"0.5.0"}	2026-03-29 18:00:48.309295+00
860fcd14-72ae-4311-b7ac-24347e7a719a	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-29 20:08:30.231271+00
ba0e4577-3b4e-4b56-a470-51d16ae976ec	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-29 20:08:30.377214+00
16ed36b6-c36b-4b36-b2ce-b1042d204813	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-29 20:08:30.378504+00
31e23268-46d7-4109-80d1-3bc4189ed641	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-31 14:34:15.996107+00
1d05d132-2cce-4693-b2b0-753b3012eba7	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-31 14:34:15.996114+00
60252ce4-11d6-46d8-a214-363adcaabe4d	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-31 14:37:16.688628+00
4b7f90dd-4702-4d33-9d8d-4b4e97e85151	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-31 14:37:16.823145+00
2bd6d053-4e5b-456c-9db8-01c88d4b30b6	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-31 14:37:16.825292+00
e2fcae85-b0f1-4711-97ed-6eba532bc84f	29baba1c-1732-4565-9b0f-b98b299dbfbb	7772f327-be15-4e33-b5f6-42f42c5a49fb	device_activated	{"DeviceId":"8e94e69c-7155-49b7-a45a-0aa1c1db05cf","DeviceName":"android-8e94e69c-7155-49b7-a45a-0aa1c1db05cf","Platform":"mobile","AppVersion":"1.0.0"}	2026-03-31 16:11:17.314131+00
63eddb66-d4d3-4363-9e0a-1e9b96243f44	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-31 19:09:51.54212+00
b1b3c454-d232-44f3-8785-7661b048d1b8	01072375-ea4f-41a3-bbc0-eac1b77037d8	464d659a-31b5-4230-95c3-32e44c17fded	heartbeat	{"DeviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","AppVersion":"33.4.11"}	2026-03-31 19:09:51.542125+00
6956130c-e144-42ec-b36c-945135798fc0	29baba1c-1732-4565-9b0f-b98b299dbfbb	36de4e34-6aa7-41e9-90b5-f3af9f561f33	device_activated	{"DeviceId":"15892d41-f150-4e72-a77b-19a2a5927895","DeviceName":"desktop-15892d41-f150-4e72-a77b-19a2a5927895","Platform":"desktop","AppVersion":"1.0.0"}	2026-03-31 19:12:34.957377+00
\.


--
-- Data for Name: admin_action_approvals; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.admin_action_approvals (id, admin_action_request_id, approved_by_internal_user_id, decision, note, created_at) FROM stdin;
\.


--
-- Data for Name: admin_action_requests; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.admin_action_requests (id, requested_by_internal_user_id, action_code, target_type, target_id, reason, status, requires_approval, metadata_json, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alert_events; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.alert_events (id, alert_rule_id, environment, severity, summary, status, triggered_at, acknowledged_at, created_at) FROM stdin;
\.


--
-- Data for Name: alert_rules; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.alert_rules (id, environment, code, severity, threshold_summary, status, runbook_code, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: analytics_report_schedules; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.analytics_report_schedules (id, tenant_id, name, report_code, frequency, format, timezone, recipients_json, filters_json, is_active, last_run_at, next_run_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: analytics_saved_views; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.analytics_saved_views (id, tenant_id, customer_account_id, scope, name, view_code, filters_json, is_default, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: app_releases; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.app_releases (id, platform, channel, version, release_date, release_notes_markdown, install_guide_markdown, minimum_requirements, is_public, is_active, created_at, updated_at) FROM stdin;
545cf901-6d08-4173-b817-4cdb9fe7eac2	windows	stable	1.4.2	2026-02-28	Yeni lisans aktivasyon sihirbazi ve rollout iyilestirmeleri.	1. Kurulum paketini indirin.\n2. Yonetici olarak calistirin.\n3. Portal lisans anahtarini girin.	Windows 10 veya 11, 4 GB RAM, 500 MB alan.	f	t	2026-03-28 19:50:46.744908+00	2026-03-28 19:50:46.77971+00
71f332c8-533d-4f50-aedf-2c42d601b76d	android	stable	1.4.2	2026-02-28	Mobil aktivasyon ve saha dogrulama iyilestirmeleri.	1. APK veya store linkini acin.\n2. Lisansli tenant hesabi ile giris yapin.	Android 10+, 200 MB alan.	f	t	2026-03-28 19:50:46.810455+00	2026-03-28 19:50:46.819523+00
d50a7032-74c0-455c-845e-c0b809ac1bc0	ios	stable	1.4.2	2026-02-28	iOS dagitim bilgisi ve aktivasyon rehberi.	1. App Store/TestFlight dagitimini takip edin.\n2. Lisansli tenant ile giris yapin.	iOS 17+.	t	t	2026-03-28 19:50:46.825799+00	2026-03-28 19:50:46.826678+00
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.audit_logs (id, tenant_id, user_id, action, entity, entity_id, payload_json, created_at) FROM stdin;
1	29baba1c-1732-4565-9b0f-b98b299dbfbb	\N	CHECKOUT_PROVISIONED	checkout_sessions	700b8dc0-d67d-4f1a-bd9f-8477c5586d5c	{"Code":"pro","BillingCycle":"monthly","InvoiceNo":"INV-20260328-6616"}	2026-03-28 19:52:41.757374+00
2	29baba1c-1732-4565-9b0f-b98b299dbfbb	\N	LICENSE_ISSUED	licenses	2e19ef47-f3a3-4491-a490-0a22ec4dbe2d	{"LicenseKey":"LMA-EF0EC9-12123E-782344-5310A8","ExpiresAt":"2026-04-28T19:52:41.4973523+00:00"}	2026-03-28 19:52:41.758556+00
3	29baba1c-1732-4565-9b0f-b98b299dbfbb	1a40ae98-9470-4d8a-b447-d9089eee0626	portal.subscription.plan_change_requested	subscription	d53794db-c8ef-4b6e-9c04-b2021234f86e	{"planCode":"enterprise","billingCycle":"monthly","mode":"immediate","effectiveAt":"2026-03-28T20:23:04.4760603+00:00","warnings":[]}	2026-03-28 20:23:04.478607+00
4	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	\N	CHECKOUT_PROVISIONED	checkout_sessions	f0516460-da1f-459c-8392-97a5105a95f6	{"Code":"starter","BillingCycle":"monthly","InvoiceNo":"INV-20260329-5219"}	2026-03-29 13:41:39.989134+00
5	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	\N	LICENSE_ISSUED	licenses	1c0eb33b-e162-4f52-98ec-0290e2964606	{"LicenseKey":"LMA-25D59E-687D2A-894B26-FC8F1D","ExpiresAt":"2026-04-29T13:41:39.7572939+00:00"}	2026-03-29 13:41:39.990223+00
6	4d6b1960-9470-47fd-afeb-9b172fe8b408	\N	CHECKOUT_PROVISIONED	checkout_sessions	e09a2060-084d-4646-9ea2-2a7f0bed41db	{"Code":"starter","BillingCycle":"monthly","InvoiceNo":"INV-20260329-3541"}	2026-03-29 13:55:45.015271+00
7	4d6b1960-9470-47fd-afeb-9b172fe8b408	\N	LICENSE_ISSUED	licenses	15df5e32-74b2-47a9-8e3b-dbff25458f13	{"LicenseKey":"LMA-950CE2-47403E-5F3579-D91484","ExpiresAt":"2026-04-29T13:55:44.9913915+00:00"}	2026-03-29 13:55:45.015308+00
8	1b2dd3e6-38dd-4103-8942-544df818621c	\N	CHECKOUT_PROVISIONED	checkout_sessions	9b1603a8-3e24-46f6-bc05-b450d729e785	{"Code":"starter","BillingCycle":"monthly","InvoiceNo":"INV-20260329-3880"}	2026-03-29 13:56:32.746531+00
9	1b2dd3e6-38dd-4103-8942-544df818621c	\N	LICENSE_ISSUED	licenses	83631f1b-1738-46ce-85b9-6e17e783e1bf	{"LicenseKey":"LMA-2F28FE-4F7113-6A0998-FC0532","ExpiresAt":"2026-04-29T13:56:32.4766178+00:00"}	2026-03-29 13:56:32.747741+00
10	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	\N	CHECKOUT_PROVISIONED	checkout_sessions	d21480da-cd09-4786-9608-27b4774ff935	{"Code":"starter","BillingCycle":"monthly","InvoiceNo":"INV-20260329-1381"}	2026-03-29 13:58:47.707878+00
11	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	\N	LICENSE_ISSUED	licenses	8249abd0-bf6a-4a20-b501-56d9f8464810	{"LicenseKey":"LMA-440FE5-C1861A-368E14-DE2D23","ExpiresAt":"2026-04-29T13:58:47.4207998+00:00"}	2026-03-29 13:58:47.709066+00
12	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	CHECKOUT_PROVISIONED	checkout_sessions	61f7b77f-7301-4346-90b5-79df284136e0	{"Code":"starter","BillingCycle":"monthly","InvoiceNo":"INV-20260329-8966"}	2026-03-29 14:01:32.641855+00
13	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	LICENSE_ISSUED	licenses	c038100b-fb18-4894-abb1-bd9551c34643	{"LicenseKey":"LMA-B8EFB9-BCEE6C-E175B8-960788","ExpiresAt":"2026-04-29T14:01:32.3531505+00:00"}	2026-03-29 14:01:32.643095+00
14	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T16:43:49.210Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":false,"printerConfigured":false}	2026-03-29 16:43:49.35023+00
15	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	7cec6763-2b15-4ce1-aded-7ff7d3c642ed	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T16:43:49.210Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":false,"printerConfigured":false}	2026-03-29 16:43:49.390933+00
16	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T16:44:49.257Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":false,"printerConfigured":false}	2026-03-29 16:44:49.314902+00
17	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	9c2bd783-51af-45c1-8838-c92f570def9f	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T16:44:49.257Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":false,"printerConfigured":false}	2026-03-29 16:44:49.315205+00
18	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T16:45:49.303Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":false,"printerConfigured":false}	2026-03-29 16:45:49.326916+00
19	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	fba998b5-11d9-46b0-9316-aef7fb285c26	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T16:45:49.303Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":false,"printerConfigured":false}	2026-03-29 16:45:49.327115+00
20	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	CASH_SESSION_OPENED	cash_sessions	009ed64a-f060-42cd-9940-2e302717201b	{"cashSessionId":"009ed64a-f060-42cd-9940-2e302717201b","cashierUserId":"fec91241358ce8383cd5c00d32fbd1a3","cashierName":"Demo Owner 5","openedAt":"2026-03-29T16:45:51.176Z","openingCashAmount":0}	2026-03-29 16:45:54.320675+00
21	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	71fcaa2c-9cac-40f9-9836-6f3c94c49143	{"cashSessionId":"009ed64a-f060-42cd-9940-2e302717201b","cashierUserId":"fec91241358ce8383cd5c00d32fbd1a3","cashierName":"Demo Owner 5","openedAt":"2026-03-29T16:45:51.176Z","openingCashAmount":0}	2026-03-29 16:45:54.320815+00
22	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SALE_CREATED	sales	f7b6fa94-44ec-49b0-93bd-b2ad7269de16	{"SaleId":"f7b6fa94-44ec-49b0-93bd-b2ad7269de16","ReceiptNo":"SAT-25-0417C9-20260329-009ED6-000001","CreatedAt":"2026-03-29T16:45:56.045+00:00","Subtotal":210,"Discount":0,"Tax":21,"Total":231,"Lines":[{"ProductId":"d4c697e1-887f-9a90-346d-9e4917442c9c","Qty":3,"UnitPrice":70,"Discount":0,"Tax":21,"LineTotal":231}],"Payments":[{"Method":1,"Amount":231}]}	2026-03-29 16:45:59.479431+00
23	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	96308bb3-e351-4e9d-96b2-1c3fc639b823	{"saleId":"f7b6fa94-44ec-49b0-93bd-b2ad7269de16","receiptNo":"SAT-25-0417C9-20260329-009ED6-000001","createdAt":"2026-03-29T16:45:56.045Z","cashSessionId":"009ed64a-f060-42cd-9940-2e302717201b","customerName":null,"subtotal":210,"discount":0,"tax":21,"total":231,"lines":[{"productId":"d4c697e1-887f-9a90-346d-9e4917442c9c","qty":3,"unitPrice":70,"discount":0,"tax":21,"lineTotal":231}],"payments":[{"method":"CASH","amount":231}]}	2026-03-29 16:45:59.483144+00
24	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	c9257b9f-cb60-4c4c-b25d-d606692eb0eb	{"saleId":"f7b6fa94-44ec-49b0-93bd-b2ad7269de16","receiptNo":"SAT-25-0417C9-20260329-009ED6-000001","method":"CASH","amount":231,"createdAt":"2026-03-29T16:45:56.045Z","cashSessionId":"009ed64a-f060-42cd-9940-2e302717201b"}	2026-03-29 16:45:59.581287+00
25	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T16:46:49.344Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 16:46:49.361823+00
26	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	a7561e57-69f5-450f-9fa2-b497c927a58e	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T16:46:49.344Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 16:46:49.362148+00
27	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T16:47:49.378Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 16:47:49.401611+00
28	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	4a9cccb9-640d-47e2-a238-672315eb2df0	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T16:47:49.378Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 16:47:49.401817+00
29	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:11:41.056Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:11:41.073857+00
30	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	5d81c298-a323-43fe-94ad-f66d2d5a6cec	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:11:41.056Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:11:41.07405+00
31	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:12:41.112Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:12:41.141431+00
32	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	cf856724-b32c-424f-8a70-9d0a5ca519a4	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:12:41.112Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:12:41.141649+00
33	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:13:41.160Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:13:41.179603+00
34	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	59380e9c-a9ea-4c29-849f-6d6401565356	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:13:41.160Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:13:41.179729+00
35	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:14:41.214Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:14:41.238675+00
36	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	5522b32b-0501-4979-8212-e261edc42fcc	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:14:41.214Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:14:41.238849+00
37	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:15:41.264Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:15:41.282028+00
38	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	796551e1-53da-48a3-a17d-38fc5dd3b0c4	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:15:41.264Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:15:41.282187+00
39	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:16:41.311Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:16:41.334485+00
40	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	ce4ab8d6-0fea-42a8-93b7-8caab24e2616	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:16:41.311Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:16:41.334616+00
41	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:17:41.373Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:17:41.396523+00
42	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	fb52a6e3-c3f0-4009-8446-53bb2cdeba26	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:17:41.373Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:17:41.396789+00
43	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:18:41.415Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:18:41.44428+00
44	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	d4b62a08-89a3-42d0-a5b2-fcfa5451c9b2	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:18:41.415Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:18:41.444376+00
45	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:19:41.467Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:19:41.487447+00
46	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	3b20aa58-af3e-4fe4-93c0-6c74f0c0b19a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:19:41.467Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:19:41.48754+00
47	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:20:41.519Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:20:41.542937+00
48	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	1405c283-d93c-404b-851d-880eaaa518ca	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:20:41.519Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:20:41.543094+00
49	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:21:41.572Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:21:41.594053+00
50	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	4d1352fd-127e-40cd-b9b7-9f09b164c225	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:21:41.572Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:21:41.594188+00
51	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:22:41.624Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:22:41.644186+00
52	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	166a0c6d-f177-4378-9126-aa14563febe1	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:22:41.624Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:22:41.644259+00
53	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:23:41.671Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:23:41.729155+00
54	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	fa16184f-8a09-43f6-bca7-dfdc7bb008c9	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:23:41.671Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:23:41.729769+00
55	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:24:41.734Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:24:41.781842+00
56	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	52fa74d4-0c69-4ad3-be1e-cb4e744ff8a8	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:24:41.734Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:24:41.782451+00
57	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	DEVICE_HEARTBEAT	devices	0417c926-baca-46bd-8ce9-ef3d8c02592a	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:25:41.848Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:25:42.144494+00
58	01072375-ea4f-41a3-bbc0-eac1b77037d8	\N	SYNC_EVENT_PROCESSED	processed_events	17b03afc-8f47-4c38-9def-c9f931a58e39	{"tenantId":"01072375-ea4f-41a3-bbc0-eac1b77037d8","branchId":"54bc4367-e4a6-4c6f-b693-a106594cfe6f","deviceId":"0417c926-baca-46bd-8ce9-ef3d8c02592a","appVersion":"0.1.0","localTime":"2026-03-29T17:25:41.848Z","connectionStatus":"online","pendingOutboxCount":0,"activeCashSession":true,"printerConfigured":false}	2026-03-29 17:25:42.158568+00
61	4d6b1960-9470-47fd-afeb-9b172fe8b408	\N	SYNC_EVENT_FAILED	sync_events	71654ede-82c4-4866-8954-6a17fbdcd1cc	{"EventId":"71654ede-82c4-4866-8954-6a17fbdcd1cc","EventType":"USER_SESSION_STARTED","Status":"retry_later","ErrorCode":"server_error","Message":"Temporary sync failure.","ServerReferenceId":"c5f2d30721f7cea5cd0acb2212111905","FailedAt":"2026-03-29T20:09:30.0704956+00:00"}	2026-03-29 20:09:30.070429+00
64	4d6b1960-9470-47fd-afeb-9b172fe8b408	\N	SYNC_EVENT_FAILED	sync_events	71654ede-82c4-4866-8954-6a17fbdcd1cc	{"EventId":"71654ede-82c4-4866-8954-6a17fbdcd1cc","EventType":"USER_SESSION_STARTED","Status":"retry_later","ErrorCode":"server_error","Message":"Temporary sync failure.","ServerReferenceId":"c5f2d30721f7cea5cd0acb2212111905","FailedAt":"2026-03-29T20:10:19.9272453+00:00"}	2026-03-29 20:10:19.927244+00
\.


--
-- Data for Name: backup_runs; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.backup_runs (id, environment, backup_type, status, region, retention_policy, artifact_reference, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: bill_of_material_lines; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.bill_of_material_lines (id, bom_id, component_product_id, quantity) FROM stdin;
\.


--
-- Data for Name: bill_of_materials; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.bill_of_materials (id, tenant_id, product_id, code, version, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: billing_profiles; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.billing_profiles (id, tenant_id, customer_account_id, company_name, billing_email, phone, tax_office, tax_number, address_line, city, country, locale, status, created_at, updated_at) FROM stdin;
56726ae9-0e54-443e-8a28-800ae2a2190f	29baba1c-1732-4565-9b0f-b98b299dbfbb	1a40ae98-9470-4d8a-b447-d9089eee0626	Demo Magaza Ltd	billing@demo.local	+905300000001	Kadikoy	1234567890	Moda Cad.	Istanbul	TR	tr-TR	active	2026-03-28 19:52:41.416569+00	2026-03-28 19:52:41.49287+00
e2459fca-fe48-49c0-9b1e-0f622bbb8e4a	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	0d68f479-53d2-499a-9b19-041da47d9c4d	Demo Magaza	owner@demo.local	+905551112233	Van	1234567890	Demo Cad. No:1	Van	TR	tr-TR	active	2026-03-29 13:41:39.721741+00	2026-03-29 13:41:39.752854+00
48952a74-d5d9-4358-a3a2-1663b985f085	4d6b1960-9470-47fd-afeb-9b172fe8b408	e1a75aac-d3a3-4d1c-a94c-42bda9e5f4ee	Demo Magaza 2	owner2@demo.local	+905551112244	Van	1234567891	Demo Cad. No:2	Van	TR	tr-TR	active	2026-03-29 13:55:44.98676+00	2026-03-29 13:55:44.987433+00
f03f4ebb-e3d6-4e17-a8c3-c6b366bd5d8f	1b2dd3e6-38dd-4103-8942-544df818621c	23237479-241c-4c06-adf7-2036086ea1fe	Demo Magaza 3	owner3@demo.local	+905551112255	Van	1234567892	Demo Cad. No:3	Van	TR	tr-TR	active	2026-03-29 13:56:32.426618+00	2026-03-29 13:56:32.469321+00
2dc070d7-a389-4b1e-9867-428d5b72f015	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	973a2c5c-759f-4421-bbd0-9c630af456f5	Demo Magaza 4	owner4@demo.local	+905551112266	Van	1234567893	Demo Cad. No:4	Van	TR	tr-TR	active	2026-03-29 13:58:47.376229+00	2026-03-29 13:58:47.414434+00
eebf784c-6722-4560-8b27-c5f7b8110369	01072375-ea4f-41a3-bbc0-eac1b77037d8	f29fe2cd-4fac-442a-8519-6956bfdac35d	Demo Magaza 5	owner5@demo.local	+905551112277	Van	1234567894	Demo Cad. No:5	Van	TR	tr-TR	active	2026-03-29 14:01:32.310097+00	2026-03-29 14:01:32.347648+00
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.branches (id, tenant_id, name, address, created_at, phone, tax_number, settings_json) FROM stdin;
\.


--
-- Data for Name: capacity_snapshots; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.capacity_snapshots (id, environment, resource_type, scope, utilization_summary, headroom_state, created_at) FROM stdin;
\.


--
-- Data for Name: cash_transactions; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.cash_transactions (id, tenant_id, branch_id, type, amount, reason, created_at) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.categories (id, tenant_id, name, parent_id) FROM stdin;
\.


--
-- Data for Name: checkout_sessions; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.checkout_sessions (id, tenant_id, company_name, email, plan_code, billing_cycle, reseller_code, amount, currency, status, completed_at, created_at, customer_account_id, subscription_id, billing_profile_id, license_id, checkout_reference, contact_name, phone, provider, provider_session_id, provider_payment_reference, coupon_code, tax_amount, payment_status, checkout_payload_json, billing_payload_json, idempotency_key, provisioned_at, error, updated_at) FROM stdin;
700b8dc0-d67d-4f1a-bd9f-8477c5586d5c	29baba1c-1732-4565-9b0f-b98b299dbfbb	Demo Magaza	demo.owner@loomapos.local	pro	monthly	MARMAR429	2990.00	TRY	provisioned	2026-03-28 19:52:41.497352+00	2026-03-28 19:52:41.099889+00	1a40ae98-9470-4d8a-b447-d9089eee0626	d53794db-c8ef-4b6e-9c04-b2021234f86e	56726ae9-0e54-443e-8a28-800ae2a2190f	2e19ef47-f3a3-4491-a490-0a22ec4dbe2d	CHK-20260328195241-993	Demo Owner	+905300000001	mock	mock-session-700b8dc0d67d4f1abd9f8477c5586d5c	mock-payment-700b8dc0d67d4f1abd9f8477c5586d5c	\N	0.00	paid	{"FullName":"Demo Owner","Email":"demo.owner@loomapos.local","PasswordHash":"pbkdf2$120000$PjDUra5/cL4Y7iuGZR5acg==$k\\u002BQJAj6eadIL2tu1dLNRfHzo8dN5ou8Cb3m5B0s45zI=","Phone":"\\u002B905300000001"}	{"BillingTitle":"Demo Magaza Ltd","BillingEmail":"billing@demo.local","TaxOffice":"Kadikoy","TaxNumber":"1234567890","AddressLine":"Moda Cad.","City":"Istanbul","Country":"tr","Locale":"tr-TR","PaymentMethod":"card"}	\N	2026-03-28 19:52:41.497352+00	\N	2026-03-28 19:52:41.797361+00
f0516460-da1f-459c-8392-97a5105a95f6	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	Demo Magaza	owner@demo.local	starter	monthly	\N	1490.00	TRY	provisioned	2026-03-29 13:41:39.757293+00	2026-03-29 13:41:39.427185+00	0d68f479-53d2-499a-9b19-041da47d9c4d	ba2d5a68-91bc-45e1-be8b-5a128033c704	e2459fca-fe48-49c0-9b1e-0f622bbb8e4a	1c0eb33b-e162-4f52-98ec-0290e2964606	CHK-20260329134139-427	Demo Owner	+905551112233	mock	mock-session-f0516460da1f459c839297a5105a95f6	mock-payment-f0516460da1f459c839297a5105a95f6	\N	0.00	paid	{"FullName":"Demo Owner","Email":"owner@demo.local","PasswordHash":"pbkdf2$120000$PtAvLHOPzoe4EQ2/6gfhzQ==$BQ2qBWi\\u002Bkl1P\\u002B9F/\\u002BJ9IEtmmJm8SZUkv04sGwZv0eVU=","Phone":"\\u002B905551112233"}	{"BillingTitle":"Demo Magaza","BillingEmail":"owner@demo.local","TaxOffice":"Van","TaxNumber":"1234567890","AddressLine":"Demo Cad. No:1","City":"Van","Country":"tr","Locale":"tr-TR","PaymentMethod":"card"}	\N	2026-03-29 13:41:39.757293+00	\N	2026-03-29 13:41:40.018596+00
e09a2060-084d-4646-9ea2-2a7f0bed41db	4d6b1960-9470-47fd-afeb-9b172fe8b408	Demo Magaza 2	owner2@demo.local	starter	monthly	\N	1490.00	TRY	provisioned	2026-03-29 13:55:44.991391+00	2026-03-29 13:55:44.793978+00	e1a75aac-d3a3-4d1c-a94c-42bda9e5f4ee	51345f8e-b501-42e8-aa57-19ea66b6f176	48952a74-d5d9-4358-a3a2-1663b985f085	15df5e32-74b2-47a9-8e3b-dbff25458f13	CHK-20260329135544-220	Demo Owner 2	+905551112244	mock	mock-session-e09a2060084d46469ea22a7f0bed41db	mock-payment-e09a2060084d46469ea22a7f0bed41db	\N	0.00	paid	{"FullName":"Demo Owner 2","Email":"owner2@demo.local","PasswordHash":"pbkdf2$120000$sMMXnAmKJCzu41xcwzP1aA==$gbtLgb42eGqcgr1hbaTsb1s4MCJprRhdCo014tkyxBU=","Phone":"\\u002B905551112244"}	{"BillingTitle":"Demo Magaza 2","BillingEmail":"owner2@demo.local","TaxOffice":"Van","TaxNumber":"1234567891","AddressLine":"Demo Cad. No:2","City":"Van","Country":"tr","Locale":"tr-TR","PaymentMethod":"card"}	\N	2026-03-29 13:55:44.991391+00	\N	2026-03-29 13:55:45.016314+00
9b1603a8-3e24-46f6-bc05-b450d729e785	1b2dd3e6-38dd-4103-8942-544df818621c	Demo Magaza 3	owner3@demo.local	starter	monthly	\N	1490.00	TRY	provisioned	2026-03-29 13:56:32.476617+00	2026-03-29 13:56:31.866116+00	23237479-241c-4c06-adf7-2036086ea1fe	236da988-0f98-47a0-b34f-4001df574251	f03f4ebb-e3d6-4e17-a8c3-c6b366bd5d8f	83631f1b-1738-46ce-85b9-6e17e783e1bf	CHK-20260329135631-442	Demo Owner 3	+905551112255	mock	mock-session-9b1603a83e2446f6bc05b450d729e785	mock-payment-9b1603a83e2446f6bc05b450d729e785	\N	0.00	paid	{"FullName":"Demo Owner 3","Email":"owner3@demo.local","PasswordHash":"pbkdf2$120000$KKX6NZRrcW3Hp635hEGRTw==$MpWUypd1aQ0nQFRoeDdm2TothpUjULpgwcpukJwXjHA=","Phone":"\\u002B905551112255"}	{"BillingTitle":"Demo Magaza 3","BillingEmail":"owner3@demo.local","TaxOffice":"Van","TaxNumber":"1234567892","AddressLine":"Demo Cad. No:3","City":"Van","Country":"tr","Locale":"tr-TR","PaymentMethod":"card"}	\N	2026-03-29 13:56:32.476617+00	\N	2026-03-29 13:56:32.8061+00
d21480da-cd09-4786-9608-27b4774ff935	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	Demo Magaza 4	owner4@demo.local	starter	monthly	\N	1490.00	TRY	provisioned	2026-03-29 13:58:47.420799+00	2026-03-29 13:58:46.813016+00	973a2c5c-759f-4421-bbd0-9c630af456f5	44a14acc-84d8-4479-ac99-74ea223f21a3	2dc070d7-a389-4b1e-9867-428d5b72f015	8249abd0-bf6a-4a20-b501-56d9f8464810	CHK-20260329135846-911	Demo Owner 4	+905551112266	mock	mock-session-d21480dacd094786960827b4774ff935	mock-payment-d21480dacd094786960827b4774ff935	\N	0.00	paid	{"FullName":"Demo Owner 4","Email":"owner4@demo.local","PasswordHash":"pbkdf2$120000$ZTGYSLEcNE4wDYyre\\u002BJvIw==$pRL5zJyddpn45uHMjcuLvEvdJOP\\u002B0ahMX2HnnIbskeI=","Phone":"\\u002B905551112266"}	{"BillingTitle":"Demo Magaza 4","BillingEmail":"owner4@demo.local","TaxOffice":"Van","TaxNumber":"1234567893","AddressLine":"Demo Cad. No:4","City":"Van","Country":"tr","Locale":"tr-TR","PaymentMethod":"card"}	\N	2026-03-29 13:58:47.420799+00	\N	2026-03-29 13:58:47.771136+00
61f7b77f-7301-4346-90b5-79df284136e0	01072375-ea4f-41a3-bbc0-eac1b77037d8	Demo Magaza 5	owner5@demo.local	starter	monthly	\N	1490.00	TRY	provisioned	2026-03-29 14:01:32.35315+00	2026-03-29 14:01:31.725332+00	f29fe2cd-4fac-442a-8519-6956bfdac35d	d88ee0e7-4d47-4bc8-b43a-b79eafe3a28d	eebf784c-6722-4560-8b27-c5f7b8110369	c038100b-fb18-4894-abb1-bd9551c34643	CHK-20260329140131-291	Demo Owner 5	+905551112277	mock	mock-session-61f7b77f7301434690b579df284136e0	mock-payment-61f7b77f7301434690b579df284136e0	\N	0.00	paid	{"FullName":"Demo Owner 5","Email":"owner5@demo.local","PasswordHash":"pbkdf2$120000$U6atOG8PXJyuIE92MD4O7w==$FKOQ3cPGHyw2FPAKiW2YSxLojeUbI5HLUDR9Q8WYjBM=","Phone":"\\u002B905551112277"}	{"BillingTitle":"Demo Magaza 5","BillingEmail":"owner5@demo.local","TaxOffice":"Van","TaxNumber":"1234567894","AddressLine":"Demo Cad. No:5","City":"Van","Country":"tr","Locale":"tr-TR","PaymentMethod":"card"}	\N	2026-03-29 14:01:32.35315+00	\N	2026-03-29 14:01:32.700173+00
aa5a255b-5d42-45b5-95b9-6cd0091aee99	\N	Looma Demo Market	demo.shared@loomapos.local	starter	monthly	\N	1490.00	TRY	payment_confirmed	\N	2026-03-31 14:29:35.262155+00	\N	\N	\N	\N	CHK-20260331142935-612	Looma Demo Owner	+905551112233	mock	mock-session-aa5a255b5d4245b595b96cd0091aee99	mock-payment-aa5a255b5d4245b595b96cd0091aee99	\N	0.00	paid	{"FullName":"Looma Demo Owner","Email":"demo.shared@loomapos.local","PasswordHash":"pbkdf2$120000$11mBoyEpyROFcIfH8qec3g==$KTgnN3RsJDLtAc7fATbaKsDyBAnqBE8Dsb2aMu7SULg=","Phone":"\\u002B905551112233"}	{"BillingTitle":"Looma Demo Market","BillingEmail":"demo.shared@loomapos.local","TaxOffice":"Demo Tax","TaxNumber":"1234567890","AddressLine":"Demo Cadde 1","City":"Istanbul","Country":"tr","Locale":"tr-TR","PaymentMethod":"card"}	\N	\N	\N	2026-03-31 14:29:35.605838+00
3e281673-9653-4661-8c57-f6dfd2f1285b	\N	Looma Demo Market	demo.shared@loomapos.local	starter	monthly	\N	1490.00	TRY	payment_confirmed	\N	2026-03-31 14:29:47.454927+00	\N	\N	\N	\N	CHK-20260331142947-416	Looma Demo Owner	+905551112233	mock	mock-session-3e281673965346618c57f6dfd2f1285b	mock-payment-3e281673965346618c57f6dfd2f1285b	\N	0.00	paid	{"FullName":"Looma Demo Owner","Email":"demo.shared@loomapos.local","PasswordHash":"pbkdf2$120000$DNhiq1Zyjpk2AtCZVXS0pQ==$EFjAyViPnrH\\u002BbiqZ0WYw1/iDBVwOzgAruLrd2qdmtcg=","Phone":"\\u002B905551112233"}	{"BillingTitle":"Looma Demo Market","BillingEmail":"demo.shared@loomapos.local","TaxOffice":"Demo Tax","TaxNumber":"1234567890","AddressLine":"Demo Cadde 1","City":"Istanbul","Country":"tr","Locale":"tr-TR","PaymentMethod":"card"}	\N	\N	\N	2026-03-31 14:29:47.552572+00
\.


--
-- Data for Name: commissions; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.commissions (id, tenant_id, reseller_id, subscription_id, invoice_id, rate, amount, status, accrued_at, paid_at, created_at) FROM stdin;
\.


--
-- Data for Name: contact_ledger; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.contact_ledger (id, tenant_id, contact_id, amount_delta, reason, ref_type, ref_id, created_at) FROM stdin;
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.contacts (id, tenant_id, type, name, phone, email, created_at) FROM stdin;
\.


--
-- Data for Name: customer_account_entries; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.customer_account_entries (id, tenant_id, customer_id, type, amount, ref_type, ref_id, created_at, note) FROM stdin;
\.


--
-- Data for Name: customer_accounts; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.customer_accounts (id, email, password_hash, full_name, phone, account_status, email_verified_at, last_login_at, password_reset_token_hash, password_reset_expires_at, created_at, updated_at, email_verification_token_hash, email_verification_expires_at) FROM stdin;
e1a75aac-d3a3-4d1c-a94c-42bda9e5f4ee	owner2@demo.local	pbkdf2$120000$sMMXnAmKJCzu41xcwzP1aA==$gbtLgb42eGqcgr1hbaTsb1s4MCJprRhdCo014tkyxBU=	Demo Owner 2	+905551112244	active	\N	2026-03-29 20:08:30.207936+00	\N	\N	2026-03-29 13:55:44.9698+00	2026-03-29 20:08:30.20817+00	\N	\N
973a2c5c-759f-4421-bbd0-9c630af456f5	owner4@demo.local	pbkdf2$120000$eC2sCVsKp/UWRYIkatLIVA==$9pRXV6AUoduSwLyqGvNF+nsmeQXWH/b5JNXK2vfEpE4=	Demo Owner 4	+905551112266	active	2026-03-31 14:31:05.667177+00	2026-03-31 14:32:05.199241+00	\N	\N	2026-03-29 13:58:47.246691+00	2026-03-31 14:32:05.237375+00	\N	\N
0d68f479-53d2-499a-9b19-041da47d9c4d	owner@demo.local	pbkdf2$120000$PtAvLHOPzoe4EQ2/6gfhzQ==$BQ2qBWi+kl1P+9F/+J9IEtmmJm8SZUkv04sGwZv0eVU=	Demo Owner	+905551112233	active	\N	2026-03-29 14:04:21.400607+00	\N	\N	2026-03-29 13:38:56.779968+00	2026-03-29 14:04:21.447137+00	81c10b5f3071e1550618a0d35f36d55b24198df93de651e851fea83204cb6892	2026-03-31 13:38:56.958236+00
1a40ae98-9470-4d8a-b447-d9089eee0626	demo.owner@loomapos.local	pbkdf2$120000$eC2sCVsKp/UWRYIkatLIVA==$9pRXV6AUoduSwLyqGvNF+nsmeQXWH/b5JNXK2vfEpE4=	Demo Owner	+905300000001	active	2026-03-31 14:31:05.667177+00	2026-03-31 19:12:34.814717+00	\N	\N	2026-03-28 19:51:46.210989+00	2026-03-31 19:12:34.815197+00	f5da06d2d33c9d5cbfe58de8d6673efd92aab8aea093689da0bb23f8ff74c546	2026-03-30 19:51:46.358774+00
23237479-241c-4c06-adf7-2036086ea1fe	owner3@demo.local	pbkdf2$120000$KKX6NZRrcW3Hp635hEGRTw==$MpWUypd1aQ0nQFRoeDdm2TothpUjULpgwcpukJwXjHA=	Demo Owner 3	+905551112255	active	\N	2026-03-29 17:56:17.281291+00	\N	\N	2026-03-29 13:56:32.289581+00	2026-03-29 17:56:17.281595+00	\N	\N
f29fe2cd-4fac-442a-8519-6956bfdac35d	owner5@demo.local	pbkdf2$120000$U6atOG8PXJyuIE92MD4O7w==$FKOQ3cPGHyw2FPAKiW2YSxLojeUbI5HLUDR9Q8WYjBM=	Demo Owner 5	+905551112277	active	\N	2026-03-29 17:56:17.591452+00	\N	\N	2026-03-29 14:01:32.170631+00	2026-03-29 17:56:17.591833+00	\N	\N
\.


--
-- Data for Name: customer_current_accounts; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.customer_current_accounts (id, tenant_id, customer_id, balance, currency, updated_at) FROM stdin;
\.


--
-- Data for Name: dependency_status_records; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.dependency_status_records (id, environment, dependency_code, status, last_error_summary, last_success_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: deployment_records; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.deployment_records (id, environment, service_name, version, commit_sha, status, release_channel, artifact_type, correlation_id, metadata_json, created_at) FROM stdin;
\.


--
-- Data for Name: device_activations; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.device_activations (id, tenant_id, device_id, device_name, platform, app_version, activation_source, activated_at, last_seen_at, revoked_at, created_at, license_id, status, updated_at) FROM stdin;
5c63647f-fb03-46d2-84c9-7621b1a20ed9	4d6b1960-9470-47fd-afeb-9b172fe8b408	84d4e6a9-245a-447f-982b-37720e3bc50d	mobile-84d4e6a9	mobile	0.5.0	mobile	2026-03-29 18:00:48.305107+00	2026-03-29 18:00:48.30517+00	\N	2026-03-29 18:00:48.304525+00	15df5e32-74b2-47a9-8e3b-dbff25458f13	active	2026-03-29 18:00:48.305501+00
7772f327-be15-4e33-b5f6-42f42c5a49fb	29baba1c-1732-4565-9b0f-b98b299dbfbb	8e94e69c-7155-49b7-a45a-0aa1c1db05cf	android-8e94e69c-7155-49b7-a45a-0aa1c1db05cf	mobile	1.0.0	mobile	2026-03-31 16:11:17.112571+00	2026-03-31 16:11:17.11264+00	\N	2026-03-31 16:11:17.111906+00	2e19ef47-f3a3-4491-a490-0a22ec4dbe2d	active	2026-03-31 16:11:17.155937+00
464d659a-31b5-4230-95c3-32e44c17fded	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	Kasa-4D10D9C3	desktop	33.4.11	desktop	2026-03-29 16:35:53.718777+00	2026-03-31 19:09:51.542002+00	\N	2026-03-29 16:35:53.718335+00	c038100b-fb18-4894-abb1-bd9551c34643	active	2026-03-31 19:09:51.573554+00
36de4e34-6aa7-41e9-90b5-f3af9f561f33	29baba1c-1732-4565-9b0f-b98b299dbfbb	15892d41-f150-4e72-a77b-19a2a5927895	desktop-15892d41-f150-4e72-a77b-19a2a5927895	desktop	1.0.0	desktop	2026-03-31 19:12:34.9447+00	2026-03-31 19:12:34.944701+00	\N	2026-03-31 19:12:34.944697+00	2e19ef47-f3a3-4491-a490-0a22ec4dbe2d	active	2026-03-31 19:12:34.944933+00
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.devices (id, tenant_id, branch_id, name, type, last_seen_at, created_at) FROM stdin;
0417c926-baca-46bd-8ce9-ef3d8c02592a	01072375-ea4f-41a3-bbc0-eac1b77037d8	54bc4367-e4a6-4c6f-b693-a106594cfe6f	POS-0417c926	desktop-pos	2026-03-29 17:25:42.143304+00	2026-03-29 16:43:49.328459+00
\.


--
-- Data for Name: download_accesses; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.download_accesses (id, tenant_id, downloadable_asset_id, subscription_id, license_id, status, expires_at, created_at, updated_at) FROM stdin;
7d3836cc-79c1-4c0d-925a-e00ad890234f	29baba1c-1732-4565-9b0f-b98b299dbfbb	55a90fb0-653e-43c9-84e3-bd7b2e5b8098	d53794db-c8ef-4b6e-9c04-b2021234f86e	2e19ef47-f3a3-4491-a490-0a22ec4dbe2d	active	2026-04-28 19:52:41.497352+00	2026-03-28 19:52:41.723839+00	2026-03-28 19:52:41.797358+00
9c1d5a06-261c-497c-884e-b761f6db751e	29baba1c-1732-4565-9b0f-b98b299dbfbb	b0887ac3-143e-4daa-b255-6579c81fada1	d53794db-c8ef-4b6e-9c04-b2021234f86e	2e19ef47-f3a3-4491-a490-0a22ec4dbe2d	active	2026-04-28 19:52:41.497352+00	2026-03-28 19:52:41.723221+00	2026-03-28 19:52:41.79735+00
9df07e5c-f5e5-4851-86af-7b9c8dfad27e	29baba1c-1732-4565-9b0f-b98b299dbfbb	b13aa63a-8587-4f8f-b14e-bdaf9fd8e3cb	d53794db-c8ef-4b6e-9c04-b2021234f86e	2e19ef47-f3a3-4491-a490-0a22ec4dbe2d	active	2026-04-28 19:52:41.497352+00	2026-03-28 19:52:41.708458+00	2026-03-28 19:52:41.797287+00
a5c69108-15e7-49c1-808d-9341a54c4885	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	b0887ac3-143e-4daa-b255-6579c81fada1	ba2d5a68-91bc-45e1-be8b-5a128033c704	1c0eb33b-e162-4f52-98ec-0290e2964606	active	2026-04-29 13:41:39.757293+00	2026-03-29 13:41:39.988094+00	2026-03-29 13:41:40.018589+00
a74000f3-6809-4849-8501-4ae1e425cfa2	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	b13aa63a-8587-4f8f-b14e-bdaf9fd8e3cb	ba2d5a68-91bc-45e1-be8b-5a128033c704	1c0eb33b-e162-4f52-98ec-0290e2964606	active	2026-04-29 13:41:39.757293+00	2026-03-29 13:41:39.972977+00	2026-03-29 13:41:40.018539+00
e5f370e2-4481-438e-a3d8-7c88fa3d6023	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	55a90fb0-653e-43c9-84e3-bd7b2e5b8098	ba2d5a68-91bc-45e1-be8b-5a128033c704	1c0eb33b-e162-4f52-98ec-0290e2964606	active	2026-04-29 13:41:39.757293+00	2026-03-29 13:41:39.988754+00	2026-03-29 13:41:40.018594+00
7360bc13-58f7-474b-91f9-462498ab6657	4d6b1960-9470-47fd-afeb-9b172fe8b408	b13aa63a-8587-4f8f-b14e-bdaf9fd8e3cb	51345f8e-b501-42e8-aa57-19ea66b6f176	15df5e32-74b2-47a9-8e3b-dbff25458f13	active	2026-04-29 13:55:44.991391+00	2026-03-29 13:55:45.014056+00	2026-03-29 13:55:45.016312+00
b3760611-cb06-49df-9484-dee55502a1cf	4d6b1960-9470-47fd-afeb-9b172fe8b408	55a90fb0-653e-43c9-84e3-bd7b2e5b8098	51345f8e-b501-42e8-aa57-19ea66b6f176	15df5e32-74b2-47a9-8e3b-dbff25458f13	active	2026-04-29 13:55:44.991391+00	2026-03-29 13:55:45.015215+00	2026-03-29 13:55:45.016313+00
bd32dd38-ba6c-4033-9c0f-6497a56de6e8	4d6b1960-9470-47fd-afeb-9b172fe8b408	b0887ac3-143e-4daa-b255-6579c81fada1	51345f8e-b501-42e8-aa57-19ea66b6f176	15df5e32-74b2-47a9-8e3b-dbff25458f13	active	2026-04-29 13:55:44.991391+00	2026-03-29 13:55:45.014618+00	2026-03-29 13:55:45.016313+00
178f8f23-7fae-430d-917d-8512baa24762	1b2dd3e6-38dd-4103-8942-544df818621c	b13aa63a-8587-4f8f-b14e-bdaf9fd8e3cb	236da988-0f98-47a0-b34f-4001df574251	83631f1b-1738-46ce-85b9-6e17e783e1bf	active	2026-04-29 13:56:32.476617+00	2026-03-29 13:56:32.728078+00	2026-03-29 13:56:32.805993+00
7026fbdd-b5c8-49ef-af5c-89e994fd857a	1b2dd3e6-38dd-4103-8942-544df818621c	b0887ac3-143e-4daa-b255-6579c81fada1	236da988-0f98-47a0-b34f-4001df574251	83631f1b-1738-46ce-85b9-6e17e783e1bf	active	2026-04-29 13:56:32.476617+00	2026-03-29 13:56:32.744294+00	2026-03-29 13:56:32.806048+00
78bf133a-1f4c-4c83-8f54-1c9de738f4f9	1b2dd3e6-38dd-4103-8942-544df818621c	55a90fb0-653e-43c9-84e3-bd7b2e5b8098	236da988-0f98-47a0-b34f-4001df574251	83631f1b-1738-46ce-85b9-6e17e783e1bf	active	2026-04-29 13:56:32.476617+00	2026-03-29 13:56:32.745897+00	2026-03-29 13:56:32.806058+00
7e1fe13a-79a3-4ddc-a8b3-cf5abaa8ea60	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	b0887ac3-143e-4daa-b255-6579c81fada1	44a14acc-84d8-4479-ac99-74ea223f21a3	8249abd0-bf6a-4a20-b501-56d9f8464810	active	2026-04-29 13:58:47.420799+00	2026-03-29 13:58:47.705793+00	2026-03-29 13:58:47.771079+00
bb029c44-86da-435d-8296-6716b2c4c573	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	b13aa63a-8587-4f8f-b14e-bdaf9fd8e3cb	44a14acc-84d8-4479-ac99-74ea223f21a3	8249abd0-bf6a-4a20-b501-56d9f8464810	active	2026-04-29 13:58:47.420799+00	2026-03-29 13:58:47.687805+00	2026-03-29 13:58:47.771023+00
eb43955a-a39d-420d-8636-7389f22f67d4	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	55a90fb0-653e-43c9-84e3-bd7b2e5b8098	44a14acc-84d8-4479-ac99-74ea223f21a3	8249abd0-bf6a-4a20-b501-56d9f8464810	active	2026-04-29 13:58:47.420799+00	2026-03-29 13:58:47.707267+00	2026-03-29 13:58:47.771088+00
5748cb90-e5e6-45a4-aa45-d89b00492cf7	01072375-ea4f-41a3-bbc0-eac1b77037d8	b13aa63a-8587-4f8f-b14e-bdaf9fd8e3cb	d88ee0e7-4d47-4bc8-b43a-b79eafe3a28d	c038100b-fb18-4894-abb1-bd9551c34643	active	2026-04-29 14:01:32.35315+00	2026-03-29 14:01:32.621412+00	2026-03-29 14:01:32.700059+00
cadafecd-29f6-4854-9bd7-59a29d3e447b	01072375-ea4f-41a3-bbc0-eac1b77037d8	b0887ac3-143e-4daa-b255-6579c81fada1	d88ee0e7-4d47-4bc8-b43a-b79eafe3a28d	c038100b-fb18-4894-abb1-bd9551c34643	active	2026-04-29 14:01:32.35315+00	2026-03-29 14:01:32.640043+00	2026-03-29 14:01:32.700112+00
eb212d59-3e1e-4b30-8d5e-2ae09ac9e177	01072375-ea4f-41a3-bbc0-eac1b77037d8	55a90fb0-653e-43c9-84e3-bd7b2e5b8098	d88ee0e7-4d47-4bc8-b43a-b79eafe3a28d	c038100b-fb18-4894-abb1-bd9551c34643	active	2026-04-29 14:01:32.35315+00	2026-03-29 14:01:32.641282+00	2026-03-29 14:01:32.700122+00
\.


--
-- Data for Name: downloadable_assets; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.downloadable_assets (id, app_release_id, label, platform, visibility, download_url, checksum, requires_active_license, is_active, created_at, updated_at) FROM stdin;
b13aa63a-8587-4f8f-b14e-bdaf9fd8e3cb	545cf901-6d08-4173-b817-4cdb9fe7eac2	Windows Desktop Installer	windows	portal	https://downloads.loomapos.com/desktop/windows	placeholder-checksum	t	t	2026-03-28 19:50:46.790544+00	2026-03-28 19:50:46.819533+00
b0887ac3-143e-4daa-b255-6579c81fada1	71f332c8-533d-4f50-aedf-2c42d601b76d	Android App	android	portal	https://downloads.loomapos.com/mobile/android	placeholder-checksum	t	t	2026-03-28 19:50:46.824895+00	2026-03-28 19:50:46.826678+00
55a90fb0-653e-43c9-84e3-bd7b2e5b8098	d50a7032-74c0-455c-845e-c0b809ac1bc0	iOS Information	ios	public	https://downloads.loomapos.com/mobile/ios	placeholder-checksum	f	t	2026-03-28 19:50:46.830548+00	2026-03-28 19:50:46.831312+00
\.


--
-- Data for Name: email_notifications; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.email_notifications (id, tenant_id, customer_account_id, event_code, to_email, subject, body_markdown, status, sent_at, created_at, updated_at) FROM stdin;
b548802a-9d39-4fed-9b95-78af6b42d89d	\N	1a40ae98-9470-4d8a-b447-d9089eee0626	registration	demo.owner@loomapos.local	LoomaPOS hesap kaydiniz alindi	Merhaba Demo Owner,\n\nPortal kaydiniz hazir. Satin alma sonrasinda lisans ve indirme erisiminiz ayni hesapta acilacaktir.	sent	2026-03-28 19:51:47.788721+00	2026-03-28 19:51:46.341151+00	2026-03-28 19:51:47.78955+00
eadf5a5b-8561-4c61-9344-0de72d6b9f00	\N	1a40ae98-9470-4d8a-b447-d9089eee0626	email_verification	demo.owner@loomapos.local	LoomaPOS e-posta dogrulamasi	Merhaba Demo Owner,\n\nE-posta dogrulama kodunuz: `N81UPTpE2HpOLOYzVNeNdy0wqGbLs7Z70I_syQVckHo`\nBu kod 48 saat gecerlidir.	sent	2026-03-28 19:51:47.789159+00	2026-03-28 19:51:46.358786+00	2026-03-28 19:51:47.789551+00
0474e4c2-0675-46b3-98e1-9dbb005a817f	29baba1c-1732-4565-9b0f-b98b299dbfbb	1a40ae98-9470-4d8a-b447-d9089eee0626	subscription_activated	demo.owner@loomapos.local	Aboneliginiz aktif	Demo Magaza icin aboneliginiz aktif hale getirildi. Yenileme tarihi: 2026-04-28.	sent	2026-03-28 19:52:42.834415+00	2026-03-28 19:52:41.771968+00	2026-03-28 19:52:42.835072+00
6bc7035c-b80a-4a76-8a7c-af5e0fe111e5	29baba1c-1732-4565-9b0f-b98b299dbfbb	1a40ae98-9470-4d8a-b447-d9089eee0626	invoice_available	demo.owner@loomapos.local	Faturaniz hazir	Fatura no: INV-20260328-6616\nTutar: 2990 TRY	sent	2026-03-28 19:52:42.834643+00	2026-03-28 19:52:41.772626+00	2026-03-28 19:52:42.835073+00
8e98f48c-89a4-4419-94df-a9e296166018	29baba1c-1732-4565-9b0f-b98b299dbfbb	1a40ae98-9470-4d8a-b447-d9089eee0626	license_issued	demo.owner@loomapos.local	Lisansiniz olusturuldu	Lisans anahtari: LMA-EF0EC9-12123E-782344-5310A8\nBitis tarihi: 2026-04-28	sent	2026-03-28 19:52:42.83481+00	2026-03-28 19:52:41.772663+00	2026-03-28 19:52:42.835074+00
b003f495-493f-49f5-a9cb-1540a94fc770	29baba1c-1732-4565-9b0f-b98b299dbfbb	1a40ae98-9470-4d8a-b447-d9089eee0626	purchase_success	demo.owner@loomapos.local	LoomaPOS satin alma isleminiz tamamlandi	Plan: pro\nLisans anahtari: LMA-EF0EC9-12123E-782344-5310A8\nPortal: /portal	sent	2026-03-28 19:52:42.834153+00	2026-03-28 19:52:41.771493+00	2026-03-28 19:52:42.835072+00
68e44fb6-459c-4851-8d41-a2c9dec2c798	\N	0d68f479-53d2-499a-9b19-041da47d9c4d	registration	owner@demo.local	LoomaPOS hesap kaydiniz alindi	Merhaba Demo Owner,\n\nPortal kaydiniz hazir. Satin alma sonrasinda lisans ve indirme erisiminiz ayni hesapta acilacaktir.	sent	2026-03-29 13:38:59.280298+00	2026-03-29 13:38:56.929289+00	2026-03-29 13:38:59.281329+00
b802ba14-2e3b-4aea-99b2-3d11ec6e4c10	\N	0d68f479-53d2-499a-9b19-041da47d9c4d	email_verification	owner@demo.local	LoomaPOS e-posta dogrulamasi	Merhaba Demo Owner,\n\nE-posta dogrulama kodunuz: `pRst7jmZFLjQ4yK4PxVoSEsTiCbTFLccUTBrfMpZElc`\nBu kod 48 saat gecerlidir.	sent	2026-03-29 13:38:59.28098+00	2026-03-29 13:38:56.95825+00	2026-03-29 13:38:59.28133+00
16fdf00d-14f4-4501-a960-4ee7f26c4994	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	0d68f479-53d2-499a-9b19-041da47d9c4d	purchase_success	owner@demo.local	LoomaPOS satin alma isleminiz tamamlandi	Plan: starter\nLisans anahtari: LMA-25D59E-687D2A-894B26-FC8F1D\nPortal: /portal	sent	2026-03-29 13:41:41.653846+00	2026-03-29 13:41:40.003506+00	2026-03-29 13:41:41.664647+00
45f06fcb-c0ba-47d2-ad0f-7995d2a333ac	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	0d68f479-53d2-499a-9b19-041da47d9c4d	invoice_available	owner@demo.local	Faturaniz hazir	Fatura no: INV-20260329-5219\nTutar: 1490 TRY	sent	2026-03-29 13:41:41.654649+00	2026-03-29 13:41:40.004693+00	2026-03-29 13:41:41.664759+00
81aecaae-fcc8-4abf-a6b5-eafe1cdbbad5	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	0d68f479-53d2-499a-9b19-041da47d9c4d	license_issued	owner@demo.local	Lisansiniz olusturuldu	Lisans anahtari: LMA-25D59E-687D2A-894B26-FC8F1D\nBitis tarihi: 2026-04-29	sent	2026-03-29 13:41:41.654841+00	2026-03-29 13:41:40.004733+00	2026-03-29 13:41:41.66476+00
b5717fbb-1d12-4be7-8f3a-2e0afb3874c4	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	0d68f479-53d2-499a-9b19-041da47d9c4d	subscription_activated	owner@demo.local	Aboneliginiz aktif	Demo Magaza icin aboneliginiz aktif hale getirildi. Yenileme tarihi: 2026-04-29.	sent	2026-03-29 13:41:41.654364+00	2026-03-29 13:41:40.003966+00	2026-03-29 13:41:41.664738+00
41606438-be6a-4e2c-b49e-b52a2dbc892c	4d6b1960-9470-47fd-afeb-9b172fe8b408	e1a75aac-d3a3-4d1c-a94c-42bda9e5f4ee	purchase_success	owner2@demo.local	LoomaPOS satin alma isleminiz tamamlandi	Plan: starter\nLisans anahtari: LMA-950CE2-47403E-5F3579-D91484\nPortal: /portal	sent	2026-03-29 13:55:46.986328+00	2026-03-29 13:55:45.015527+00	2026-03-29 13:55:46.987633+00
91e0ee21-ea64-490c-815c-2eb4918cab73	4d6b1960-9470-47fd-afeb-9b172fe8b408	e1a75aac-d3a3-4d1c-a94c-42bda9e5f4ee	subscription_activated	owner2@demo.local	Aboneliginiz aktif	Demo Magaza 2 icin aboneliginiz aktif hale getirildi. Yenileme tarihi: 2026-04-29.	sent	2026-03-29 13:55:46.986652+00	2026-03-29 13:55:45.01559+00	2026-03-29 13:55:46.987635+00
e75bb534-aac0-4aaa-b6bb-8b452e30ea30	4d6b1960-9470-47fd-afeb-9b172fe8b408	e1a75aac-d3a3-4d1c-a94c-42bda9e5f4ee	license_issued	owner2@demo.local	Lisansiniz olusturuldu	Lisans anahtari: LMA-950CE2-47403E-5F3579-D91484\nBitis tarihi: 2026-04-29	sent	2026-03-29 13:55:46.987144+00	2026-03-29 13:55:45.015716+00	2026-03-29 13:55:46.987638+00
ecd8cd9d-141a-4dd7-956d-e7d38aa83b40	4d6b1960-9470-47fd-afeb-9b172fe8b408	e1a75aac-d3a3-4d1c-a94c-42bda9e5f4ee	invoice_available	owner2@demo.local	Faturaniz hazir	Fatura no: INV-20260329-3541\nTutar: 1490 TRY	sent	2026-03-29 13:55:46.986914+00	2026-03-29 13:55:45.015647+00	2026-03-29 13:55:46.987636+00
32313590-ae13-4ecb-935c-82876f652a07	1b2dd3e6-38dd-4103-8942-544df818621c	23237479-241c-4c06-adf7-2036086ea1fe	license_issued	owner3@demo.local	Lisansiniz olusturuldu	Lisans anahtari: LMA-2F28FE-4F7113-6A0998-FC0532\nBitis tarihi: 2026-04-29	sent	2026-03-29 13:56:37.010934+00	2026-03-29 13:56:32.783296+00	2026-03-29 13:56:37.011186+00
6c7849fc-8c46-4fa6-abe6-9680922809c1	1b2dd3e6-38dd-4103-8942-544df818621c	23237479-241c-4c06-adf7-2036086ea1fe	invoice_available	owner3@demo.local	Faturaniz hazir	Fatura no: INV-20260329-3880\nTutar: 1490 TRY	sent	2026-03-29 13:56:37.010782+00	2026-03-29 13:56:32.783232+00	2026-03-29 13:56:37.011186+00
e6fa396b-0d74-41c5-a61d-de421bdb9d08	1b2dd3e6-38dd-4103-8942-544df818621c	23237479-241c-4c06-adf7-2036086ea1fe	purchase_success	owner3@demo.local	LoomaPOS satin alma isleminiz tamamlandi	Plan: starter\nLisans anahtari: LMA-2F28FE-4F7113-6A0998-FC0532\nPortal: /portal	sent	2026-03-29 13:56:37.010346+00	2026-03-29 13:56:32.763313+00	2026-03-29 13:56:37.011185+00
f64e4718-59d4-474e-9587-45ff83809865	1b2dd3e6-38dd-4103-8942-544df818621c	23237479-241c-4c06-adf7-2036086ea1fe	subscription_activated	owner3@demo.local	Aboneliginiz aktif	Demo Magaza 3 icin aboneliginiz aktif hale getirildi. Yenileme tarihi: 2026-04-29.	sent	2026-03-29 13:56:37.010525+00	2026-03-29 13:56:32.782517+00	2026-03-29 13:56:37.011186+00
7a513967-84c0-4211-b7ee-50b7616f26d4	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	973a2c5c-759f-4421-bbd0-9c630af456f5	purchase_success	owner4@demo.local	LoomaPOS satin alma isleminiz tamamlandi	Plan: starter\nLisans anahtari: LMA-440FE5-C1861A-368E14-DE2D23\nPortal: /portal	sent	2026-03-29 13:58:48.912776+00	2026-03-29 13:58:47.726588+00	2026-03-29 13:58:48.914501+00
9df33b49-9316-404f-95ba-76e5f692cd4b	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	973a2c5c-759f-4421-bbd0-9c630af456f5	invoice_available	owner4@demo.local	Faturaniz hazir	Fatura no: INV-20260329-1381\nTutar: 1490 TRY	sent	2026-03-29 13:58:48.913849+00	2026-03-29 13:58:47.74676+00	2026-03-29 13:58:48.914502+00
c4297edd-6ca6-4e7d-80a7-25dff1dba3bd	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	973a2c5c-759f-4421-bbd0-9c630af456f5	subscription_activated	owner4@demo.local	Aboneliginiz aktif	Demo Magaza 4 icin aboneliginiz aktif hale getirildi. Yenileme tarihi: 2026-04-29.	sent	2026-03-29 13:58:48.913356+00	2026-03-29 13:58:47.746006+00	2026-03-29 13:58:48.914502+00
d141c7c4-0894-4c6d-9c88-5fdcd318d54b	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	973a2c5c-759f-4421-bbd0-9c630af456f5	license_issued	owner4@demo.local	Lisansiniz olusturuldu	Lisans anahtari: LMA-440FE5-C1861A-368E14-DE2D23\nBitis tarihi: 2026-04-29	sent	2026-03-29 13:58:48.914093+00	2026-03-29 13:58:47.746812+00	2026-03-29 13:58:48.914503+00
288956ff-9c0b-4d6a-924d-c5f2adfe0e38	01072375-ea4f-41a3-bbc0-eac1b77037d8	f29fe2cd-4fac-442a-8519-6956bfdac35d	invoice_available	owner5@demo.local	Faturaniz hazir	Fatura no: INV-20260329-8966\nTutar: 1490 TRY	sent	2026-03-29 14:01:33.610069+00	2026-03-29 14:01:32.678341+00	2026-03-29 14:01:33.610471+00
a2515a0e-cf6a-4f90-9009-54278dc72699	01072375-ea4f-41a3-bbc0-eac1b77037d8	f29fe2cd-4fac-442a-8519-6956bfdac35d	subscription_activated	owner5@demo.local	Aboneliginiz aktif	Demo Magaza 5 icin aboneliginiz aktif hale getirildi. Yenileme tarihi: 2026-04-29.	sent	2026-03-29 14:01:33.609799+00	2026-03-29 14:01:32.677666+00	2026-03-29 14:01:33.610471+00
f3b99fb6-8f73-4484-9070-2641c4800e81	01072375-ea4f-41a3-bbc0-eac1b77037d8	f29fe2cd-4fac-442a-8519-6956bfdac35d	license_issued	owner5@demo.local	Lisansiniz olusturuldu	Lisans anahtari: LMA-B8EFB9-BCEE6C-E175B8-960788\nBitis tarihi: 2026-04-29	sent	2026-03-29 14:01:33.610247+00	2026-03-29 14:01:32.678406+00	2026-03-29 14:01:33.610471+00
f675a5d2-cdda-417b-a607-f40c60d2eb37	01072375-ea4f-41a3-bbc0-eac1b77037d8	f29fe2cd-4fac-442a-8519-6956bfdac35d	purchase_success	owner5@demo.local	LoomaPOS satin alma isleminiz tamamlandi	Plan: starter\nLisans anahtari: LMA-B8EFB9-BCEE6C-E175B8-960788\nPortal: /portal	sent	2026-03-29 14:01:33.609353+00	2026-03-29 14:01:32.659258+00	2026-03-29 14:01:33.61047+00
\.


--
-- Data for Name: environment_configs; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.environment_configs (id, environment, config_key, value_kind, is_secret_reference, value_preview, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: feature_flags; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.feature_flags (id, code, name, description, is_public, is_active, created_at, updated_at) FROM stdin;
05e94670-d0a0-4631-84f5-cf169f0d8e7e	variant_products	Variant Products	Varyantli urun modulu	t	t	2026-03-28 19:50:46.418302+00	2026-03-28 19:50:46.439023+00
1a2e8e92-4ead-4315-bf94-1de619cb3be5	reporting	Reporting	Yonetici raporlama modulu	t	t	2026-03-28 19:50:46.415356+00	2026-03-28 19:50:46.439022+00
567ea24a-a93d-40e7-b2ec-f8af902706cb	management_dashboard	Management Dashboard	Yonetici dashboard modulu	t	t	2026-03-28 19:50:46.42036+00	2026-03-28 19:50:46.439024+00
6ba12ac7-801c-4072-8615-b7ac8499e9bf	e_invoice	E-Invoice	E-fatura uyumlulugu	t	t	2026-03-28 19:50:46.418967+00	2026-03-28 19:50:46.439024+00
797f6279-74c5-4205-9abf-22f6c7c5e02e	online_collection	Online Collection	Uzak tahsilat entegrasyonu	t	t	2026-03-28 19:50:46.417687+00	2026-03-28 19:50:46.439023+00
835d4758-d1d0-4822-8920-b156e4a098fd	inventory_management	Inventory Management	Stok ve urun hareketi modulu	t	t	2026-03-28 19:50:46.413693+00	2026-03-28 19:50:46.439014+00
a79ebb4d-9873-437d-903a-f9d97ba5b1ae	fiscal_integrations	Fiscal Integrations	Mali cihaz entegrasyonlari	t	t	2026-03-28 19:50:46.419683+00	2026-03-28 19:50:46.439024+00
a859225b-bd6b-44bf-b9cc-8e8b6ab09c33	download_center	Download Center	Uygulama indirme merkezi	t	t	2026-03-28 19:50:46.421132+00	2026-03-28 19:50:46.439024+00
b536b3b3-973a-4d1a-b26c-8951c8f4ff68	branch_management	Branch Management	Cok sube yonetimi	t	t	2026-03-28 19:50:46.417001+00	2026-03-28 19:50:46.439023+00
d07f93a6-ddea-4300-a58a-565ca276f29c	sales_operations	Sales Operations	Desktop ve mobile operasyon modulu	t	t	2026-03-28 19:50:46.350708+00	2026-03-28 19:50:46.438965+00
e346ce3f-88e6-47da-be36-86830e44c41a	staff_management	Staff Management	Rol ve personel modulu	t	t	2026-03-28 19:50:46.416185+00	2026-03-28 19:50:46.439022+00
\.


--
-- Data for Name: incident_records; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.incident_records (id, environment, severity, title, status, category, impact_summary, owner, linked_runbook_code, opened_at, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: incident_timeline_events; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.incident_timeline_events (id, incident_record_id, event_type, summary, metadata_json, created_at) FROM stdin;
\.


--
-- Data for Name: internal_sessions; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.internal_sessions (id, internal_user_id, access_token_hash, refresh_token_hash, expires_at, refresh_expires_at, user_agent, ip_address, revoked_at, created_at, updated_at) FROM stdin;
4b52aff6-4309-4e50-8a7d-39140d355f69	11111111-1111-1111-1111-111111111111	65eccf3ffde84907ec0f7597ae19c75b90647480d04711769aab1c17d32b78c1	b2862974f9c8808a877ee5a32c21dcc1ba7bc1ec341ead7c58bb566986da22f5	2026-03-29 08:03:35.868806+00	2026-04-27 20:03:35.868806+00	curl/8.5.0	127.0.0.1	\N	2026-03-28 20:03:35.869315+00	2026-03-28 20:03:35.892457+00
f2b6accd-b5ab-4818-a86f-0a03bd8b394f	11111111-1111-1111-1111-111111111111	5e12df176d4740a0fac9bcfba08960dda43c178cfb97e0df90e88ec84c371a8f	2510d407c92320d083b187ce487fc0f4bb0204384354f4ff07663cd54278ce7f	2026-03-29 08:35:03.177734+00	2026-04-27 20:35:03.177734+00	curl/8.5.0	127.0.0.1	\N	2026-03-28 20:35:03.177792+00	2026-03-28 20:35:03.178684+00
fc72dae6-55e9-4aec-a4b8-6492b23e4f4b	11111111-1111-1111-1111-111111111111	9d9113e9b463d73d7aa4c23545876d2f46a409a75422ee5c74ab24fae8185fe3	25e866df23785277f4ecf7c017d1003c9f76716ca0f7e937325e8bc34a3747a4	2026-03-29 08:35:28.065826+00	2026-04-27 20:35:28.065826+00	curl/8.5.0	127.0.0.1	\N	2026-03-28 20:35:28.065904+00	2026-03-28 20:35:28.066136+00
2ec05dbb-81e3-4364-910b-224c6b952258	11111111-1111-1111-1111-111111111111	0eefa5f8ee9a7778c17e52f66eb1968f86ef99165d8b8961a2af87cbeb079b8a	8f2750320a7d0585b92518e3d278df002c9244bb3396c42969d84a23185d6fca	2026-03-29 08:36:57.117484+00	2026-04-27 20:36:57.117484+00	curl/8.5.0	127.0.0.1	\N	2026-03-28 20:36:57.117941+00	2026-03-28 20:36:57.16435+00
601882ff-f8d8-4a4d-a070-defcfb5a0c2b	11111111-1111-1111-1111-111111111111	a94bf79979b9317048ae91caa086d159fa26fbac3c9be9c7c90049c94931a4f3	fe74ce6e73f6da1da2bf953ad2cb7d5d7dd99f3bb3f317462c3238c66b433ac4	2026-03-29 08:39:25.104582+00	2026-04-27 20:39:25.104582+00	curl/8.5.0	127.0.0.1	\N	2026-03-28 20:39:25.104644+00	2026-03-28 20:39:25.105827+00
bd53fd98-e9f9-457c-a7c4-3032ab948c4b	11111111-1111-1111-1111-111111111111	e6680609120ea64d8a0f107fc67c692d9829bbac2ab9d9b3fa21c6465bfb82b6	634a2f3e77d49cdfc7bf8457d31ac67eed348cd962e35112954b8c5220ed41f8	2026-03-29 09:00:23.529113+00	2026-04-27 21:00:23.529113+00	node	127.0.0.1	\N	2026-03-28 21:00:23.529192+00	2026-03-28 21:00:23.529597+00
64069c05-a48e-4648-8d1d-679367c89076	11111111-1111-1111-1111-111111111111	0601ce6d0fb3fb89f85cfdf3cd9e1c5280ed41b4e15d049ad6df1528c7e960ae	794206289e2727ee30bee808a795ef1bf8692cf6520f9cae0ed0f520899eb964	2026-03-30 00:52:44.918296+00	2026-04-28 12:52:44.918296+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 12:52:44.918566+00	2026-03-29 12:52:44.943721+00
5a23bea4-c284-4adf-a18a-cbb9051199bf	11111111-1111-1111-1111-111111111111	420d4e6145c508df84480accaf54c49f8f2fc216070594b81e5f0d1fea158ada	f807d621c89affc565610f8da17b3ae43bb26ee23ea5d0559699d437855a313d	2026-03-30 01:12:22.949906+00	2026-04-28 13:12:22.949906+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 13:12:22.949997+00	2026-03-29 13:12:22.950814+00
3844eccf-5b04-4074-af81-da9f69f93197	11111111-1111-1111-1111-111111111111	ab9b40e1cdb643ba045aae467bf92d47c2d6cbb57cc9fc2970c359466f3eb83f	3b11c45fc99fbae64702d30bcfe3d129dc47d4e881c262c6b7bd392c77a5a704	2026-03-30 01:32:02.955788+00	2026-04-28 13:32:02.955788+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 13:32:02.95586+00	2026-03-29 13:32:02.9564+00
80f5b458-3d7e-4750-b57c-92fbae80cdbd	11111111-1111-1111-1111-111111111111	1fef11991dae6274e2fbcbc4357799ef60df4b9633a3af838bbe4e8fb1324579	93881d9c05849acd7b4ca92983fb659b6352d80a27d4a63301beb49c9ccb85eb	2026-03-30 01:33:24.396303+00	2026-04-28 13:33:24.396303+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 13:33:24.396775+00	2026-03-29 13:33:24.452753+00
c57a9bd4-3c37-4f22-8d42-2157d82a1d82	11111111-1111-1111-1111-111111111111	c1eb451fd5f2f9717ee74066b17811dc385b934debdcfe5ad1ce3069dd4d7fdb	81a79a1e50bc5010fe5bc8e743aebc9b6a68b1cc31b2a2d966f5a52a46331c1a	2026-03-30 01:36:17.683284+00	2026-04-28 13:36:17.683284+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 13:36:17.683757+00	2026-03-29 13:36:17.734313+00
aa530711-80fd-4a9e-b653-e4f5457b7da3	11111111-1111-1111-1111-111111111111	b16d9bada0fd95ea96b2c395c81b0b77a2dace772afada0edf78aac33b392c1b	a80abf8f652d139324e1b2e8ec944e0b343266c985b9a3cfd3db28c5e55bedd0	2026-03-30 02:02:08.703419+00	2026-04-28 14:02:08.703419+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 14:02:08.703913+00	2026-03-29 14:02:08.732503+00
85d7eb2c-8cfb-4cbf-afc1-72de09ca7f77	11111111-1111-1111-1111-111111111111	9da8a87b2c44a17a92048aa21770b4c94a0aae1bd328993f9a6b3aa6d5ef61b1	deabea319e4473f1090feaa629003f9319f13f49107dcb1987aff50f47cae4a6	2026-03-30 03:35:12.049151+00	2026-04-28 15:35:12.049151+00	node	127.0.0.1	\N	2026-03-29 15:35:12.049371+00	2026-03-29 15:35:12.050038+00
5164b5f1-7d17-4bda-babf-c51dae255acb	11111111-1111-1111-1111-111111111111	bcc9be8d1583e1deff6e4a914dbb795dfbff7b69417f2a301a0a43dd6839f5bf	25f05a4dbdb5e911a7fd5f841b5bf298377dbdc9bab05bddbbb5f09a1e3e3b6a	2026-03-30 05:20:43.016643+00	2026-04-28 17:20:43.016643+00	node	127.0.0.1	\N	2026-03-29 17:20:43.017339+00	2026-03-29 17:20:43.056709+00
5b428aef-e5dd-405f-980b-9e08aa0b95fa	11111111-1111-1111-1111-111111111111	0fc69c9a83436490840766bcccd9e8855e612f3db612e590fd53fab06462ec46	c4487c8a89f783b93c4254f32631a05f88c6b6967106d877e0d4d4a8de5307d2	2026-03-30 05:34:53.884857+00	2026-04-28 17:34:53.884857+00	node	127.0.0.1	\N	2026-03-29 17:34:53.885291+00	2026-03-29 17:34:53.916166+00
379971cc-c7af-45cd-a85e-08b2b2ce22ad	11111111-1111-1111-1111-111111111111	c31959c89af50ee119654ada119c8f616cb94d952ee068b890a8058759bec7ba	447ba8f24c848fc502069f1d885b6dd73d8538f097b1f9e827d58dfe196d9e3f	2026-03-30 05:36:34.490574+00	2026-04-28 17:36:34.490574+00	node	127.0.0.1	\N	2026-03-29 17:36:34.490615+00	2026-03-29 17:36:34.491027+00
980d1579-5422-4e04-980e-91843f4511d3	11111111-1111-1111-1111-111111111111	b2062e998b4ce8c455d4f9434b48a0873b39e6d7c810313ba35725d5975d8552	d26686faa674adcdd1755cd44fa130f55a38312447ca575b69ff6ff3ee2dc347	2026-03-30 05:49:34.40348+00	2026-04-28 17:49:34.40348+00	node	127.0.0.1	\N	2026-03-29 17:49:34.403518+00	2026-03-29 17:49:34.403851+00
e8d001f6-50b4-458c-b853-4cc599d66455	11111111-1111-1111-1111-111111111111	52aaee5c9a147a612ca39a8e08e85b78643e26d50243dbadf6b554feae16bc01	24cf62ec9d6235c095d09c887604c1897621c15b2c0b6c8ea164d32f4979dc0e	2026-03-30 05:49:44.628255+00	2026-04-28 17:49:44.628255+00	node	127.0.0.1	\N	2026-03-29 17:49:44.628286+00	2026-03-29 17:49:44.62848+00
f16524aa-6853-4b5d-9fe4-d4aae3099272	11111111-1111-1111-1111-111111111111	cad7d318998bd9781486cc9e35df2dd720990d55431b1d0f4fda5e6ec22e6c78	c286856f37c996c08c3faff2d4a1fc448125ccf5f28e816104341f0b6f128c7a	2026-03-30 05:49:48.024848+00	2026-04-28 17:49:48.024848+00	node	127.0.0.1	\N	2026-03-29 17:49:48.02491+00	2026-03-29 17:49:48.025105+00
fa349826-0ca8-43da-b03b-5810e145f1ad	11111111-1111-1111-1111-111111111111	03f1a16ee9c256a33675b83babd2b98be3024b002ccf1c5b15e872849e05655f	91f4e4cb0364082cbef8b33ccfb15941b9b7120f9e366d15ab6991984e89f9ec	2026-03-30 05:49:49.891295+00	2026-04-28 17:49:49.891295+00	node	127.0.0.1	\N	2026-03-29 17:49:49.891353+00	2026-03-29 17:49:49.89153+00
f1ae566f-db7a-4981-91d0-586bf74496c5	11111111-1111-1111-1111-111111111111	eab9014e8a7feaa80378aeb5d4faa58ab60af830cc184a769994c8b044801c0d	e9306d5edc2eb63c7b88d916d8823f3679b439f8dd737f5b17e59feeed56551d	2026-03-30 05:49:51.373435+00	2026-04-28 17:49:51.373435+00	node	127.0.0.1	\N	2026-03-29 17:49:51.37347+00	2026-03-29 17:49:51.373696+00
744a1222-b4b2-4144-b466-47221faa5603	11111111-1111-1111-1111-111111111111	7d2f1bf2d7450de7aa29687099cf3aaf2a0178b283917642836f0c18f34f2352	f84a19248e3b9dfc59b5c229833fbbc13623bebe5706178f22d4229e0c765366	2026-04-01 02:32:41.105053+00	2026-04-30 14:32:41.105053+00	curl/8.5.0	127.0.0.1	\N	2026-03-31 14:32:41.105453+00	2026-03-31 14:32:41.130698+00
59dc7a39-9d51-487f-9aa9-452dd9eb0ab4	11111111-1111-1111-1111-111111111111	07503685debc7870c294466b9848e4a3971f575fcbba12e6b7a951e29c1fb73a	183a7608045ea71b596d08c28d51dd766eaa1f51f80a978b5df522e25f04153d	2026-04-01 02:33:30.152776+00	2026-04-30 14:33:30.152776+00	node	127.0.0.1	\N	2026-03-31 14:33:30.152831+00	2026-03-31 14:33:30.153319+00
53c1e547-a1b6-4c91-8e0a-81662792f518	11111111-1111-1111-1111-111111111111	943694b7be1612f4d91054eafe50a34ca3c97d0ba3be80fce5f1a42c2464ee8f	bcb7fb1e178b4eb4fdd6fbc72bd9e42c4ec8e5d9c7c9337c3d2626537bb91a5a	2026-04-01 02:35:24.879643+00	2026-04-30 14:35:24.879643+00	curl/8.5.0	127.0.0.1	\N	2026-03-31 14:35:24.879717+00	2026-03-31 14:35:24.87993+00
050cc978-cd10-4d8e-80d3-faac0ca41071	11111111-1111-1111-1111-111111111111	b2c7906e672d0aa31828b775e1c3ae862de09083aa795afe1c6c839fe2baa77a	675deaae1d942c35adf5708b1a22e4afb88ffae5ea3512da12ff4ca3da9000f1	2026-04-01 04:11:57.226743+00	2026-04-30 16:11:57.226743+00	node	127.0.0.1	\N	2026-03-31 16:11:57.227275+00	2026-03-31 16:11:57.269296+00
e54d795b-73dd-4a96-bac0-da492a57ad4c	11111111-1111-1111-1111-111111111111	34dec1fc69427cf3973f066273279dd8bacc41bb08987d542576dfbf9780a20f	a7d4b9f26ab07ee10d4d3eb78e3f0b3d1ba1abae7d9f6874c400013d352de69b	2026-04-01 07:12:59.128735+00	2026-04-30 19:12:59.128735+00	curl/8.5.0	127.0.0.1	\N	2026-03-31 19:12:59.128797+00	2026-03-31 19:12:59.129096+00
11aebf48-5b23-4ac9-be91-0adbd357df68	11111111-1111-1111-1111-111111111111	3224a9ffa4906f688eb91ea3469891198eac8820c1495ea5026cd9e4984bec0c	f9c259f28d328859224fa0a1b49f05c60823d23f82d1d812456f9ed31de28dba	2026-04-02 11:46:59.653585+00	2026-05-01 23:46:59.653585+00	curl/8.5.0	127.0.0.1	\N	2026-04-01 23:46:59.654005+00	2026-04-01 23:46:59.687685+00
c358414f-d6e3-4641-a18a-87311cd48451	11111111-1111-1111-1111-111111111111	540cff8c239d36f5c6f846e0a2afadb68b8020d4493b96db54d43f061e130c62	b263872c22429b7988d222a79879fc24ecb28b6f2d2d9328cadb30d5ac5c0a18	2026-04-02 11:50:23.362585+00	2026-05-01 23:50:23.362585+00	curl/8.5.0	127.0.0.1	\N	2026-04-01 23:50:23.362633+00	2026-04-01 23:50:23.363633+00
818be76c-c14e-4a34-879b-eebdf15fd248	11111111-1111-1111-1111-111111111111	ba3d44a7d2077d5e62bff5bdb114b35e1d159e75914518188668c11f9c303158	20ea58b1b030c325d27f27fc71459797d6fe9d8d3d1047b3bd97c8b0cfd392d8	2026-04-02 11:50:32.874709+00	2026-05-01 23:50:32.874709+00	curl/8.5.0	127.0.0.1	\N	2026-04-01 23:50:32.874756+00	2026-04-01 23:50:32.87498+00
ea9f9b54-ad57-4411-bbf3-d505458a136c	11111111-1111-1111-1111-111111111111	f73358e4e3c6be9d80016553255d4e6b2e50f5c4c54adb16aa8fb6a252934c66	d44582cecdfedaf5fa824ac0d64f54127b80519ad953d867efca2aed6954a493	2026-04-02 11:51:13.93432+00	2026-05-01 23:51:13.93432+00	curl/8.5.0	127.0.0.1	\N	2026-04-01 23:51:13.934386+00	2026-04-01 23:51:13.934601+00
\.


--
-- Data for Name: internal_user_roles; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.internal_user_roles (id, internal_user_id, role_code, created_at) FROM stdin;
6c839786-dc8c-4b3a-992b-28db7d7354dc	11111111-1111-1111-1111-111111111111	super_admin	2026-04-01 23:51:05.632654+00
014d3490-27c6-4a0e-adeb-f96932bfa697	11111111-1111-1111-1111-111111111111	sales_manager	2026-04-01 23:51:05.632654+00
8b994786-1084-47a1-b07d-a421f11f1a0e	11111111-1111-1111-1111-111111111111	sales_rep	2026-04-01 23:51:05.632654+00
\.


--
-- Data for Name: internal_users; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.internal_users (id, email, display_name, password_hash, status, require_mfa, last_login_at, created_at, updated_at) FROM stdin;
11111111-1111-1111-1111-111111111111	demo.owner@loomapos.local	LoomaPOS Operations	pbkdf2$120000$eC2sCVsKp/UWRYIkatLIVA==$9pRXV6AUoduSwLyqGvNF+nsmeQXWH/b5JNXK2vfEpE4=	active	f	2026-04-01 23:51:13.93432+00	2026-03-28 19:56:08.199158+00	2026-04-01 23:51:13.934602+00
\.


--
-- Data for Name: invoice_lines; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.invoice_lines (id, tenant_id, invoice_id, description, quantity, unit_amount, tax_amount, total_amount, created_at) FROM stdin;
500eb675-220d-422f-9c88-a41eebf5973f	29baba1c-1732-4565-9b0f-b98b299dbfbb	ac4668ce-3f6d-4b9f-8fc2-16befaadbc04	Pro monthly abonelik	1.00	2990.00	0.00	2990.00	2026-03-28 19:52:41.577745+00
1ee95f4f-c477-428e-86be-fa66a1eec4ad	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	2519d65c-380e-4f6e-8bf6-8afbef759551	Starter monthly abonelik	1.00	1490.00	0.00	1490.00	2026-03-29 13:41:39.843549+00
7cf79d4e-32a8-4c58-87d2-41c572ad6b1a	4d6b1960-9470-47fd-afeb-9b172fe8b408	c9ba9f63-6a8a-44ef-9208-9ab756272696	Starter monthly abonelik	1.00	1490.00	0.00	1490.00	2026-03-29 13:55:44.999901+00
9cbf341a-301e-4dc6-b69c-935e84ca617e	1b2dd3e6-38dd-4103-8942-544df818621c	99d71410-12d3-441c-8c0d-f8f3fb36a800	Starter monthly abonelik	1.00	1490.00	0.00	1490.00	2026-03-29 13:56:32.580888+00
979666c0-eb69-4655-98f4-f37b28a5af38	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	2b3a44e6-f915-42a0-a765-93e815998612	Starter monthly abonelik	1.00	1490.00	0.00	1490.00	2026-03-29 13:58:47.529873+00
28d90a70-4518-409b-8f35-5155f955d708	01072375-ea4f-41a3-bbc0-eac1b77037d8	fdb8bfb2-1bf5-499d-8ff1-444484ed988c	Starter monthly abonelik	1.00	1490.00	0.00	1490.00	2026-03-29 14:01:32.459647+00
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.invoices (id, tenant_id, subscription_id, invoice_no, total, currency, status, issued_at, paid_at, created_at, billing_profile_id, description, subtotal, tax_amount, due_at, billing_period_start, billing_period_end, provider_invoice_reference, pdf_url, updated_at) FROM stdin;
ac4668ce-3f6d-4b9f-8fc2-16befaadbc04	29baba1c-1732-4565-9b0f-b98b299dbfbb	d53794db-c8ef-4b6e-9c04-b2021234f86e	INV-20260328-6616	2990.00	TRY	paid	2026-03-28 19:52:41.497352+00	2026-03-28 19:52:41.497352+00	2026-03-28 19:52:41.536425+00	56726ae9-0e54-443e-8a28-800ae2a2190f	Pro monthly abonelik	2990.00	0.00	2026-03-28 19:52:41.497352+00	2026-03-28 19:52:41.497352+00	2026-04-28 19:52:41.497352+00	mock-payment-700b8dc0d67d4f1abd9f8477c5586d5c	/commerce/portal/billing/ac4668ce-3f6d-4b9f-8fc2-16befaadbc04/pdf	2026-03-28 19:52:41.573542+00
2519d65c-380e-4f6e-8bf6-8afbef759551	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	ba2d5a68-91bc-45e1-be8b-5a128033c704	INV-20260329-5219	1490.00	TRY	paid	2026-03-29 13:41:39.757293+00	2026-03-29 13:41:39.757293+00	2026-03-29 13:41:39.802617+00	e2459fca-fe48-49c0-9b1e-0f622bbb8e4a	Starter monthly abonelik	1490.00	0.00	2026-03-29 13:41:39.757293+00	2026-03-29 13:41:39.757293+00	2026-04-29 13:41:39.757293+00	mock-payment-f0516460da1f459c839297a5105a95f6	/commerce/portal/billing/2519d65c-380e-4f6e-8bf6-8afbef759551/pdf	2026-03-29 13:41:39.839646+00
c9ba9f63-6a8a-44ef-9208-9ab756272696	4d6b1960-9470-47fd-afeb-9b172fe8b408	51345f8e-b501-42e8-aa57-19ea66b6f176	INV-20260329-3541	1490.00	TRY	paid	2026-03-29 13:55:44.991391+00	2026-03-29 13:55:44.991391+00	2026-03-29 13:55:44.994488+00	48952a74-d5d9-4358-a3a2-1663b985f085	Starter monthly abonelik	1490.00	0.00	2026-03-29 13:55:44.991391+00	2026-03-29 13:55:44.991391+00	2026-04-29 13:55:44.991391+00	mock-payment-e09a2060084d46469ea22a7f0bed41db	/commerce/portal/billing/c9ba9f63-6a8a-44ef-9208-9ab756272696/pdf	2026-03-29 13:55:44.995034+00
99d71410-12d3-441c-8c0d-f8f3fb36a800	1b2dd3e6-38dd-4103-8942-544df818621c	236da988-0f98-47a0-b34f-4001df574251	INV-20260329-3880	1490.00	TRY	paid	2026-03-29 13:56:32.476617+00	2026-03-29 13:56:32.476617+00	2026-03-29 13:56:32.528857+00	f03f4ebb-e3d6-4e17-a8c3-c6b366bd5d8f	Starter monthly abonelik	1490.00	0.00	2026-03-29 13:56:32.476617+00	2026-03-29 13:56:32.476617+00	2026-04-29 13:56:32.476617+00	mock-payment-9b1603a83e2446f6bc05b450d729e785	/commerce/portal/billing/99d71410-12d3-441c-8c0d-f8f3fb36a800/pdf	2026-03-29 13:56:32.574843+00
2b3a44e6-f915-42a0-a765-93e815998612	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	44a14acc-84d8-4479-ac99-74ea223f21a3	INV-20260329-1381	1490.00	TRY	paid	2026-03-29 13:58:47.420799+00	2026-03-29 13:58:47.420799+00	2026-03-29 13:58:47.477343+00	2dc070d7-a389-4b1e-9867-428d5b72f015	Starter monthly abonelik	1490.00	0.00	2026-03-29 13:58:47.420799+00	2026-03-29 13:58:47.420799+00	2026-04-29 13:58:47.420799+00	mock-payment-d21480dacd094786960827b4774ff935	/commerce/portal/billing/2b3a44e6-f915-42a0-a765-93e815998612/pdf	2026-03-29 13:58:47.525513+00
fdb8bfb2-1bf5-499d-8ff1-444484ed988c	01072375-ea4f-41a3-bbc0-eac1b77037d8	d88ee0e7-4d47-4bc8-b43a-b79eafe3a28d	INV-20260329-8966	1490.00	TRY	paid	2026-03-29 14:01:32.35315+00	2026-03-29 14:01:32.35315+00	2026-03-29 14:01:32.408445+00	eebf784c-6722-4560-8b27-c5f7b8110369	Starter monthly abonelik	1490.00	0.00	2026-03-29 14:01:32.35315+00	2026-03-29 14:01:32.35315+00	2026-04-29 14:01:32.35315+00	mock-payment-61f7b77f7301434690b579df284136e0	/commerce/portal/billing/fdb8bfb2-1bf5-499d-8ff1-444484ed988c/pdf	2026-03-29 14:01:32.455316+00
\.


--
-- Data for Name: license_events; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.license_events (id, tenant_id, license_id, event_type, payload_json, created_at) FROM stdin;
1	29baba1c-1732-4565-9b0f-b98b299dbfbb	2e19ef47-f3a3-4491-a490-0a22ec4dbe2d	LICENSE_ISSUED	{"LicenseKey":"LMA-EF0EC9-12123E-782344-5310A8","Code":"pro","featureFlags":["variant_products","reporting","e_invoice","online_collection","inventory_management","download_center","branch_management","sales_operations","staff_management"]}	2026-03-28 19:52:41.497352+00
2	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	1c0eb33b-e162-4f52-98ec-0290e2964606	LICENSE_ISSUED	{"LicenseKey":"LMA-25D59E-687D2A-894B26-FC8F1D","Code":"starter","featureFlags":["reporting","inventory_management","download_center","sales_operations"]}	2026-03-29 13:41:39.757293+00
3	4d6b1960-9470-47fd-afeb-9b172fe8b408	15df5e32-74b2-47a9-8e3b-dbff25458f13	LICENSE_ISSUED	{"LicenseKey":"LMA-950CE2-47403E-5F3579-D91484","Code":"starter","featureFlags":["reporting","inventory_management","download_center","sales_operations"]}	2026-03-29 13:55:44.991391+00
4	1b2dd3e6-38dd-4103-8942-544df818621c	83631f1b-1738-46ce-85b9-6e17e783e1bf	LICENSE_ISSUED	{"LicenseKey":"LMA-2F28FE-4F7113-6A0998-FC0532","Code":"starter","featureFlags":["reporting","inventory_management","download_center","sales_operations"]}	2026-03-29 13:56:32.476617+00
5	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	8249abd0-bf6a-4a20-b501-56d9f8464810	LICENSE_ISSUED	{"LicenseKey":"LMA-440FE5-C1861A-368E14-DE2D23","Code":"starter","featureFlags":["reporting","inventory_management","download_center","sales_operations"]}	2026-03-29 13:58:47.420799+00
6	01072375-ea4f-41a3-bbc0-eac1b77037d8	c038100b-fb18-4894-abb1-bd9551c34643	LICENSE_ISSUED	{"LicenseKey":"LMA-B8EFB9-BCEE6C-E175B8-960788","Code":"starter","featureFlags":["reporting","inventory_management","download_center","sales_operations"]}	2026-03-29 14:01:32.35315+00
\.


--
-- Data for Name: licenses; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.licenses (id, tenant_id, subscription_id, plan_code, license_token, features_json, device_limit, issued_at, expires_at, grace_days, status, created_at, license_key, signature) FROM stdin;
2e19ef47-f3a3-4491-a490-0a22ec4dbe2d	29baba1c-1732-4565-9b0f-b98b299dbfbb	d53794db-c8ef-4b6e-9c04-b2021234f86e	pro	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRfaWQiOiIyOWJhYmExYy0xNzMyLTQ1NjUtOWIwZi1iOThiMjk5ZGJmYmIiLCJzdWJzY3JpcHRpb25faWQiOiJkNTM3OTRkYi1jOGVmLTRiNmUtOWMwNC1iMjAyMTIzNGY4NmUiLCJwbGFuX2NvZGUiOiJwcm8iLCJkZXZpY2VfbGltaXQiOiI1IiwiZmVhdHVyZV9mbGFncyI6IltcInZhcmlhbnRfcHJvZHVjdHNcIixcInJlcG9ydGluZ1wiLFwiZV9pbnZvaWNlXCIsXCJvbmxpbmVfY29sbGVjdGlvblwiLFwiaW52ZW50b3J5X21hbmFnZW1lbnRcIixcImRvd25sb2FkX2NlbnRlclwiLFwiYnJhbmNoX21hbmFnZW1lbnRcIixcInNhbGVzX29wZXJhdGlvbnNcIixcInN0YWZmX21hbmFnZW1lbnRcIl0iLCJsaWNlbnNlX2tleSI6IkxNQS1FRjBFQzktMTIxMjNFLTc4MjM0NC01MzEwQTgiLCJwYXlsb2FkIjoie1widGVuYW50SWRcIjpcIjI5YmFiYTFjLTE3MzItNDU2NS05YjBmLWI5OGIyOTlkYmZiYlwiLFwic3Vic2NyaXB0aW9uSWRcIjpcImQ1Mzc5NGRiLWM4ZWYtNGI2ZS05YzA0LWIyMDIxMjM0Zjg2ZVwiLFwicGxhbkNvZGVcIjpcInByb1wiLFwiZGV2aWNlTGltaXRcIjo1LFwiZmVhdHVyZUZsYWdzXCI6W1widmFyaWFudF9wcm9kdWN0c1wiLFwicmVwb3J0aW5nXCIsXCJlX2ludm9pY2VcIixcIm9ubGluZV9jb2xsZWN0aW9uXCIsXCJpbnZlbnRvcnlfbWFuYWdlbWVudFwiLFwiZG93bmxvYWRfY2VudGVyXCIsXCJicmFuY2hfbWFuYWdlbWVudFwiLFwic2FsZXNfb3BlcmF0aW9uc1wiLFwic3RhZmZfbWFuYWdlbWVudFwiXSxcImlzc3VlZEF0XCI6XCIyMDI2LTAzLTI4VDE5OjUyOjQxLjQ5NzM1MjMrMDA6MDBcIixcImV4cGlyZXNBdFwiOlwiMjAyNi0wNC0yOFQxOTo1Mjo0MS40OTczNTIzKzAwOjAwXCIsXCJsaWNlbnNlS2V5XCI6XCJMTUEtRUYwRUM5LTEyMTIzRS03ODIzNDQtNTMxMEE4XCJ9IiwibmJmIjoxNzc0NzI3NTAxLCJleHAiOjE3Nzc0MDU5NjEsImlzcyI6Imxvb21hcG9zLWFwaSIsImF1ZCI6Imxvb21hcG9zLWNsaWVudHMifQ.kBteBwfTX6dCilpHP5BdF7FkC5DqgqIHU4Fo590CxCA	["variant_products","reporting","e_invoice","online_collection","inventory_management","download_center","branch_management","sales_operations","staff_management"]	5	2026-03-28 19:52:41.497352+00	2026-04-28 19:52:41.497352+00	7	active	2026-03-28 19:52:41.651672+00	LMA-EF0EC9-12123E-782344-5310A8	99bf12506dd9ec9ca0ab84315a4bd33a8943372aca7e20ef7235ead099392922
1c0eb33b-e162-4f52-98ec-0290e2964606	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	ba2d5a68-91bc-45e1-be8b-5a128033c704	starter	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRfaWQiOiIwNDI4MmM2Zi01YWZkLTRjYzktOTExZS1hMGE0ZThmZGI4ZDIiLCJzdWJzY3JpcHRpb25faWQiOiJiYTJkNWE2OC05MWJjLTQ1ZTEtYmU4Yi01YTEyODAzM2M3MDQiLCJwbGFuX2NvZGUiOiJzdGFydGVyIiwiZGV2aWNlX2xpbWl0IjoiMSIsImZlYXR1cmVfZmxhZ3MiOiJbXCJyZXBvcnRpbmdcIixcImludmVudG9yeV9tYW5hZ2VtZW50XCIsXCJkb3dubG9hZF9jZW50ZXJcIixcInNhbGVzX29wZXJhdGlvbnNcIl0iLCJsaWNlbnNlX2tleSI6IkxNQS0yNUQ1OUUtNjg3RDJBLTg5NEIyNi1GQzhGMUQiLCJwYXlsb2FkIjoie1widGVuYW50SWRcIjpcIjA0MjgyYzZmLTVhZmQtNGNjOS05MTFlLWEwYTRlOGZkYjhkMlwiLFwic3Vic2NyaXB0aW9uSWRcIjpcImJhMmQ1YTY4LTkxYmMtNDVlMS1iZThiLTVhMTI4MDMzYzcwNFwiLFwicGxhbkNvZGVcIjpcInN0YXJ0ZXJcIixcImRldmljZUxpbWl0XCI6MSxcImZlYXR1cmVGbGFnc1wiOltcInJlcG9ydGluZ1wiLFwiaW52ZW50b3J5X21hbmFnZW1lbnRcIixcImRvd25sb2FkX2NlbnRlclwiLFwic2FsZXNfb3BlcmF0aW9uc1wiXSxcImlzc3VlZEF0XCI6XCIyMDI2LTAzLTI5VDEzOjQxOjM5Ljc1NzI5MzkrMDA6MDBcIixcImV4cGlyZXNBdFwiOlwiMjAyNi0wNC0yOVQxMzo0MTozOS43NTcyOTM5KzAwOjAwXCIsXCJsaWNlbnNlS2V5XCI6XCJMTUEtMjVENTlFLTY4N0QyQS04OTRCMjYtRkM4RjFEXCJ9IiwibmJmIjoxNzc0NzkxNjM5LCJleHAiOjE3Nzc0NzAwOTksImlzcyI6Imxvb21hcG9zLWFwaSIsImF1ZCI6Imxvb21hcG9zLWNsaWVudHMifQ.WOCaYA3lT14VG9P2aIa6g_4iScUKOAcbdo7dxzkagYs	["reporting","inventory_management","download_center","sales_operations"]	1	2026-03-29 13:41:39.757293+00	2026-04-29 13:41:39.757293+00	7	active	2026-03-29 13:41:39.913078+00	LMA-25D59E-687D2A-894B26-FC8F1D	8580676d49fa9c36ce877360ec2832edf108cc5b0b8e9bba91593fed128c064e
15df5e32-74b2-47a9-8e3b-dbff25458f13	4d6b1960-9470-47fd-afeb-9b172fe8b408	51345f8e-b501-42e8-aa57-19ea66b6f176	starter	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRfaWQiOiI0ZDZiMTk2MC05NDcwLTQ3ZmQtYWZlYi05YjE3MmZlOGI0MDgiLCJzdWJzY3JpcHRpb25faWQiOiI1MTM0NWY4ZS1iNTAxLTQyZTgtYWE1Ny0xOWVhNjZiNmYxNzYiLCJwbGFuX2NvZGUiOiJzdGFydGVyIiwiZGV2aWNlX2xpbWl0IjoiMSIsImZlYXR1cmVfZmxhZ3MiOiJbXCJyZXBvcnRpbmdcIixcImludmVudG9yeV9tYW5hZ2VtZW50XCIsXCJkb3dubG9hZF9jZW50ZXJcIixcInNhbGVzX29wZXJhdGlvbnNcIl0iLCJsaWNlbnNlX2tleSI6IkxNQS05NTBDRTItNDc0MDNFLTVGMzU3OS1EOTE0ODQiLCJwYXlsb2FkIjoie1widGVuYW50SWRcIjpcIjRkNmIxOTYwLTk0NzAtNDdmZC1hZmViLTliMTcyZmU4YjQwOFwiLFwic3Vic2NyaXB0aW9uSWRcIjpcIjUxMzQ1ZjhlLWI1MDEtNDJlOC1hYTU3LTE5ZWE2NmI2ZjE3NlwiLFwicGxhbkNvZGVcIjpcInN0YXJ0ZXJcIixcImRldmljZUxpbWl0XCI6MSxcImZlYXR1cmVGbGFnc1wiOltcInJlcG9ydGluZ1wiLFwiaW52ZW50b3J5X21hbmFnZW1lbnRcIixcImRvd25sb2FkX2NlbnRlclwiLFwic2FsZXNfb3BlcmF0aW9uc1wiXSxcImlzc3VlZEF0XCI6XCIyMDI2LTAzLTI5VDEzOjU1OjQ0Ljk5MTM5MTUrMDA6MDBcIixcImV4cGlyZXNBdFwiOlwiMjAyNi0wNC0yOVQxMzo1NTo0NC45OTEzOTE1KzAwOjAwXCIsXCJsaWNlbnNlS2V5XCI6XCJMTUEtOTUwQ0UyLTQ3NDAzRS01RjM1NzktRDkxNDg0XCJ9IiwibmJmIjoxNzc0NzkyNDg0LCJleHAiOjE3Nzc0NzA5NDQsImlzcyI6Imxvb21hcG9zLWFwaSIsImF1ZCI6Imxvb21hcG9zLWNsaWVudHMifQ.h2kv4ULld_yx3-UAHmLJydWhUFqoiHwwrrvOaLaC0Cw	["reporting","inventory_management","download_center","sales_operations"]	1	2026-03-29 13:55:44.991391+00	2026-04-29 13:55:44.991391+00	7	active	2026-03-29 13:55:45.007634+00	LMA-950CE2-47403E-5F3579-D91484	8ef32a0aa8241ba08a1c0cac213f8cbd775aaf333f76bc8f320f2c1e08ed2c85
83631f1b-1738-46ce-85b9-6e17e783e1bf	1b2dd3e6-38dd-4103-8942-544df818621c	236da988-0f98-47a0-b34f-4001df574251	starter	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRfaWQiOiIxYjJkZDNlNi0zOGRkLTQxMDMtODk0Mi01NDRkZjgxODYyMWMiLCJzdWJzY3JpcHRpb25faWQiOiIyMzZkYTk4OC0wZjk4LTQ3YTAtYjM0Zi00MDAxZGY1NzQyNTEiLCJwbGFuX2NvZGUiOiJzdGFydGVyIiwiZGV2aWNlX2xpbWl0IjoiMSIsImZlYXR1cmVfZmxhZ3MiOiJbXCJyZXBvcnRpbmdcIixcImludmVudG9yeV9tYW5hZ2VtZW50XCIsXCJkb3dubG9hZF9jZW50ZXJcIixcInNhbGVzX29wZXJhdGlvbnNcIl0iLCJsaWNlbnNlX2tleSI6IkxNQS0yRjI4RkUtNEY3MTEzLTZBMDk5OC1GQzA1MzIiLCJwYXlsb2FkIjoie1widGVuYW50SWRcIjpcIjFiMmRkM2U2LTM4ZGQtNDEwMy04OTQyLTU0NGRmODE4NjIxY1wiLFwic3Vic2NyaXB0aW9uSWRcIjpcIjIzNmRhOTg4LTBmOTgtNDdhMC1iMzRmLTQwMDFkZjU3NDI1MVwiLFwicGxhbkNvZGVcIjpcInN0YXJ0ZXJcIixcImRldmljZUxpbWl0XCI6MSxcImZlYXR1cmVGbGFnc1wiOltcInJlcG9ydGluZ1wiLFwiaW52ZW50b3J5X21hbmFnZW1lbnRcIixcImRvd25sb2FkX2NlbnRlclwiLFwic2FsZXNfb3BlcmF0aW9uc1wiXSxcImlzc3VlZEF0XCI6XCIyMDI2LTAzLTI5VDEzOjU2OjMyLjQ3NjYxNzgrMDA6MDBcIixcImV4cGlyZXNBdFwiOlwiMjAyNi0wNC0yOVQxMzo1NjozMi40NzY2MTc4KzAwOjAwXCIsXCJsaWNlbnNlS2V5XCI6XCJMTUEtMkYyOEZFLTRGNzExMy02QTA5OTgtRkMwNTMyXCJ9IiwibmJmIjoxNzc0NzkyNTMyLCJleHAiOjE3Nzc0NzA5OTIsImlzcyI6Imxvb21hcG9zLWFwaSIsImF1ZCI6Imxvb21hcG9zLWNsaWVudHMifQ.J1GQWy8HrwKixnM1vuJ2vf9gfpYaXYMArKo0rmmcIU8	["reporting","inventory_management","download_center","sales_operations"]	1	2026-03-29 13:56:32.476617+00	2026-04-29 13:56:32.476617+00	7	active	2026-03-29 13:56:32.663879+00	LMA-2F28FE-4F7113-6A0998-FC0532	63433fd47941b94723504b264f90515274164393fb6df078af3733acc3132a54
8249abd0-bf6a-4a20-b501-56d9f8464810	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	44a14acc-84d8-4479-ac99-74ea223f21a3	starter	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRfaWQiOiJmZjg5ODBmNC0zYzBiLTQwZDYtYWQzYi1lMzIxOGRlODJhOGEiLCJzdWJzY3JpcHRpb25faWQiOiI0NGExNGFjYy04NGQ4LTQ0NzktYWM5OS03NGVhMjIzZjIxYTMiLCJwbGFuX2NvZGUiOiJzdGFydGVyIiwiZGV2aWNlX2xpbWl0IjoiMSIsImZlYXR1cmVfZmxhZ3MiOiJbXCJyZXBvcnRpbmdcIixcImludmVudG9yeV9tYW5hZ2VtZW50XCIsXCJkb3dubG9hZF9jZW50ZXJcIixcInNhbGVzX29wZXJhdGlvbnNcIl0iLCJsaWNlbnNlX2tleSI6IkxNQS00NDBGRTUtQzE4NjFBLTM2OEUxNC1ERTJEMjMiLCJwYXlsb2FkIjoie1widGVuYW50SWRcIjpcImZmODk4MGY0LTNjMGItNDBkNi1hZDNiLWUzMjE4ZGU4MmE4YVwiLFwic3Vic2NyaXB0aW9uSWRcIjpcIjQ0YTE0YWNjLTg0ZDgtNDQ3OS1hYzk5LTc0ZWEyMjNmMjFhM1wiLFwicGxhbkNvZGVcIjpcInN0YXJ0ZXJcIixcImRldmljZUxpbWl0XCI6MSxcImZlYXR1cmVGbGFnc1wiOltcInJlcG9ydGluZ1wiLFwiaW52ZW50b3J5X21hbmFnZW1lbnRcIixcImRvd25sb2FkX2NlbnRlclwiLFwic2FsZXNfb3BlcmF0aW9uc1wiXSxcImlzc3VlZEF0XCI6XCIyMDI2LTAzLTI5VDEzOjU4OjQ3LjQyMDc5OTgrMDA6MDBcIixcImV4cGlyZXNBdFwiOlwiMjAyNi0wNC0yOVQxMzo1ODo0Ny40MjA3OTk4KzAwOjAwXCIsXCJsaWNlbnNlS2V5XCI6XCJMTUEtNDQwRkU1LUMxODYxQS0zNjhFMTQtREUyRDIzXCJ9IiwibmJmIjoxNzc0NzkyNjY3LCJleHAiOjE3Nzc0NzExMjcsImlzcyI6Imxvb21hcG9zLWFwaSIsImF1ZCI6Imxvb21hcG9zLWNsaWVudHMifQ.xHRfOT04LA5R6KWLFyItrVprw63CMADuVSR67OV2ZbU	["reporting","inventory_management","download_center","sales_operations"]	1	2026-03-29 13:58:47.420799+00	2026-04-29 13:58:47.420799+00	7	active	2026-03-29 13:58:47.619914+00	LMA-440FE5-C1861A-368E14-DE2D23	6cad922d4a689c526970f9540ab74586f468072c39a1d71380559227514734bb
c038100b-fb18-4894-abb1-bd9551c34643	01072375-ea4f-41a3-bbc0-eac1b77037d8	d88ee0e7-4d47-4bc8-b43a-b79eafe3a28d	starter	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0ZW5hbnRfaWQiOiIwMTA3MjM3NS1lYTRmLTQxYTMtYmJjMC1lYWMxYjc3MDM3ZDgiLCJzdWJzY3JpcHRpb25faWQiOiJkODhlZTBlNy00ZDQ3LTRiYzgtYjQzYS1iNzllYWZlM2EyOGQiLCJwbGFuX2NvZGUiOiJzdGFydGVyIiwiZGV2aWNlX2xpbWl0IjoiMSIsImZlYXR1cmVfZmxhZ3MiOiJbXCJyZXBvcnRpbmdcIixcImludmVudG9yeV9tYW5hZ2VtZW50XCIsXCJkb3dubG9hZF9jZW50ZXJcIixcInNhbGVzX29wZXJhdGlvbnNcIl0iLCJsaWNlbnNlX2tleSI6IkxNQS1COEVGQjktQkNFRTZDLUUxNzVCOC05NjA3ODgiLCJwYXlsb2FkIjoie1widGVuYW50SWRcIjpcIjAxMDcyMzc1LWVhNGYtNDFhMy1iYmMwLWVhYzFiNzcwMzdkOFwiLFwic3Vic2NyaXB0aW9uSWRcIjpcImQ4OGVlMGU3LTRkNDctNGJjOC1iNDNhLWI3OWVhZmUzYTI4ZFwiLFwicGxhbkNvZGVcIjpcInN0YXJ0ZXJcIixcImRldmljZUxpbWl0XCI6MSxcImZlYXR1cmVGbGFnc1wiOltcInJlcG9ydGluZ1wiLFwiaW52ZW50b3J5X21hbmFnZW1lbnRcIixcImRvd25sb2FkX2NlbnRlclwiLFwic2FsZXNfb3BlcmF0aW9uc1wiXSxcImlzc3VlZEF0XCI6XCIyMDI2LTAzLTI5VDE0OjAxOjMyLjM1MzE1MDUrMDA6MDBcIixcImV4cGlyZXNBdFwiOlwiMjAyNi0wNC0yOVQxNDowMTozMi4zNTMxNTA1KzAwOjAwXCIsXCJsaWNlbnNlS2V5XCI6XCJMTUEtQjhFRkI5LUJDRUU2Qy1FMTc1QjgtOTYwNzg4XCJ9IiwibmJmIjoxNzc0NzkyODMyLCJleHAiOjE3Nzc0NzEyOTIsImlzcyI6Imxvb21hcG9zLWFwaSIsImF1ZCI6Imxvb21hcG9zLWNsaWVudHMifQ.libi4Xo2U68skGa5zZXgy4wDOdnf8FTdFeNDiyJPazQ	["reporting","inventory_management","download_center","sales_operations"]	1	2026-03-29 14:01:32.35315+00	2026-04-29 14:01:32.35315+00	7	active	2026-03-29 14:01:32.553783+00	LMA-B8EFB9-BCEE6C-E175B8-960788	1f831f945c20d36ee5c6c68047cd14d64bfa08ccd621455799709ba74f0d733a
\.


--
-- Data for Name: migration_runs; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.migration_runs (id, environment, migration_name, status, verification_summary, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: ops_audit_logs; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.ops_audit_logs (id, actor_email, action, target_type, target_id, reason, metadata_json, created_at) FROM stdin;
\.


--
-- Data for Name: payment_attempts; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.payment_attempts (id, checkout_session_id, payment_transaction_id, provider, status, failure_reason, metadata_json, attempted_at, created_at) FROM stdin;
dfbf8d7d-f7bf-4395-b808-8be212dbec98	700b8dc0-d67d-4f1a-bd9f-8477c5586d5c	\N	mock	created	\N	{"Code":"pro","billingPeriod":"monthly"}	2026-03-28 19:52:41.203042+00	2026-03-28 19:52:41.203042+00
cc271eb4-1127-45f9-b078-3454dcd2e74b	f0516460-da1f-459c-8392-97a5105a95f6	\N	mock	created	\N	{"Code":"starter","billingPeriod":"monthly"}	2026-03-29 13:41:39.507998+00	2026-03-29 13:41:39.507998+00
e188da3c-9a35-4874-9bb8-25f2c35e64c3	e09a2060-084d-4646-9ea2-2a7f0bed41db	\N	mock	created	\N	{"Code":"starter","billingPeriod":"monthly"}	2026-03-29 13:55:44.932335+00	2026-03-29 13:55:44.932335+00
4daa455b-f6c4-42c4-977a-42cb3f96330b	9b1603a8-3e24-46f6-bc05-b450d729e785	\N	mock	created	\N	{"Code":"starter","billingPeriod":"monthly"}	2026-03-29 13:56:32.111736+00	2026-03-29 13:56:32.111736+00
ce0c8ea4-73e7-4648-9e50-1b5fb3a81ffa	d21480da-cd09-4786-9608-27b4774ff935	\N	mock	created	\N	{"Code":"starter","billingPeriod":"monthly"}	2026-03-29 13:58:47.057489+00	2026-03-29 13:58:47.057489+00
f0bca4e7-a525-42ba-9cae-4d8dfd85a5e6	61f7b77f-7301-4346-90b5-79df284136e0	\N	mock	created	\N	{"Code":"starter","billingPeriod":"monthly"}	2026-03-29 14:01:31.985604+00	2026-03-29 14:01:31.985604+00
5640409f-e227-4b4b-8c12-ec80f8e564a5	aa5a255b-5d42-45b5-95b9-6cd0091aee99	\N	mock	created	\N	{"Code":"starter","billingPeriod":"monthly"}	2026-03-31 14:29:35.572631+00	2026-03-31 14:29:35.572631+00
67400f9a-fd71-474f-b30e-01995a4e68ba	3e281673-9653-4661-8c57-f6dfd2f1285b	\N	mock	created	\N	{"Code":"starter","billingPeriod":"monthly"}	2026-03-31 14:29:47.54839+00	2026-03-31 14:29:47.54839+00
\.


--
-- Data for Name: payment_transactions; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.payment_transactions (id, tenant_id, subscription_id, invoice_id, checkout_session_id, provider, provider_payment_id, provider_customer_reference, amount, tax_amount, currency, status, payment_method_summary, metadata_json, paid_at, created_at, updated_at) FROM stdin;
8dc29595-933e-41cb-8556-0b6e51834f7f	29baba1c-1732-4565-9b0f-b98b299dbfbb	d53794db-c8ef-4b6e-9c04-b2021234f86e	ac4668ce-3f6d-4b9f-8fc2-16befaadbc04	700b8dc0-d67d-4f1a-bd9f-8477c5586d5c	mock	mock-payment-700b8dc0d67d4f1abd9f8477c5586d5c	mock-customer-c7d11688	2990.00	0.00	TRY	paid	card	{"checkoutSessionId":"700b8dc0-d67d-4f1a-bd9f-8477c5586d5c","InvoiceNo":"INV-20260328-6616"}	2026-03-28 19:52:41.497352+00	2026-03-28 19:52:41.59124+00	2026-03-28 19:52:41.627495+00
1f621253-d6ec-4b1b-849f-94e6368da7b5	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	ba2d5a68-91bc-45e1-be8b-5a128033c704	2519d65c-380e-4f6e-8bf6-8afbef759551	f0516460-da1f-459c-8392-97a5105a95f6	mock	mock-payment-f0516460da1f459c839297a5105a95f6	mock-customer-5876af22	1490.00	0.00	TRY	paid	card	{"checkoutSessionId":"f0516460-da1f-459c-8392-97a5105a95f6","InvoiceNo":"INV-20260329-5219"}	2026-03-29 13:41:39.757293+00	2026-03-29 13:41:39.85563+00	2026-03-29 13:41:39.892579+00
f4efd2ec-8b9c-411e-97e3-fd0c772ff181	4d6b1960-9470-47fd-afeb-9b172fe8b408	51345f8e-b501-42e8-aa57-19ea66b6f176	c9ba9f63-6a8a-44ef-9208-9ab756272696	e09a2060-084d-4646-9ea2-2a7f0bed41db	mock	mock-payment-e09a2060084d46469ea22a7f0bed41db	mock-customer-e878f8f	1490.00	0.00	TRY	paid	card	{"checkoutSessionId":"e09a2060-084d-4646-9ea2-2a7f0bed41db","InvoiceNo":"INV-20260329-3541"}	2026-03-29 13:55:44.991391+00	2026-03-29 13:55:45.000022+00	2026-03-29 13:55:45.000747+00
e65b589a-683c-43f0-a788-cb5b446ee6b2	1b2dd3e6-38dd-4103-8942-544df818621c	236da988-0f98-47a0-b34f-4001df574251	99d71410-12d3-441c-8c0d-f8f3fb36a800	9b1603a8-3e24-46f6-bc05-b450d729e785	mock	mock-payment-9b1603a83e2446f6bc05b450d729e785	mock-customer-c647b0ef	1490.00	0.00	TRY	paid	card	{"checkoutSessionId":"9b1603a8-3e24-46f6-bc05-b450d729e785","InvoiceNo":"INV-20260329-3880"}	2026-03-29 13:56:32.476617+00	2026-03-29 13:56:32.593545+00	2026-03-29 13:56:32.637159+00
70547181-1e70-4cf0-8d70-2fb7418a5bcf	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	44a14acc-84d8-4479-ac99-74ea223f21a3	2b3a44e6-f915-42a0-a765-93e815998612	d21480da-cd09-4786-9608-27b4774ff935	mock	mock-payment-d21480dacd094786960827b4774ff935	mock-customer-133d8b4	1490.00	0.00	TRY	paid	card	{"checkoutSessionId":"d21480da-cd09-4786-9608-27b4774ff935","InvoiceNo":"INV-20260329-1381"}	2026-03-29 13:58:47.420799+00	2026-03-29 13:58:47.543687+00	2026-03-29 13:58:47.592013+00
f8a27526-edac-4a50-931a-8e3267452dee	01072375-ea4f-41a3-bbc0-eac1b77037d8	d88ee0e7-4d47-4bc8-b43a-b79eafe3a28d	fdb8bfb2-1bf5-499d-8ff1-444484ed988c	61f7b77f-7301-4346-90b5-79df284136e0	mock	mock-payment-61f7b77f7301434690b579df284136e0	mock-customer-8ec4d080	1490.00	0.00	TRY	paid	card	{"checkoutSessionId":"61f7b77f-7301-4346-90b5-79df284136e0","InvoiceNo":"INV-20260329-8966"}	2026-03-29 14:01:32.35315+00	2026-03-29 14:01:32.473428+00	2026-03-29 14:01:32.524011+00
\.


--
-- Data for Name: payment_webhooks; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.payment_webhooks (id, provider, event_id, payload_json, status, error, received_at, processed_at) FROM stdin;
2c8e500f-d476-4251-b675-9e4c7d234b67	mock	auto-700b8dc0d67d4f1abd9f8477c5586d5c	{"checkoutSessionId":"700b8dc0-d67d-4f1a-bd9f-8477c5586d5c","ProviderPaymentReference":"mock-payment-700b8dc0d67d4f1abd9f8477c5586d5c","status":"paid"}	processed	\N	2026-03-28 19:52:41.266454+00	2026-03-28 19:52:41.266487+00
c749553e-219d-4def-8658-738b17a0926f	mock	auto-f0516460da1f459c839297a5105a95f6	{"checkoutSessionId":"f0516460-da1f-459c-8392-97a5105a95f6","ProviderPaymentReference":"mock-payment-f0516460da1f459c839297a5105a95f6","status":"paid"}	processed	\N	2026-03-29 13:41:39.575608+00	2026-03-29 13:41:39.575644+00
91376966-9dcc-44e4-9c77-962402a4247a	mock	auto-e09a2060084d46469ea22a7f0bed41db	{"checkoutSessionId":"e09a2060-084d-4646-9ea2-2a7f0bed41db","ProviderPaymentReference":"mock-payment-e09a2060084d46469ea22a7f0bed41db","status":"paid"}	processed	\N	2026-03-29 13:55:44.950098+00	2026-03-29 13:55:44.950098+00
50d36aa4-b355-49ca-b8c0-80de3e152329	mock	auto-9b1603a83e2446f6bc05b450d729e785	{"checkoutSessionId":"9b1603a8-3e24-46f6-bc05-b450d729e785","ProviderPaymentReference":"mock-payment-9b1603a83e2446f6bc05b450d729e785","status":"paid"}	processed	\N	2026-03-29 13:56:32.174299+00	2026-03-29 13:56:32.17434+00
3eae674f-68c7-45af-84dc-ee9769b9a94b	mock	auto-d21480dacd094786960827b4774ff935	{"checkoutSessionId":"d21480da-cd09-4786-9608-27b4774ff935","ProviderPaymentReference":"mock-payment-d21480dacd094786960827b4774ff935","status":"paid"}	processed	\N	2026-03-29 13:58:47.135852+00	2026-03-29 13:58:47.135905+00
243629e5-29f2-425d-b726-98a814a068af	mock	auto-61f7b77f7301434690b579df284136e0	{"checkoutSessionId":"61f7b77f-7301-4346-90b5-79df284136e0","ProviderPaymentReference":"mock-payment-61f7b77f7301434690b579df284136e0","status":"paid"}	processed	\N	2026-03-29 14:01:32.048508+00	2026-03-29 14:01:32.048557+00
5efbdeef-4672-4f2c-9bb1-656926109632	mock	auto-aa5a255b5d4245b595b96cd0091aee99	{"checkoutSessionId":"aa5a255b-5d42-45b5-95b9-6cd0091aee99","ProviderPaymentReference":"mock-payment-aa5a255b5d4245b595b96cd0091aee99","status":"paid"}	processed	\N	2026-03-31 14:29:35.639824+00	2026-03-31 14:29:35.639888+00
415388e9-8516-453e-a54b-5f40dd2dc99d	mock	auto-3e281673965346618c57f6dfd2f1285b	{"checkoutSessionId":"3e281673-9653-4661-8c57-f6dfd2f1285b","ProviderPaymentReference":"mock-payment-3e281673965346618c57f6dfd2f1285b","status":"paid"}	processed	\N	2026-03-31 14:29:47.559338+00	2026-03-31 14:29:47.559338+00
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.payments (id, sale_id, method, amount, created_at) FROM stdin;
22ae7737-15a9-45a8-9642-c1466244cc52	f7b6fa94-44ec-49b0-93bd-b2ad7269de16	Cash	231.00	2026-03-29 16:45:59.40977+00
\.


--
-- Data for Name: payouts; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.payouts (id, reseller_id, period_start, period_end, total, status, created_at, paid_at) FROM stdin;
\.


--
-- Data for Name: plan_feature_flags; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.plan_feature_flags (id, subscription_plan_id, feature_flag_id, is_enabled, created_at) FROM stdin;
36ef6ad0-2677-45bc-a94c-cd0bd63b78fe	61522536-f6a6-41d5-a0f1-251c9480eb10	1a2e8e92-4ead-4315-bf94-1de619cb3be5	t	2026-03-28 19:50:46.660222+00
3ad680c4-d4a2-49d2-8ebe-b7cab55d600d	61522536-f6a6-41d5-a0f1-251c9480eb10	835d4758-d1d0-4822-8920-b156e4a098fd	t	2026-03-28 19:50:46.659309+00
49f7eb20-30b0-4e67-ba76-d6aed58b6edf	61522536-f6a6-41d5-a0f1-251c9480eb10	a859225b-bd6b-44bf-b9cc-8e8b6ab09c33	t	2026-03-28 19:50:46.661168+00
9bfa224e-4cc1-4cde-ad8e-39c6a7c11a82	61522536-f6a6-41d5-a0f1-251c9480eb10	d07f93a6-ddea-4300-a58a-565ca276f29c	t	2026-03-28 19:50:46.648861+00
1dfaca1c-bcc5-4997-aa5a-f750e792c08f	cfaee100-0ee1-42b3-b3e6-a20556c47dc2	05e94670-d0a0-4631-84f5-cf169f0d8e7e	t	2026-03-28 19:50:46.700205+00
31730d05-b890-4e45-9d75-86bc1311c770	cfaee100-0ee1-42b3-b3e6-a20556c47dc2	a859225b-bd6b-44bf-b9cc-8e8b6ab09c33	t	2026-03-28 19:50:46.701912+00
3d526157-4a34-4a4d-a1c1-9c1c45d31252	cfaee100-0ee1-42b3-b3e6-a20556c47dc2	d07f93a6-ddea-4300-a58a-565ca276f29c	t	2026-03-28 19:50:46.695052+00
422dc660-b1e6-4e4a-bd33-4b57d968af10	cfaee100-0ee1-42b3-b3e6-a20556c47dc2	1a2e8e92-4ead-4315-bf94-1de619cb3be5	t	2026-03-28 19:50:46.697012+00
4532afa5-280c-4a54-9f4c-3fbee92d97ca	cfaee100-0ee1-42b3-b3e6-a20556c47dc2	797f6279-74c5-4205-9abf-22f6c7c5e02e	t	2026-03-28 19:50:46.699476+00
4a0de0e7-e41b-4a02-aa15-fde4cba4482a	cfaee100-0ee1-42b3-b3e6-a20556c47dc2	6ba12ac7-801c-4072-8615-b7ac8499e9bf	t	2026-03-28 19:50:46.701084+00
5f851cca-e60d-4eca-a7e2-b61ab0d96003	cfaee100-0ee1-42b3-b3e6-a20556c47dc2	e346ce3f-88e6-47da-be36-86830e44c41a	t	2026-03-28 19:50:46.697936+00
62efd4c6-e0df-4bf6-aa09-5892fe409258	cfaee100-0ee1-42b3-b3e6-a20556c47dc2	835d4758-d1d0-4822-8920-b156e4a098fd	t	2026-03-28 19:50:46.695919+00
755c8957-33b9-4c8e-88c6-3aa1f4e3bb06	cfaee100-0ee1-42b3-b3e6-a20556c47dc2	b536b3b3-973a-4d1a-b26c-8951c8f4ff68	t	2026-03-28 19:50:46.69872+00
3a4288c1-a6c9-4cd7-877d-e50e2888756c	67301fb7-840e-4ba6-a8f6-e8368095b459	b536b3b3-973a-4d1a-b26c-8951c8f4ff68	t	2026-03-28 19:50:46.717396+00
495d2c29-e50b-4eb4-96b3-15ec45a31246	67301fb7-840e-4ba6-a8f6-e8368095b459	6ba12ac7-801c-4072-8615-b7ac8499e9bf	t	2026-03-28 19:50:46.720197+00
5ea36e57-baba-4cd7-865b-6f13175b6aab	67301fb7-840e-4ba6-a8f6-e8368095b459	05e94670-d0a0-4631-84f5-cf169f0d8e7e	t	2026-03-28 19:50:46.719402+00
64f2a662-13ac-4a1f-a725-1248dd0374bc	67301fb7-840e-4ba6-a8f6-e8368095b459	835d4758-d1d0-4822-8920-b156e4a098fd	t	2026-03-28 19:50:46.714548+00
6a3eb513-b9f6-4597-91af-c76f34acfe16	67301fb7-840e-4ba6-a8f6-e8368095b459	a79ebb4d-9873-437d-903a-f9d97ba5b1ae	t	2026-03-28 19:50:46.721042+00
acd2b30b-7d5b-4596-bdcb-a3330b4f7a0b	67301fb7-840e-4ba6-a8f6-e8368095b459	a859225b-bd6b-44bf-b9cc-8e8b6ab09c33	t	2026-03-28 19:50:46.722482+00
b636ab9f-d6a1-4e57-9b1e-dec19fba6961	67301fb7-840e-4ba6-a8f6-e8368095b459	d07f93a6-ddea-4300-a58a-565ca276f29c	t	2026-03-28 19:50:46.713488+00
b6503544-4f62-41fa-bb8b-4ca438fc9576	67301fb7-840e-4ba6-a8f6-e8368095b459	1a2e8e92-4ead-4315-bf94-1de619cb3be5	t	2026-03-28 19:50:46.715391+00
d5ca2273-1964-419d-858f-ce7e276a805c	67301fb7-840e-4ba6-a8f6-e8368095b459	567ea24a-a93d-40e7-b2ec-f8af902706cb	t	2026-03-28 19:50:46.721755+00
eac8ef3e-b446-4d11-9de8-3c4d07347755	67301fb7-840e-4ba6-a8f6-e8368095b459	e346ce3f-88e6-47da-be36-86830e44c41a	t	2026-03-28 19:50:46.716257+00
f5cc6a0c-5ad7-4030-83cd-6b63f6cc7674	67301fb7-840e-4ba6-a8f6-e8368095b459	797f6279-74c5-4205-9abf-22f6c7c5e02e	t	2026-03-28 19:50:46.718581+00
\.


--
-- Data for Name: plan_prices; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.plan_prices (id, subscription_plan_id, billing_period, currency, amount, promo_amount, external_price_id, trial_days, is_active, created_at, updated_at) FROM stdin;
c309dab0-67a0-4148-84c7-c2861dea39b6	61522536-f6a6-41d5-a0f1-251c9480eb10	monthly	TRY	1490.00	\N	\N	0	t	2026-03-28 19:50:46.6172+00	2026-03-28 19:50:46.681096+00
e295ed1d-6086-4206-abc2-8bf15cd1f2f3	61522536-f6a6-41d5-a0f1-251c9480eb10	yearly	TRY	14900.00	\N	\N	0	t	2026-03-28 19:50:46.640857+00	2026-03-28 19:50:46.681039+00
c3a9f121-191b-43d7-9c07-0f29081ba39d	cfaee100-0ee1-42b3-b3e6-a20556c47dc2	monthly	TRY	2990.00	\N	\N	0	t	2026-03-28 19:50:46.693202+00	2026-03-28 19:50:46.703439+00
f34b4b16-a589-4312-b376-fe344f5c7419	cfaee100-0ee1-42b3-b3e6-a20556c47dc2	yearly	TRY	29900.00	\N	\N	0	t	2026-03-28 19:50:46.694197+00	2026-03-28 19:50:46.703439+00
1925401b-c430-49a4-869c-7f61cc9eeedb	67301fb7-840e-4ba6-a8f6-e8368095b459	monthly	TRY	5990.00	\N	\N	0	t	2026-03-28 19:50:46.711043+00	2026-03-28 19:50:46.72553+00
faf8270f-cfc2-420a-bc57-3986910b137f	67301fb7-840e-4ba6-a8f6-e8368095b459	yearly	TRY	59900.00	\N	\N	0	t	2026-03-28 19:50:46.712239+00	2026-03-28 19:50:46.725529+00
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.plans (id, code, name, monthly_price, yearly_price, max_branches, max_users, max_devices, features_json, is_active, created_at) FROM stdin;
10000000-0000-0000-0000-000000000001	starter	Starter	499.00	4990.00	1	3	1	["sales","inventory","reports","mobile"]	t	2026-03-28 19:50:45.092769+00
10000000-0000-0000-0000-000000000002	pro	Pro	999.00	9990.00	5	10	5	["sales","inventory","reports","mobile","online_collection","variants"]	t	2026-03-28 19:50:45.092769+00
10000000-0000-0000-0000-000000000003	enterprise	Enterprise	0.00	0.00	\N	\N	\N	["all"]	t	2026-03-28 19:50:45.092769+00
\.


--
-- Data for Name: portal_sessions; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.portal_sessions (id, customer_account_id, reseller_account_id, tenant_id, portal_type, role_code, access_token_hash, refresh_token_hash, expires_at, refresh_expires_at, user_agent, ip_address, revoked_at, created_at, updated_at) FROM stdin;
c98626c5-fe15-48f9-b994-3b099d493e78	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	\N	customer	tenant_owner	4c4712adef03a05f3d9d7957609699d76395de09c774baae5f36227632232336	2f4fa49f0485ba661004be90b40f7ce1752ec87a201cc5a4e611ca7d719f1779	2026-03-29 07:51:46.392881+00	2026-04-27 19:51:46.392881+00	curl/8.5.0	127.0.0.1	\N	2026-03-28 19:51:46.393048+00	2026-03-28 19:51:46.420703+00
99bc0a1b-6297-4f94-8234-9521773a3e8e	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	29baba1c-1732-4565-9b0f-b98b299dbfbb	customer	tenant_owner	914dc6f0d37441d9b158261eaaf6e0cfdaf2fd2b9ad2d16c0f9990beb105e4cd	b1bcfdbb83e6e7a0c67bad5e852963ccbc9c482938ed27fe3b9272ef64467dc6	2026-03-29 07:54:10.321797+00	2026-04-27 19:54:10.321797+00	curl/8.5.0	127.0.0.1	\N	2026-03-28 19:54:10.321849+00	2026-03-28 19:54:10.322775+00
99b9925b-1327-4713-8852-d26cbd756f41	\N	6de4d19e-0bd4-4fca-9459-ff801dfcb1d9	\N	reseller	reseller_user	1e8b428f78c6fd3b24ec960eb85f231ba18c74f015a5638337e0aab73a6c8b8d	52314718ea38291cc5d057f59c180cabd641d81cb2df8443821a12fedc97a854	2026-03-29 07:54:26.228887+00	2026-04-27 19:54:26.228887+00	curl/8.5.0	127.0.0.1	\N	2026-03-28 19:54:26.228946+00	2026-03-28 19:54:26.230202+00
4b062053-f89e-4f02-9af7-893b5363d7b7	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	29baba1c-1732-4565-9b0f-b98b299dbfbb	customer	tenant_owner	dbf1fee881b0ae2083dd731d28d10aa04f4e025d9539c92a06e9d0ca3527d707	c64ef493d021b0ac6f200db9ef84e866e39886f1bc3e0b395156433dd929a6c2	2026-03-29 08:05:16.088838+00	2026-04-27 20:05:16.088838+00	curl/8.5.0	127.0.0.1	\N	2026-03-28 20:05:16.088884+00	2026-03-28 20:05:16.089134+00
7481934c-ae5e-4c85-8167-37d44b31e70f	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	29baba1c-1732-4565-9b0f-b98b299dbfbb	customer	tenant_owner	394affb25a347d85a5700853988ef5511609cac661d909ec1f0d5322b2bd2313	255d57b88dac715885af88662649412c1e087fb32221d1805ed41ef792ad42dd	2026-03-29 08:16:09.86556+00	2026-04-27 20:16:09.86556+00	curl/8.5.0	127.0.0.1	\N	2026-03-28 20:16:09.865608+00	2026-03-28 20:16:09.865788+00
38a2455b-d7fe-4902-9017-08ec3d887cb1	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	29baba1c-1732-4565-9b0f-b98b299dbfbb	customer	tenant_owner	2931d77c01579f3d452123ce7e809dbf4dbc1855288339683520491c31b5fbec	080663fbf512a770718cc6daee1cabfebc983ccad4156149cae53f5cdfc6c229	2026-03-29 08:16:49.654558+00	2026-04-27 20:16:49.654558+00	curl/8.5.0	127.0.0.1	\N	2026-03-28 20:16:49.654613+00	2026-03-28 20:16:49.654911+00
ba85bd34-2822-4c27-b3df-0fb137bd3fc9	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	29baba1c-1732-4565-9b0f-b98b299dbfbb	customer	tenant_owner	8574736384cb1e6289ab63fdbefa4622b6485993e118e92d89fec870f4bf569f	c877f54270ff5db9d1316ddd1d685679c4d7f5c13c033de0793e8007f4e31339	2026-03-29 08:20:21.064915+00	2026-04-27 20:20:21.064915+00	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	127.0.0.1	\N	2026-03-28 20:20:21.065993+00	2026-03-28 20:20:21.066612+00
d2c6a060-265d-4539-aead-911ca2365d16	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	29baba1c-1732-4565-9b0f-b98b299dbfbb	customer	tenant_owner	621d749260b739e9efda1c56d838e4b832be65c88f1aeb0ead049f4071d742fb	28c128222d391c99fc04d483916b22b89088f18adf28a26d42688b63fdd31269	2026-03-29 08:22:08.240378+00	2026-04-27 20:22:08.240378+00	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	127.0.0.1	\N	2026-03-28 20:22:08.240434+00	2026-03-28 20:22:08.24064+00
c6b1c9de-2f64-47ff-83b8-1f6ce916ddda	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	29baba1c-1732-4565-9b0f-b98b299dbfbb	customer	tenant_owner	77504a039670b93fa2c50738f935719f1496126d8150be5975c63d0b0d2f515e	3893d843c6f19a2b552ef7d5791b254b7a40b430c46fd21a232bffbb0a987543	2026-03-29 08:31:42.651621+00	2026-04-27 20:31:42.651621+00	curl/8.5.0	127.0.0.1	\N	2026-03-28 20:31:42.652041+00	2026-03-28 20:31:42.652539+00
6004445a-ad51-419a-9855-a8e8d3a9be04	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	29baba1c-1732-4565-9b0f-b98b299dbfbb	customer	tenant_owner	51174deecf39d7d95f9525259a6414d09847bc351c2a1e4d78f5d856664b597a	8681e86dc7182cde4ba33d708750f200ca4740fb3cc56463f77e9c082e272bef	2026-03-29 08:32:05.685605+00	2026-04-27 20:32:05.685605+00	curl/8.5.0	127.0.0.1	\N	2026-03-28 20:32:05.685672+00	2026-03-28 20:32:05.685983+00
e0aba014-39e5-4aed-a46b-a25cf4d9752e	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	29baba1c-1732-4565-9b0f-b98b299dbfbb	customer	tenant_owner	96867f29715a3fdb98c8c105481ffe0bc1b3453dbd5658c43d01ac364ec7daef	b6b02f7b4a00fccb1636680d30f36905e5e1e12c19fc352329ca5e81b5436d0d	2026-03-30 00:52:44.662437+00	2026-04-28 12:52:44.662437+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 12:52:44.662893+00	2026-03-29 12:52:44.719788+00
b35fc84b-6709-4fbb-aa8b-b8edb3394e14	0d68f479-53d2-499a-9b19-041da47d9c4d	\N	\N	customer	tenant_owner	2dff3ebbcd2b045988812d1b83d5873a7a7720c628a61e96a1c742b832009f75	b1961832db50af3bb0a25c92e1ca6d21be1050d82f8baa0f1c7224b2432bdaeb	2026-03-30 01:38:57.012616+00	2026-04-28 13:38:57.012616+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 13:38:57.012877+00	2026-03-29 13:38:57.05289+00
46a13967-44c9-4085-a5a1-deddbb8f3a4c	0d68f479-53d2-499a-9b19-041da47d9c4d	\N	\N	customer	tenant_owner	881dabad4c2d0d28cf1ae5cc5491e77ab4d9c4f21b414e0d1c10f06222aa674b	e64492e4c1d51ef7bbfe066f81df8a9a659ab3629e11dca6716f0f11ca90e51c	2026-03-30 01:39:52.750212+00	2026-04-28 13:39:52.750212+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 13:39:52.750243+00	2026-03-29 13:39:52.751038+00
b4c07783-204e-4fbd-8f61-7d3394baedc1	0d68f479-53d2-499a-9b19-041da47d9c4d	\N	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	customer	tenant_owner	8b631face3c94138097021295d7f344347552e69e639e67271c9fff3357308b3	f69c37c7611d977e0363b68ad0cec0a1888b750c7c93e81b74890eaacdd94d43	2026-03-30 01:43:31.041434+00	2026-04-28 13:43:31.041434+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 13:43:31.04149+00	2026-03-29 13:43:31.043438+00
9c301659-47d6-425e-9f6e-648101711727	0d68f479-53d2-499a-9b19-041da47d9c4d	\N	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	customer	tenant_owner	271cd857f1a6d6dbaa54ffda6825eeca3d768131a17fd07ec0230a26a1a1e09f	dd6a85b69ce8c1656c695d7b6a3c6fd3f2e81f3c0a2f21a5cb72e55ef49f2903	2026-03-30 01:43:44.879361+00	2026-04-28 13:43:44.879361+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 13:43:44.879439+00	2026-03-29 13:43:44.87971+00
c0b0d92b-a26e-4226-94f9-4bb6b481ec53	0d68f479-53d2-499a-9b19-041da47d9c4d	\N	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	customer	tenant_owner	7c4f299e7fd468850f01478b5498a713c49d5fe0dba43c4924611f49c935da84	8a0bf30cf63b8061a45ce2886696e198d11644dc878cce7e1029422d5422ba4d	2026-03-30 02:04:21.400607+00	2026-04-28 14:04:21.400607+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 14:04:21.400886+00	2026-03-29 14:04:21.447058+00
e07ceed6-b561-4c42-96e7-9ac2a41d82b7	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	9e6a0c0abb270fb132106ef1119c708e0ffbbe53652e8d992f10c97a601bd124	f01266d663d018ce2781553db023599797a19767184f5b4f5ac7ae4a8566aaee	2026-03-30 02:06:57.7526+00	2026-04-28 14:06:57.7526+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 14:06:57.752672+00	2026-03-29 14:06:57.753115+00
5aa6faf4-1e87-49cd-9cdd-070652414d96	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	ca1e07504047a31f51e83970a92838131f2c5a473ecb248f7c28321d554bd0a3	97b1b55502b458795e127beb5934fbc6f7bfdcaad2f378f0a003e6513441c864	2026-03-30 02:07:28.687273+00	2026-04-28 14:07:28.687273+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 14:07:28.687352+00	2026-03-29 14:07:28.687748+00
7b16428a-ee8a-4235-bdc2-193f62fdbce2	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	7f62901a0e159286c456fcdea6b0b65261ab37ecff3918748a717c1f27210757	1b4d1e1d0a08edf3f4f7a06d1940cafb86a2e8341df3db052142b978afced57e	2026-03-30 02:08:29.120075+00	2026-04-28 14:08:29.120075+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 14:08:29.120165+00	2026-03-29 14:08:29.120544+00
82ed738e-ac52-4ab8-9037-9d992dc84c71	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	63f7d3fc89e110cd5e97a591b60c636fdc5d763963bb92ca73c8f37ee7998be8	738a33257671904aa38990ea24f8d45a462308db6d8c2bc07ef9a1a41e48d5a3	2026-03-30 02:13:03.011817+00	2026-04-28 14:13:03.011817+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 14:13:03.011847+00	2026-03-29 14:13:03.01208+00
24ad54cd-41b1-4813-8ffb-828e72c75401	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	fe54ad1eefec91803c0988a76a068e7b03bf903da457f229bd496ffa693ad818	38a0f2e65fab7ec78dde3d224778a6be2db2062d33f4b779d8674f51075653c3	2026-03-30 02:18:20.227676+00	2026-04-28 14:18:20.227676+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 14:18:20.227735+00	2026-03-29 14:18:20.228009+00
382f908b-2768-49d5-a3f8-87c565470559	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	8642856bd752fccb8e171d4dbe6573388b368ec38bd927fdc304b1442ecc419d	8104b5efd3661a95f5ac5904454bb118c2a3272a69f55805115fc2f46cb471df	2026-03-30 02:51:41.964842+00	2026-04-28 14:51:41.964842+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 14:51:41.964904+00	2026-03-29 14:51:41.965195+00
1429f1f9-c09f-4e3b-a0ed-361dfc62231b	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	2b8ce033cf7ad9a2dd8ec32e43a7dffb4084ef3d35c8274b5f4505a4ef4c9cad	ba441705da0af3c25d91d588586a7617d44c5ed5730cdbd468d32e68b04c9809	2026-03-30 02:51:42.335309+00	2026-04-28 14:51:42.335309+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 14:51:42.335382+00	2026-03-29 14:51:42.335706+00
3fd6a88b-afbf-4e3b-948c-8fb6b6baa184	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	e2024b2d29782cb8c4351df65fd26451ca8a0482598123195372d35e55ab93d1	711edfd183c0b6f6a1f6303295e70ff789482e6e99d412054b034fe04d28064b	2026-03-30 03:03:56.914976+00	2026-04-28 15:03:56.914976+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 15:03:56.915054+00	2026-03-29 15:03:56.915374+00
0aa18bfb-4f69-4556-ae3d-3a8500c9c92c	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	2c3e8132e1eb8911f9ecd328ed0436f61d88fd864bd35cdaae2848e4d0e00d3d	ed1792df719a5d147a244eb12450e7cf976f9298c722ce469ec902da34594d9e	2026-03-30 03:36:07.19973+00	2026-04-28 15:36:07.19973+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 15:36:07.199784+00	2026-03-29 15:36:07.199964+00
dd20bade-7c88-4d80-b7ef-45d6bb59b9a9	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	67bee6a856d6eed14cb8ff32bbbb65bf61194d6395eace3a91eee1ce6f842f4c	b07b0986649597f64897ece0e8e265ec03f511ef99950e606c650fc32fd53e02	2026-03-30 03:38:56.874618+00	2026-04-28 15:38:56.874618+00	node	127.0.0.1	\N	2026-03-29 15:38:56.874698+00	2026-03-29 15:38:56.874861+00
be19041b-b299-4d9b-914e-a44b746247c4	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	3201b57c650a35eb386885c93e5585851618e75b6d65acb4b52ea2b1728b963b	6f89c34d61ba8881d039c24b17bb564b0f64a074d0522f4e89be8fad701cc612	2026-03-30 03:42:47.350826+00	2026-04-28 15:42:47.350826+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 15:42:47.350857+00	2026-03-29 15:42:47.351043+00
3cbda0a3-29af-4cce-bd49-1951a0866a05	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	5d3a29e0307d9bf9c66c66585b9377249d660556e81952995d1387205d1f3232	46c5e88984c8f69e5af51161532e3397b80ef989ab62a7b4fc58653bc853070e	2026-03-30 04:16:15.850788+00	2026-04-28 16:16:15.850788+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 16:16:15.851855+00	2026-03-29 16:16:15.922941+00
00229b01-d536-4a52-a16b-bb67e723ffa4	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	c2a13b510e942c163ee80dc1e1e40e5b15b9233bc9f3dcfc3d4b0d1a9ebc11af	a435bf342ce671fbf16ea95d3ec7d4b6479375cf00a3e1dc85f6794e7a21a5f3	2026-03-30 04:17:09.412085+00	2026-04-28 16:17:09.412085+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 16:17:09.412192+00	2026-03-29 16:17:09.415017+00
1f3d53fd-da75-4fdc-82f8-d8f109cb42a3	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	a595d058784b9c55ebf903c8e35e8c64e3baa5f9e0a28ea4c8d8415b91e98f87	b57ee9aa5354b8be71f98d2dc44a245132622e91bfbbe453d5e6be97e91c5142	2026-03-30 04:21:12.552984+00	2026-04-28 16:21:12.552984+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 16:21:12.554117+00	2026-03-29 16:21:12.6186+00
83d433f4-75f7-479f-9651-9d8a94de36cf	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	6193338d7927b99645eb912c527e55a15f386978291d24c623ee9dc2481bb26e	5180d98145241b32eafaa8aaff72a6cfcf44d8e8de152675891fb520c0eefb0c	2026-03-30 04:26:03.079587+00	2026-04-28 16:26:03.079587+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 16:26:03.080354+00	2026-03-29 16:26:03.144638+00
99b734b3-217b-4b60-9c59-f39ca4a237ff	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	f644b6131e7b7dade10cdfc2c598c66cc8f479027be6949f2d23c9733697aafc	e0208fdf0c827e9eb55f64a64fe97fb28c06e5260725018bccf435ae7d2677ad	2026-03-30 04:35:53.052328+00	2026-04-28 16:35:53.052328+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 16:35:53.052726+00	2026-03-29 16:35:53.141704+00
6db5c1cb-f3b5-4273-972e-613b1b169afd	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	18355a968278537a6c0a0a4c85648d9b7d17cad7e5969a941f2b774230a9220a	61cd8a8c77e648d347ceebb001c0b340cd7422a403b1df2da78e6116564b9634	2026-03-30 04:36:20.971826+00	2026-04-28 16:36:20.971826+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 16:36:20.971896+00	2026-03-29 16:36:20.973248+00
6c05f703-6a2d-4a07-ab43-7bae0e633208	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	9bb843cd500afa486d88271b73d672669744b0ea43c7731d57ae67a71795b0cb	79d02eed7fe1ca4a6764756a0cb9edb89105bedf0cdc2023c4a73e880de4a5da	2026-03-30 04:40:46.513244+00	2026-04-28 16:40:46.513244+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 16:40:46.513871+00	2026-03-29 16:40:46.624443+00
f6f4a446-f7a7-41dc-b4bc-08499c816ac3	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	e8fdb5ffaa7df4a7e27129355e38cae54f1daf4381ef7682b40d3cd6546992cc	e350e44303a4544340c1e80d39a523da64204f0eb1e7cedc5facddcd6d5230e6	2026-03-30 05:15:02.605391+00	2026-04-28 17:15:02.605391+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 17:15:02.605488+00	2026-03-29 17:15:02.606172+00
bdac9893-f4a8-47be-b473-59d8ffa8f99b	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	79b899e0dbd23293bc2a1839476183ac652fe472ccc67830c6575bd729c931ff	e6a847726405f68897e62a1f6143f48d9551be1b6842a25bc3da2c8fe0f00d12	2026-03-30 05:15:02.864584+00	2026-04-28 17:15:02.864584+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 17:15:02.864629+00	2026-03-29 17:15:02.865839+00
138ae6c3-b698-4ea5-ae29-b52e8eefe38b	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	db3eecbbd33186c3f8ab90bcc406b7d5ce338189c3ec808b6e12c429d40c1cff	13bbe479425ebeacd455314106bcb9b5bca15ed68be5849073afc5423e4cb838	2026-03-30 05:17:13.536471+00	2026-04-28 17:17:13.536471+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 17:17:13.536561+00	2026-03-29 17:17:13.536779+00
77ad2ce5-2052-4dbe-96e1-e1f6fc639169	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	8824a5791055ea447b1d30bd28bce34b4a3902274c73d4d13b97aa8514c4ec15	5ec6a74f06db28552fd7231b0ef799b985973e1ffdd4cd9b9277c8ba7245c90b	2026-03-30 05:17:13.690778+00	2026-04-28 17:17:13.690778+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 17:17:13.690819+00	2026-03-29 17:17:13.691116+00
5c2a9125-146f-4d0a-963d-ab73e38b4797	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	ea8151e821d4126ea85999d586fd892a5b5966c5ef6fe89f6a03c0ef474632b5	3c6695350ff6e49a4477bdecacc057e35055e582624c76b572dc98458dd48e8d	2026-03-30 05:20:41.739979+00	2026-04-28 17:20:41.739979+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 17:20:41.740019+00	2026-03-29 17:20:41.740186+00
c332b51e-9807-480b-9daf-359670cb032b	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	b06de465c4f39cbaf1ec560817166bdc78db6246a6b2baf7d5d33322327c0d37	4bf801f7c2d7df0129c197728b7c2c6dbda19cfed9a7c4ea0ad3efc924967029	2026-03-30 05:20:41.767487+00	2026-04-28 17:20:41.767487+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 17:20:41.767544+00	2026-03-29 17:20:41.767706+00
b65a09bb-8b9a-4908-a299-14495e1a39e2	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	635a89cbb3cb8d73360c8ff4c354a67bb1af6f2d14dbcf5fd8f66db6a20e1577	40f33a0248c6055a942a78eb6731757c6b26305588e53c22d8054e44f0ea8364	2026-03-30 05:34:52.055436+00	2026-04-28 17:34:52.055436+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 17:34:52.055833+00	2026-03-29 17:34:52.130991+00
be78de3e-f9cb-41b9-8ce8-e6b0c934e971	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	bfb686752505d7a656d5b4ad327b83e55490797594a7a13f1a59a97a01f873ca	625fe75290b0f95d0788de008e94ce22b5a94fb5703ba1c262d6b5219a0605f3	2026-03-30 05:34:52.05543+00	2026-04-28 17:34:52.05543+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 17:34:52.055833+00	2026-03-29 17:34:52.131013+00
cc66f006-69ee-49c2-9981-07193eb6bc49	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	64e9e7d51acd1d5e06d6d3ca301974262c40cd84fea1393e4125f73539c850bb	3e98e1447ec57dcedbf0144bc67afb5f7b30ebec3366c2179a1af87432139d18	2026-03-30 05:49:14.46214+00	2026-04-28 17:49:14.46214+00	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	127.0.0.1	\N	2026-03-29 17:49:14.462236+00	2026-03-29 17:49:14.462596+00
470e264c-3a9a-4e6d-96fc-495410d7aaad	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	04582b2ceb0c8aab9041394d1e2cb302a076814db3d48ea18ba8f210788b3487	0847e57039b7e9660ddc45a5214176de38b90d61227aeb98f5f50704df8624ba	2026-03-30 05:50:59.989104+00	2026-04-28 17:50:59.989104+00	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	127.0.0.1	\N	2026-03-29 17:50:59.989145+00	2026-03-29 17:50:59.989409+00
129fa445-20b3-407e-8f34-49f87dc6490a	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	028c4bce7ee527d4179e0a4994d3943fae915303f32136fb999c9dbb3bb97733	79bc2b2af30e99785225e18d492ee81542b704d6d6b90d742ca9cad8bd580bc7	2026-03-30 05:54:55.436405+00	2026-04-28 17:54:55.436405+00	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	127.0.0.1	\N	2026-03-29 17:54:55.436451+00	2026-03-29 17:54:55.436653+00
758e98fa-515f-4112-8840-1c71b3ecb943	e1a75aac-d3a3-4d1c-a94c-42bda9e5f4ee	\N	4d6b1960-9470-47fd-afeb-9b172fe8b408	customer	tenant_owner	94025fd7d6b5beb25f8c11a9571c52378c68eb6ece469c0601b6ab57d226b0d8	5b8339151f0f428d726c533aa9889ad86f552e8facdaf50d081c3aad72756049	2026-03-30 05:56:17.147014+00	2026-04-28 17:56:17.147014+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 17:56:17.147095+00	2026-03-29 17:56:17.147639+00
b4b894e9-8c23-4373-a880-b29dee94d4d3	23237479-241c-4c06-adf7-2036086ea1fe	\N	1b2dd3e6-38dd-4103-8942-544df818621c	customer	tenant_owner	086fe491e329eb0021e3d7e193d965a3ff469ea7de4c7973babc6da197cf5a0d	a4f28eaa0caf38a9c22357b6b856aa3b1c003fc7b11dc07203908290bc855a3f	2026-03-30 05:56:17.281291+00	2026-04-28 17:56:17.281291+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 17:56:17.281371+00	2026-03-29 17:56:17.281594+00
3af27535-2979-4303-b19c-7da84a3f141d	973a2c5c-759f-4421-bbd0-9c630af456f5	\N	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	customer	tenant_owner	03f8508a30c7b185edd6d89a74a4ffa9be8afab65e74ba4eb89d21496c46d6d9	31332f2faede24ce16233c96c626bc938d698fc514649bef4127bf0bf8faaf02	2026-03-30 05:56:17.411171+00	2026-04-28 17:56:17.411171+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 17:56:17.411206+00	2026-03-29 17:56:17.411402+00
fef566df-848a-4b00-a124-7c4eb1faa48f	f29fe2cd-4fac-442a-8519-6956bfdac35d	\N	01072375-ea4f-41a3-bbc0-eac1b77037d8	customer	tenant_owner	e8980088ce95612d69299065b4d226c1a5818bea9c46fd392e9794a248ff16ad	89d2be705dac36002977baad832b60a7cb11cb26bf0642e34d660af8446d4027	2026-03-30 05:56:17.591452+00	2026-04-28 17:56:17.591452+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 17:56:17.591516+00	2026-03-29 17:56:17.591832+00
ffb17979-77e8-4ef6-a4bf-0d4b2d4c649c	e1a75aac-d3a3-4d1c-a94c-42bda9e5f4ee	\N	4d6b1960-9470-47fd-afeb-9b172fe8b408	customer	tenant_owner	68caa68492aaa257b44d367d13e8d9f2a60a19d7fe17c6be1926f2953e890999	c964e2db9f8c74c9bb6e1e19b95cc3f1ed22f1ae365d23bd418ed4a51f694975	2026-03-30 05:58:20.521636+00	2026-04-28 17:58:20.521636+00	curl/8.5.0	127.0.0.1	\N	2026-03-29 17:58:20.521677+00	2026-03-29 17:58:20.521882+00
7126eccb-2ccd-4cc9-83e4-a964a12f3a0f	e1a75aac-d3a3-4d1c-a94c-42bda9e5f4ee	\N	4d6b1960-9470-47fd-afeb-9b172fe8b408	customer	tenant_owner	65571a0f0eb130b9fd2b2b2814c173e527b286a619dd58093b6d7467026b3665	cc8e8bd4299e28ef854e29add8f160c5d06c0f0799d556006e662918b33475db	2026-03-30 06:00:48.24651+00	2026-04-28 18:00:48.24651+00	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:148.0) Gecko/20100101 Firefox/148.0	127.0.0.1	\N	2026-03-29 18:00:48.246544+00	2026-03-29 18:00:48.246697+00
67516dcd-4724-430d-b2e6-7204f0060b8a	e1a75aac-d3a3-4d1c-a94c-42bda9e5f4ee	\N	4d6b1960-9470-47fd-afeb-9b172fe8b408	customer	tenant_owner	f79a6061de9cd413fe5fa76bffcc4caa78f71fe17190d83284860d9eb8547a21	b9d14ee75c7e3950e0846092a1fec84104196f843ee63a58acd1f4b85e472fe6	2026-03-30 08:08:30.207936+00	2026-04-28 20:08:30.207936+00	node	127.0.0.1	\N	2026-03-29 20:08:30.207986+00	2026-03-29 20:08:30.208169+00
55ee8376-34e1-4d70-9e77-ec8866235d9e	973a2c5c-759f-4421-bbd0-9c630af456f5	\N	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	customer	tenant_owner	517b8531f3df920c061eadbf1ffa85bed3ecf4d27ec43c1763e411fa6b343802	eccabb1d48a77e412635f5ebe82ea597dccc4086a7666ba61eae392b71eca8a2	2026-04-01 02:32:05.199189+00	2026-04-30 14:32:05.199189+00	curl/8.5.0	127.0.0.1	\N	2026-03-31 14:32:05.199511+00	2026-03-31 14:32:05.237297+00
c66e514a-9d3b-405b-b006-74da12bce1a2	973a2c5c-759f-4421-bbd0-9c630af456f5	\N	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	customer	tenant_owner	5406212ab1011545ea8f20c0c596b3aa23861478764f61587bc52043d45dacbc	f44f6a44d6758e2ead7a2e7821bb4ff4b9c94f2390dd850b3d3f9163d3ee0aaf	2026-04-01 02:32:05.199174+00	2026-04-30 14:32:05.199174+00	curl/8.5.0	127.0.0.1	\N	2026-03-31 14:32:05.199475+00	2026-03-31 14:32:05.23732+00
7dfbc76a-92b1-4970-9066-c8a1748072da	973a2c5c-759f-4421-bbd0-9c630af456f5	\N	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	customer	tenant_owner	520e9a7596c9ed807b053180070ea7a76c22c4453e33b9377d24c82592c22d84	49ae0b34e7c77ba41978e5cf5ec76444a61928547c1b64f5af129fe9ff4024b5	2026-04-01 02:32:05.199241+00	2026-04-30 14:32:05.199241+00	curl/8.5.0	127.0.0.1	\N	2026-03-31 14:32:05.199551+00	2026-03-31 14:32:05.237337+00
68c45ab1-7442-4fcf-9672-80cb35e0e6df	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	29baba1c-1732-4565-9b0f-b98b299dbfbb	customer	tenant_owner	7e7c86a8e1630a4069f2272eba793c3a5e165aaad5b28ee692d3dc76f347f53b	326aa550728ab3c8ada04aa3aa8d3c815abdacd452c504da5cce80c9cadf478d	2026-04-01 02:34:27.235489+00	2026-04-30 14:34:27.235489+00	curl/8.5.0	127.0.0.1	\N	2026-03-31 14:34:27.23557+00	2026-03-31 14:34:27.236724+00
d165ab65-8fc9-405f-9bfa-45e5dc748a72	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	29baba1c-1732-4565-9b0f-b98b299dbfbb	customer	tenant_owner	479e50f837f577ff96a0a5ef9d64cc98af52dbbc98ad61457e0a6d510792f355	31f79263c1217c576ab0c66d47824b87a0d320ed1c10a51cc0e808a79fe76b1c	2026-04-01 02:34:27.272774+00	2026-04-30 14:34:27.272774+00	curl/8.5.0	127.0.0.1	\N	2026-03-31 14:34:27.272805+00	2026-03-31 14:34:27.273097+00
c14175b2-d5d1-48c7-bee6-c63373795404	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	29baba1c-1732-4565-9b0f-b98b299dbfbb	customer	tenant_owner	eff44d0272fd4dd5e17e0109ba95d3dfda63c63499e4c7d2556637830368bd6e	6a67297cc28a5342506d4921f198d66632b480920c9e54587785f56408b661e8	2026-04-01 02:34:27.273698+00	2026-04-30 14:34:27.273698+00	curl/8.5.0	127.0.0.1	\N	2026-03-31 14:34:27.273738+00	2026-03-31 14:34:27.273946+00
c11d7944-6714-4e61-8f60-ce15214fca81	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	29baba1c-1732-4565-9b0f-b98b299dbfbb	customer	tenant_owner	135f2354563dc851bf90bb27775a367993e0dc0a311a4a29c8b24b70f97183bb	9b6739bfa9fa2d3467ca5f471385e15bf246fc8738ac99a15b8ef42b04a065dd	2026-04-01 02:37:16.670989+00	2026-04-30 14:37:16.670989+00	node	127.0.0.1	\N	2026-03-31 14:37:16.671022+00	2026-03-31 14:37:16.671244+00
9cae4b7b-b943-46e9-81a0-6a811689fc69	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	29baba1c-1732-4565-9b0f-b98b299dbfbb	customer	tenant_owner	d9baa981831e09d4995ae87bfb93370290dac6f4193793ac20cf4619a4758bbe	c83f7499f313e5542b2e7d09db06272eedccbe44718f0d2ba0e1ea7abf62f091	2026-04-01 04:09:02.827944+00	2026-04-30 16:09:02.827944+00	curl/8.5.0	127.0.0.1	\N	2026-03-31 16:09:02.828431+00	2026-03-31 16:09:02.906017+00
b9a8b347-45af-425d-abb9-3c8ba9537551	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	29baba1c-1732-4565-9b0f-b98b299dbfbb	customer	tenant_owner	c3e36a154ff59c1b60d37004123e2027b3d3cb41cfacf3bfde115b8c9dc724cb	c26d0964a5b05b8f867bee8be93d173cb295dec102c7115d645677af0aeebcc6	2026-04-01 04:11:16.780459+00	2026-04-30 16:11:16.780459+00	curl/8.5.0	127.0.0.1	\N	2026-03-31 16:11:16.780491+00	2026-03-31 16:11:16.781766+00
0b4695c2-aaf2-46ff-af0c-77061b04e6f2	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	29baba1c-1732-4565-9b0f-b98b299dbfbb	customer	tenant_owner	174f263534b5290ec8761c19d8392b9693a28438578426b5a09b51980a764267	1ed17be59d93ca41888e599401f002db614886fe20af4c509277cb7354a54c74	2026-04-01 04:11:30.095297+00	2026-04-30 16:11:30.095297+00	curl/8.5.0	127.0.0.1	\N	2026-03-31 16:11:30.09535+00	2026-03-31 16:11:30.095589+00
e581c366-8d8f-4e15-b8a3-99892b27834f	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	29baba1c-1732-4565-9b0f-b98b299dbfbb	customer	tenant_owner	1b54507a5fedd95f8e636890fc3d6cf0ffe6238d082456c6ccd5605c028bcf74	f7c4de98b4c1b6f67afba16fd63e8638702dc7e97070efd8cb160925cd942b0a	2026-04-01 07:08:39.7254+00	2026-04-30 19:08:39.7254+00	curl/8.5.0	127.0.0.1	\N	2026-03-31 19:08:39.736318+00	2026-03-31 19:08:39.736611+00
4aadfc49-a27e-4453-975f-e70f6a9d1af9	1a40ae98-9470-4d8a-b447-d9089eee0626	\N	29baba1c-1732-4565-9b0f-b98b299dbfbb	customer	tenant_owner	7110fef7c6d25b681ea4cf5ef6d69b75510ad5d4d1a10fa3a24a02ae55ffec62	bd650c4e8acb123970a172ebfeefdbd9eb2751cbb23f47e773e3df7086585e1c	2026-04-01 07:12:34.814717+00	2026-04-30 19:12:34.814717+00	curl/8.5.0	127.0.0.1	\N	2026-03-31 19:12:34.814781+00	2026-03-31 19:12:34.815196+00
\.


--
-- Data for Name: processed_events; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.processed_events (event_id, tenant_id, device_id, processed_at) FROM stdin;
7cec6763-2b15-4ce1-aded-7ff7d3c642ed	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 16:43:49.380759+00
9c2bd783-51af-45c1-8838-c92f570def9f	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 16:44:49.315149+00
fba998b5-11d9-46b0-9316-aef7fb285c26	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 16:45:49.327064+00
71fcaa2c-9cac-40f9-9836-6f3c94c49143	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 16:45:54.320781+00
96308bb3-e351-4e9d-96b2-1c3fc639b823	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 16:45:59.483101+00
c9257b9f-cb60-4c4c-b25d-d606692eb0eb	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 16:45:59.581205+00
a7561e57-69f5-450f-9fa2-b497c927a58e	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 16:46:49.362102+00
4a9cccb9-640d-47e2-a238-672315eb2df0	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 16:47:49.401769+00
5d81c298-a323-43fe-94ad-f66d2d5a6cec	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 17:11:41.074003+00
cf856724-b32c-424f-8a70-9d0a5ca519a4	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 17:12:41.141588+00
59380e9c-a9ea-4c29-849f-6d6401565356	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 17:13:41.179698+00
5522b32b-0501-4979-8212-e261edc42fcc	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 17:14:41.238819+00
796551e1-53da-48a3-a17d-38fc5dd3b0c4	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 17:15:41.282161+00
ce4ab8d6-0fea-42a8-93b7-8caab24e2616	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 17:16:41.334585+00
fb52a6e3-c3f0-4009-8446-53bb2cdeba26	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 17:17:41.396764+00
d4b62a08-89a3-42d0-a5b2-fcfa5451c9b2	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 17:18:41.444361+00
3b20aa58-af3e-4fe4-93c0-6c74f0c0b19a	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 17:19:41.487527+00
1405c283-d93c-404b-851d-880eaaa518ca	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 17:20:41.543059+00
4d1352fd-127e-40cd-b9b7-9f09b164c225	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 17:21:41.594175+00
166a0c6d-f177-4378-9126-aa14563febe1	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 17:22:41.644249+00
fa16184f-8a09-43f6-bca7-dfdc7bb008c9	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 17:23:41.729754+00
52fa74d4-0c69-4ad3-be1e-cb4e744ff8a8	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 17:24:41.782435+00
17b03afc-8f47-4c38-9def-c9f931a58e39	01072375-ea4f-41a3-bbc0-eac1b77037d8	0417c926-baca-46bd-8ce9-ef3d8c02592a	2026-03-29 17:25:42.158546+00
\.


--
-- Data for Name: product_barcodes; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.product_barcodes (product_id, barcode) FROM stdin;
\.


--
-- Data for Name: product_variants; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.product_variants (id, tenant_id, product_id, name, sku, barcode, attributes_json, price_delta, stock_tracking_enabled, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: production_orders; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.production_orders (id, tenant_id, bom_id, finished_product_id, planned_quantity, status, created_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.products (id, tenant_id, name, sku, barcode, unit, tax_rate, is_active, created_at, category_id, sale_price, purchase_price, stock_tracking_enabled, min_stock) FROM stdin;
\.


--
-- Data for Name: purchase_order_lines; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.purchase_order_lines (id, purchase_order_id, product_id, quantity, unit_cost) FROM stdin;
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.purchase_orders (id, tenant_id, supplier_id, warehouse_id, status, created_at, received_at) FROM stdin;
\.


--
-- Data for Name: rate_limit_policies; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.rate_limit_policies (id, policy_code, scope, target, limit_summary, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reseller_accounts; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.reseller_accounts (id, code, name, email, status, commission_rate, approved_at, created_at, company_name, city, phone, website_or_social_proof, experience, message, password_hash, last_login_at, updated_at) FROM stdin;
6de4d19e-0bd4-4fca-9459-ff801dfcb1d9	MARMAR429	Aylin Demir	partner@loomapos.com	approved	0.1200	2026-03-28 19:50:46.926459+00	2026-03-28 19:50:46.847046+00	Marmara POS Danismanlik	Istanbul	+90 532 111 22 33	linkedin.com/company/marmarapos	7 yil perakende yazilim satis ve saha kurulum deneyimi	Marmara bolgesi icin aktif cozum ortakligi yurutmek istiyoruz.	pbkdf2$120000$RKbOKmoKcToy2kJcCycvlA==$M99T5bN/rgGBonte9Sk2khSMK9kT0V1Tt81aGhtehx0=	2026-03-28 19:54:26.228887+00	2026-03-28 19:54:26.230202+00
\.


--
-- Data for Name: reseller_codes; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.reseller_codes (id, reseller_account_id, code, is_primary, is_active, created_at, updated_at) FROM stdin;
f2a1b4cf-be81-4ef8-aa44-c3de46e50b66	6de4d19e-0bd4-4fca-9459-ff801dfcb1d9	MARMAR429	t	t	2026-03-28 19:50:46.994281+00	2026-03-28 19:50:47.009703+00
\.


--
-- Data for Name: reseller_commission_events; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.reseller_commission_events (id, tenant_id, reseller_account_id, subscription_id, invoice_id, rate, amount, status, event_at, created_at) FROM stdin;
78beba09-fd45-4e77-84d7-2053642c3e7a	29baba1c-1732-4565-9b0f-b98b299dbfbb	6de4d19e-0bd4-4fca-9459-ff801dfcb1d9	d53794db-c8ef-4b6e-9c04-b2021234f86e	ac4668ce-3f6d-4b9f-8fc2-16befaadbc04	0.1200	358.80	accrued	2026-03-28 19:52:41.497352+00	2026-03-28 19:52:41.742583+00
\.


--
-- Data for Name: reseller_customer_links; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.reseller_customer_links (id, tenant_id, reseller_account_id, customer_account_id, subscription_id, referral_code, linked_at, created_at) FROM stdin;
f94309d1-f335-4182-bc9c-2f92075cd47b	29baba1c-1732-4565-9b0f-b98b299dbfbb	6de4d19e-0bd4-4fca-9459-ff801dfcb1d9	1a40ae98-9470-4d8a-b447-d9089eee0626	d53794db-c8ef-4b6e-9c04-b2021234f86e	MARMAR429	2026-03-28 19:52:41.497352+00	2026-03-28 19:52:41.730721+00
\.


--
-- Data for Name: reseller_customers; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.reseller_customers (id, tenant_id, reseller_id, referred_at, created_at) FROM stdin;
\.


--
-- Data for Name: reseller_referrals; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.reseller_referrals (id, reseller_account_id, checkout_session_id, tenant_id, referral_code, status, commission_eligible, created_at, updated_at) FROM stdin;
c7cdae74-f79a-4afc-b86b-77e42c0c6e5b	6de4d19e-0bd4-4fca-9459-ff801dfcb1d9	700b8dc0-d67d-4f1a-bd9f-8477c5586d5c	\N	MARMAR429	attached	t	2026-03-28 19:52:41.189211+00	2026-03-28 19:52:41.227386+00
\.


--
-- Data for Name: restore_validation_runs; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.restore_validation_runs (id, backup_run_id, environment, status, validation_type, findings_json, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: retention_policies; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.retention_policies (id, policy_code, data_class, hot_retention, archive_retention, disposal_policy, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.roles (id, tenant_id, name) FROM stdin;
\.


--
-- Data for Name: rollout_records; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.rollout_records (id, environment, channel, target_type, target_version, status, compatibility_window, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: runbook_records; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.runbook_records (id, code, title, category, severity, markdown_path, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sale_lines; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.sale_lines (id, sale_id, product_id, qty, unit_price, discount, tax, line_total) FROM stdin;
13b3db70-1e56-4d53-9043-a003446d941e	f7b6fa94-44ec-49b0-93bd-b2ad7269de16	d4c697e1-887f-9a90-346d-9e4917442c9c	3.0000	70.00	0.00	21.00	231.00
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.sales (id, tenant_id, branch_id, device_id, receipt_no, status, subtotal, discount, tax, total, created_at) FROM stdin;
f7b6fa94-44ec-49b0-93bd-b2ad7269de16	01072375-ea4f-41a3-bbc0-eac1b77037d8	54bc4367-e4a6-4c6f-b693-a106594cfe6f	0417c926-baca-46bd-8ce9-ef3d8c02592a	SAT-25-0417C9-20260329-009ED6-000001	Completed	210.00	0.00	21.00	231.00	2026-03-29 16:45:56.045+00
\.


--
-- Data for Name: secret_references; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.secret_references (id, environment, secret_name, provider, rotation_policy, last_rotated_at, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: security_events; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.security_events (id, environment, event_type, severity, summary, status, created_at) FROM stdin;
\.


--
-- Data for Name: service_versions; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.service_versions (id, environment, service_name, version, minimum_supported_version, rollout_state, created_at) FROM stdin;
\.


--
-- Data for Name: slo_definitions; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.slo_definitions (id, environment, service_name, slo_code, objective, measurement_window, alert_policy, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stock_balances; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.stock_balances (tenant_id, branch_id, product_id, qty) FROM stdin;
\.


--
-- Data for Name: stock_by_warehouse; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.stock_by_warehouse (id, tenant_id, product_id, warehouse_id, quantity, updated_at) FROM stdin;
\.


--
-- Data for Name: stock_moves; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.stock_moves (id, tenant_id, branch_id, product_id, qty_delta, reason, ref_type, ref_id, created_at, warehouse_id) FROM stdin;
cf176042-d66e-4143-a282-68ca39f1fb8b	01072375-ea4f-41a3-bbc0-eac1b77037d8	54bc4367-e4a6-4c6f-b693-a106594cfe6f	d4c697e1-887f-9a90-346d-9e4917442c9c	-3.0000	SALE_CREATED	sale	f7b6fa94-44ec-49b0-93bd-b2ad7269de16	2026-03-29 16:45:59.36744+00	3cc20022-9e61-659a-b9cd-c78f3e7a9841
\.


--
-- Data for Name: subscription_payments; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.subscription_payments (id, tenant_id, subscription_id, invoice_id, provider, payment_ref, status, amount, currency, paid_at, created_at) FROM stdin;
\.


--
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.subscription_plans (id, code, name, description, branch_limit, user_limit, device_limit, support_tier, reseller_commission_eligibility, is_public, is_active, highlight_label, created_at, updated_at) FROM stdin;
61522536-f6a6-41d5-a0f1-251c9480eb10	starter	Starter	Tek sube ile lisansli POS ekosistemine gecis.	1	3	1	standard	f	t	t		2026-03-28 19:50:46.558519+00	2026-03-28 19:50:46.596798+00
cfaee100-0ee1-42b3-b3e6-a20556c47dc2	pro	Pro	Bayi ve cok subeli perakende ekipleri icin ana paket.	5	10	5	priority	t	t	t	Most popular	2026-03-28 19:50:46.662331+00	2026-03-28 19:50:46.68103+00
67301fb7-840e-4ba6-a8f6-e8368095b459	enterprise	Enterprise	Kurumsal zincirler icin kurumsal rollout paketi.	\N	\N	\N	enterprise	t	t	t	Custom SLA	2026-03-28 19:50:46.702733+00	2026-03-28 19:50:46.703439+00
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.subscriptions (id, tenant_id, plan_code, billing_cycle, status, current_period_start, current_period_end, reseller_code, created_at, billing_profile_id, renewal_date, cancel_at_period_end, trial_ends_at, grace_ends_at, canceled_at, provider_subscription_id, provider_customer_reference, plan_snapshot_json, updated_at) FROM stdin;
d53794db-c8ef-4b6e-9c04-b2021234f86e	29baba1c-1732-4565-9b0f-b98b299dbfbb	enterprise	monthly	subscription_active	2026-03-28 19:52:41.497352+00	2026-04-28 19:52:41.497352+00	MARMAR429	2026-03-28 19:52:41.500916+00	56726ae9-0e54-443e-8a28-800ae2a2190f	2026-04-28 19:52:41.497352+00	f	\N	\N	\N	mock-subscription-20d3895c5f004c22a32f48482651f3ae	mock-customer-c7d11688	{"Code":"enterprise","Name":"Enterprise","BranchLimit":null,"UserLimit":null,"DeviceLimit":null,"SupportTier":"enterprise","featureFlags":["variant_products","reporting","management_dashboard","e_invoice","online_collection","inventory_management","fiscal_integrations","download_center","branch_management","sales_operations","staff_management"],"price":5990.00,"promoPrice":null}	2026-03-28 20:23:04.480784+00
ba2d5a68-91bc-45e1-be8b-5a128033c704	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	starter	monthly	active	2026-03-29 13:41:39.757293+00	2026-04-29 13:41:39.757293+00	\N	2026-03-29 13:41:39.763628+00	e2459fca-fe48-49c0-9b1e-0f622bbb8e4a	2026-04-29 13:41:39.757293+00	f	\N	\N	\N	mock-subscription-2c5ded90557d479e92f41c2dd0e3d6bf	mock-customer-5876af22	{"Code":"starter","Name":"Starter","BranchLimit":1,"UserLimit":3,"DeviceLimit":1,"SupportTier":"standard","featureFlags":["reporting","inventory_management","download_center","sales_operations"],"price":1490.00,"promoPrice":null}	2026-03-29 13:41:39.799674+00
51345f8e-b501-42e8-aa57-19ea66b6f176	4d6b1960-9470-47fd-afeb-9b172fe8b408	starter	monthly	active	2026-03-29 13:55:44.991391+00	2026-04-29 13:55:44.991391+00	\N	2026-03-29 13:55:44.991538+00	48952a74-d5d9-4358-a3a2-1663b985f085	2026-04-29 13:55:44.991391+00	f	\N	\N	\N	mock-subscription-4b87d3ae118f4a0f9ecb1d7547263927	mock-customer-e878f8f	{"Code":"starter","Name":"Starter","BranchLimit":1,"UserLimit":3,"DeviceLimit":1,"SupportTier":"standard","featureFlags":["reporting","inventory_management","download_center","sales_operations"],"price":1490.00,"promoPrice":null}	2026-03-29 13:55:44.992081+00
236da988-0f98-47a0-b34f-4001df574251	1b2dd3e6-38dd-4103-8942-544df818621c	starter	monthly	active	2026-03-29 13:56:32.476617+00	2026-04-29 13:56:32.476617+00	\N	2026-03-29 13:56:32.48617+00	f03f4ebb-e3d6-4e17-a8c3-c6b366bd5d8f	2026-04-29 13:56:32.476617+00	f	\N	\N	\N	mock-subscription-f1fa0bb974544943a3b258adb20fdf8e	mock-customer-c647b0ef	{"Code":"starter","Name":"Starter","BranchLimit":1,"UserLimit":3,"DeviceLimit":1,"SupportTier":"standard","featureFlags":["reporting","inventory_management","download_center","sales_operations"],"price":1490.00,"promoPrice":null}	2026-03-29 13:56:32.525425+00
44a14acc-84d8-4479-ac99-74ea223f21a3	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	starter	monthly	active	2026-03-29 13:58:47.420799+00	2026-04-29 13:58:47.420799+00	\N	2026-03-29 13:58:47.429276+00	2dc070d7-a389-4b1e-9867-428d5b72f015	2026-04-29 13:58:47.420799+00	f	\N	\N	\N	mock-subscription-861002294688481f8292a771bd55fd95	mock-customer-133d8b4	{"Code":"starter","Name":"Starter","BranchLimit":1,"UserLimit":3,"DeviceLimit":1,"SupportTier":"standard","featureFlags":["reporting","inventory_management","download_center","sales_operations"],"price":1490.00,"promoPrice":null}	2026-03-29 13:58:47.473463+00
d88ee0e7-4d47-4bc8-b43a-b79eafe3a28d	01072375-ea4f-41a3-bbc0-eac1b77037d8	starter	monthly	active	2026-03-29 14:01:32.35315+00	2026-04-29 14:01:32.35315+00	\N	2026-03-29 14:01:32.36508+00	eebf784c-6722-4560-8b27-c5f7b8110369	2026-04-29 14:01:32.35315+00	f	\N	\N	\N	mock-subscription-a882877702ae4952aec961f7632f7a9e	mock-customer-8ec4d080	{"Code":"starter","Name":"Starter","BranchLimit":1,"UserLimit":3,"DeviceLimit":1,"SupportTier":"standard","featureFlags":["reporting","inventory_management","download_center","sales_operations"],"price":1490.00,"promoPrice":null}	2026-03-29 14:01:32.404498+00
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.suppliers (id, tenant_id, name, tax_number, phone, email, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: support_access_sessions; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.support_access_sessions (id, internal_user_id, tenant_id, access_mode, reason, status, expires_at, ended_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: support_case_links; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.support_case_links (id, support_case_id, entity_type, entity_id, label, created_at) FROM stdin;
\.


--
-- Data for Name: support_case_messages; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.support_case_messages (id, support_case_id, author_type, author_internal_user_id, author_customer_account_id, body, is_internal, created_at) FROM stdin;
\.


--
-- Data for Name: support_case_notes; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.support_case_notes (id, support_case_id, internal_user_id, note, created_at) FROM stdin;
\.


--
-- Data for Name: support_cases; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.support_cases (id, tenant_id, customer_account_id, reseller_account_id, source, category, priority, status, title, summary, contact_preference, assignee_email, escalation_level, first_response_at, resolved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenant_users; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.tenant_users (id, tenant_id, customer_account_id, role_code, is_owner, status, created_at, updated_at) FROM stdin;
03affe89-beac-466a-b84c-61aaefb84248	29baba1c-1732-4565-9b0f-b98b299dbfbb	1a40ae98-9470-4d8a-b447-d9089eee0626	tenant_owner	t	active	2026-03-28 19:52:41.377943+00	2026-03-28 19:52:41.492922+00
86056ec4-dfb3-486c-b91c-1318f6f6ee4b	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	0d68f479-53d2-499a-9b19-041da47d9c4d	tenant_owner	t	active	2026-03-29 13:41:39.683306+00	2026-03-29 13:41:39.752797+00
d5073281-9e65-4c29-8fb9-1387520597a1	4d6b1960-9470-47fd-afeb-9b172fe8b408	e1a75aac-d3a3-4d1c-a94c-42bda9e5f4ee	tenant_owner	t	active	2026-03-29 13:55:44.976426+00	2026-03-29 13:55:44.98742+00
956673ab-7df2-4650-8ae1-c83047cd6481	1b2dd3e6-38dd-4103-8942-544df818621c	23237479-241c-4c06-adf7-2036086ea1fe	tenant_owner	t	active	2026-03-29 13:56:32.369118+00	2026-03-29 13:56:32.469266+00
c24b0753-463e-4d61-a574-6dfd0e074d0a	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	973a2c5c-759f-4421-bbd0-9c630af456f5	tenant_owner	t	active	2026-03-29 13:58:47.320355+00	2026-03-29 13:58:47.414355+00
72ab6ee8-92e4-49cd-a04e-744d2a95990c	01072375-ea4f-41a3-bbc0-eac1b77037d8	f29fe2cd-4fac-442a-8519-6956bfdac35d	tenant_owner	t	active	2026-03-29 14:01:32.246359+00	2026-03-29 14:01:32.347593+00
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.tenants (id, name, settings_json, created_at, tenant_code, billing_email, tax_office, tax_number, country, default_locale, status, updated_at) FROM stdin;
29baba1c-1732-4565-9b0f-b98b299dbfbb	Demo Magaza	{"commercialWebsite":true,"websiteCannotRunPos":true}	2026-03-28 19:52:41.34583+00	DEMOMAGA-5927	billing@demo.local	Kadikoy	1234567890	TR	tr-TR	active	2026-03-28 19:52:41.369188+00
04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	Demo Magaza	{"commercialWebsite":true,"websiteCannotRunPos":true}	2026-03-29 13:41:39.653955+00	DEMOMAGA-5335	owner@demo.local	Van	1234567890	TR	tr-TR	active	2026-03-29 13:41:39.676294+00
4d6b1960-9470-47fd-afeb-9b172fe8b408	Demo Magaza 2	{"commercialWebsite":true,"websiteCannotRunPos":true}	2026-03-29 13:55:44.974001+00	DEMOMAGA-5412	owner2@demo.local	Van	1234567891	TR	tr-TR	active	2026-03-29 13:55:44.974485+00
1b2dd3e6-38dd-4103-8942-544df818621c	Demo Magaza 3	{"commercialWebsite":true,"websiteCannotRunPos":true}	2026-03-29 13:56:32.337661+00	DEMOMAGA-2622	owner3@demo.local	Van	1234567892	TR	tr-TR	active	2026-03-29 13:56:32.365454+00
ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	Demo Magaza 4	{"commercialWebsite":true,"websiteCannotRunPos":true}	2026-03-29 13:58:47.291989+00	DEMOMAGA-9013	owner4@demo.local	Van	1234567893	TR	tr-TR	active	2026-03-29 13:58:47.317217+00
01072375-ea4f-41a3-bbc0-eac1b77037d8	Demo Magaza 5	{"commercialWebsite":true,"websiteCannotRunPos":true}	2026-03-29 14:01:32.214998+00	DEMOMAGA-1578	owner5@demo.local	Van	1234567894	TR	tr-TR	active	2026-03-29 14:01:32.243006+00
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.user_roles (user_id, role_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.users (id, tenant_id, email, name, is_active, created_at, branch_id, phone) FROM stdin;
\.


--
-- Data for Name: warehouse_transfer_lines; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.warehouse_transfer_lines (id, transfer_id, product_id, quantity) FROM stdin;
\.


--
-- Data for Name: warehouse_transfers; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.warehouse_transfers (id, tenant_id, from_warehouse_id, to_warehouse_id, status, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: loomapos
--

COPY public.warehouses (id, tenant_id, name, type, is_active, created_at) FROM stdin;
01745e2e-1e82-7e5f-33f7-b36064c3d7ba	29baba1c-1732-4565-9b0f-b98b299dbfbb	DEFAULT	main	t	2026-03-31 14:21:26.904405+00
dde0d896-4dc7-6b12-9856-b660667e4537	04282c6f-5afd-4cc9-911e-a0a4e8fdb8d2	DEFAULT	main	t	2026-03-31 14:21:26.904405+00
b697d3eb-347f-c7b8-1679-95e37d46c900	4d6b1960-9470-47fd-afeb-9b172fe8b408	DEFAULT	main	t	2026-03-31 14:21:26.904405+00
3e9cfe2a-4698-376d-2143-d64b8dc9850e	1b2dd3e6-38dd-4103-8942-544df818621c	DEFAULT	main	t	2026-03-31 14:21:26.904405+00
7927a1d0-2085-9250-c9cd-82c3497ea7b2	ff8980f4-3c0b-40d6-ad3b-e3218de82a8a	DEFAULT	main	t	2026-03-31 14:21:26.904405+00
3cc20022-9e61-659a-b9cd-c78f3e7a9841	01072375-ea4f-41a3-bbc0-eac1b77037d8	DEFAULT	main	t	2026-03-31 14:21:26.904405+00
\.


--
-- Name: aggregatedcounter_id_seq; Type: SEQUENCE SET; Schema: hangfire; Owner: loomapos
--

SELECT pg_catalog.setval('hangfire.aggregatedcounter_id_seq', 1, false);


--
-- Name: counter_id_seq; Type: SEQUENCE SET; Schema: hangfire; Owner: loomapos
--

SELECT pg_catalog.setval('hangfire.counter_id_seq', 1, false);


--
-- Name: hash_id_seq; Type: SEQUENCE SET; Schema: hangfire; Owner: loomapos
--

SELECT pg_catalog.setval('hangfire.hash_id_seq', 1, false);


--
-- Name: job_id_seq; Type: SEQUENCE SET; Schema: hangfire; Owner: loomapos
--

SELECT pg_catalog.setval('hangfire.job_id_seq', 1, false);


--
-- Name: jobparameter_id_seq; Type: SEQUENCE SET; Schema: hangfire; Owner: loomapos
--

SELECT pg_catalog.setval('hangfire.jobparameter_id_seq', 1, false);


--
-- Name: jobqueue_id_seq; Type: SEQUENCE SET; Schema: hangfire; Owner: loomapos
--

SELECT pg_catalog.setval('hangfire.jobqueue_id_seq', 1, false);


--
-- Name: list_id_seq; Type: SEQUENCE SET; Schema: hangfire; Owner: loomapos
--

SELECT pg_catalog.setval('hangfire.list_id_seq', 1, false);


--
-- Name: set_id_seq; Type: SEQUENCE SET; Schema: hangfire; Owner: loomapos
--

SELECT pg_catalog.setval('hangfire.set_id_seq', 1, false);


--
-- Name: state_id_seq; Type: SEQUENCE SET; Schema: hangfire; Owner: loomapos
--

SELECT pg_catalog.setval('hangfire.state_id_seq', 1, false);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: loomapos
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 64, true);


--
-- Name: license_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: loomapos
--

SELECT pg_catalog.setval('public.license_events_id_seq', 6, true);


--
-- Name: aggregatedcounter aggregatedcounter_key_key; Type: CONSTRAINT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.aggregatedcounter
    ADD CONSTRAINT aggregatedcounter_key_key UNIQUE (key);


--
-- Name: aggregatedcounter aggregatedcounter_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.aggregatedcounter
    ADD CONSTRAINT aggregatedcounter_pkey PRIMARY KEY (id);


--
-- Name: counter counter_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.counter
    ADD CONSTRAINT counter_pkey PRIMARY KEY (id);


--
-- Name: hash hash_key_field_key; Type: CONSTRAINT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.hash
    ADD CONSTRAINT hash_key_field_key UNIQUE (key, field);


--
-- Name: hash hash_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.hash
    ADD CONSTRAINT hash_pkey PRIMARY KEY (id);


--
-- Name: job job_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.job
    ADD CONSTRAINT job_pkey PRIMARY KEY (id);


--
-- Name: jobparameter jobparameter_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.jobparameter
    ADD CONSTRAINT jobparameter_pkey PRIMARY KEY (id);


--
-- Name: jobqueue jobqueue_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.jobqueue
    ADD CONSTRAINT jobqueue_pkey PRIMARY KEY (id);


--
-- Name: list list_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.list
    ADD CONSTRAINT list_pkey PRIMARY KEY (id);


--
-- Name: lock lock_resource_key; Type: CONSTRAINT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.lock
    ADD CONSTRAINT lock_resource_key UNIQUE (resource);

ALTER TABLE ONLY hangfire.lock REPLICA IDENTITY USING INDEX lock_resource_key;


--
-- Name: schema schema_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.schema
    ADD CONSTRAINT schema_pkey PRIMARY KEY (version);


--
-- Name: server server_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.server
    ADD CONSTRAINT server_pkey PRIMARY KEY (id);


--
-- Name: set set_key_value_key; Type: CONSTRAINT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.set
    ADD CONSTRAINT set_key_value_key UNIQUE (key, value);


--
-- Name: set set_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.set
    ADD CONSTRAINT set_pkey PRIMARY KEY (id);


--
-- Name: state state_pkey; Type: CONSTRAINT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.state
    ADD CONSTRAINT state_pkey PRIMARY KEY (id);


--
-- Name: __ef_migrations_history PK___ef_migrations_history; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.__ef_migrations_history
    ADD CONSTRAINT "PK___ef_migrations_history" PRIMARY KEY ("MigrationId");


--
-- Name: abuse_flags abuse_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.abuse_flags
    ADD CONSTRAINT abuse_flags_pkey PRIMARY KEY (id);


--
-- Name: accounting_export_items accounting_export_items_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.accounting_export_items
    ADD CONSTRAINT accounting_export_items_pkey PRIMARY KEY (id);


--
-- Name: activation_events activation_events_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.activation_events
    ADD CONSTRAINT activation_events_pkey PRIMARY KEY (id);


--
-- Name: admin_action_approvals admin_action_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.admin_action_approvals
    ADD CONSTRAINT admin_action_approvals_pkey PRIMARY KEY (id);


--
-- Name: admin_action_requests admin_action_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.admin_action_requests
    ADD CONSTRAINT admin_action_requests_pkey PRIMARY KEY (id);


--
-- Name: alert_events alert_events_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.alert_events
    ADD CONSTRAINT alert_events_pkey PRIMARY KEY (id);


--
-- Name: alert_rules alert_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.alert_rules
    ADD CONSTRAINT alert_rules_pkey PRIMARY KEY (id);


--
-- Name: analytics_report_schedules analytics_report_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.analytics_report_schedules
    ADD CONSTRAINT analytics_report_schedules_pkey PRIMARY KEY (id);


--
-- Name: analytics_saved_views analytics_saved_views_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.analytics_saved_views
    ADD CONSTRAINT analytics_saved_views_pkey PRIMARY KEY (id);


--
-- Name: app_releases app_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.app_releases
    ADD CONSTRAINT app_releases_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: backup_runs backup_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.backup_runs
    ADD CONSTRAINT backup_runs_pkey PRIMARY KEY (id);


--
-- Name: bill_of_material_lines bill_of_material_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.bill_of_material_lines
    ADD CONSTRAINT bill_of_material_lines_pkey PRIMARY KEY (id);


--
-- Name: bill_of_materials bill_of_materials_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.bill_of_materials
    ADD CONSTRAINT bill_of_materials_pkey PRIMARY KEY (id);


--
-- Name: billing_profiles billing_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.billing_profiles
    ADD CONSTRAINT billing_profiles_pkey PRIMARY KEY (id);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: capacity_snapshots capacity_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.capacity_snapshots
    ADD CONSTRAINT capacity_snapshots_pkey PRIMARY KEY (id);


--
-- Name: cash_transactions cash_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.cash_transactions
    ADD CONSTRAINT cash_transactions_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: checkout_sessions checkout_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.checkout_sessions
    ADD CONSTRAINT checkout_sessions_pkey PRIMARY KEY (id);


--
-- Name: commissions commissions_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.commissions
    ADD CONSTRAINT commissions_pkey PRIMARY KEY (id);


--
-- Name: contact_ledger contact_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.contact_ledger
    ADD CONSTRAINT contact_ledger_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: customer_account_entries customer_account_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.customer_account_entries
    ADD CONSTRAINT customer_account_entries_pkey PRIMARY KEY (id);


--
-- Name: customer_accounts customer_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.customer_accounts
    ADD CONSTRAINT customer_accounts_pkey PRIMARY KEY (id);


--
-- Name: customer_current_accounts customer_current_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.customer_current_accounts
    ADD CONSTRAINT customer_current_accounts_pkey PRIMARY KEY (id);


--
-- Name: dependency_status_records dependency_status_records_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.dependency_status_records
    ADD CONSTRAINT dependency_status_records_pkey PRIMARY KEY (id);


--
-- Name: deployment_records deployment_records_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.deployment_records
    ADD CONSTRAINT deployment_records_pkey PRIMARY KEY (id);


--
-- Name: device_activations device_activations_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.device_activations
    ADD CONSTRAINT device_activations_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: download_accesses download_accesses_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.download_accesses
    ADD CONSTRAINT download_accesses_pkey PRIMARY KEY (id);


--
-- Name: downloadable_assets downloadable_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.downloadable_assets
    ADD CONSTRAINT downloadable_assets_pkey PRIMARY KEY (id);


--
-- Name: email_notifications email_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.email_notifications
    ADD CONSTRAINT email_notifications_pkey PRIMARY KEY (id);


--
-- Name: environment_configs environment_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.environment_configs
    ADD CONSTRAINT environment_configs_pkey PRIMARY KEY (id);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (id);


--
-- Name: incident_records incident_records_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.incident_records
    ADD CONSTRAINT incident_records_pkey PRIMARY KEY (id);


--
-- Name: incident_timeline_events incident_timeline_events_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.incident_timeline_events
    ADD CONSTRAINT incident_timeline_events_pkey PRIMARY KEY (id);


--
-- Name: internal_sessions internal_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.internal_sessions
    ADD CONSTRAINT internal_sessions_pkey PRIMARY KEY (id);


--
-- Name: internal_user_roles internal_user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.internal_user_roles
    ADD CONSTRAINT internal_user_roles_pkey PRIMARY KEY (id);


--
-- Name: internal_users internal_users_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.internal_users
    ADD CONSTRAINT internal_users_pkey PRIMARY KEY (id);


--
-- Name: invoice_lines invoice_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.invoice_lines
    ADD CONSTRAINT invoice_lines_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_invoice_no_key; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_no_key UNIQUE (invoice_no);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: license_events license_events_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.license_events
    ADD CONSTRAINT license_events_pkey PRIMARY KEY (id);


--
-- Name: licenses licenses_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.licenses
    ADD CONSTRAINT licenses_pkey PRIMARY KEY (id);


--
-- Name: migration_runs migration_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.migration_runs
    ADD CONSTRAINT migration_runs_pkey PRIMARY KEY (id);


--
-- Name: ops_audit_logs ops_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.ops_audit_logs
    ADD CONSTRAINT ops_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: payment_attempts payment_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.payment_attempts
    ADD CONSTRAINT payment_attempts_pkey PRIMARY KEY (id);


--
-- Name: payment_transactions payment_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_pkey PRIMARY KEY (id);


--
-- Name: payment_webhooks payment_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.payment_webhooks
    ADD CONSTRAINT payment_webhooks_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: payouts payouts_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.payouts
    ADD CONSTRAINT payouts_pkey PRIMARY KEY (id);


--
-- Name: plan_feature_flags plan_feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.plan_feature_flags
    ADD CONSTRAINT plan_feature_flags_pkey PRIMARY KEY (id);


--
-- Name: plan_prices plan_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.plan_prices
    ADD CONSTRAINT plan_prices_pkey PRIMARY KEY (id);


--
-- Name: plans plans_code_key; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_code_key UNIQUE (code);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: portal_sessions portal_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.portal_sessions
    ADD CONSTRAINT portal_sessions_pkey PRIMARY KEY (id);


--
-- Name: processed_events processed_events_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.processed_events
    ADD CONSTRAINT processed_events_pkey PRIMARY KEY (event_id);


--
-- Name: product_barcodes product_barcodes_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.product_barcodes
    ADD CONSTRAINT product_barcodes_pkey PRIMARY KEY (product_id, barcode);


--
-- Name: product_variants product_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_pkey PRIMARY KEY (id);


--
-- Name: production_orders production_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.production_orders
    ADD CONSTRAINT production_orders_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_lines purchase_order_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: rate_limit_policies rate_limit_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.rate_limit_policies
    ADD CONSTRAINT rate_limit_policies_pkey PRIMARY KEY (id);


--
-- Name: reseller_accounts reseller_accounts_code_key; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_accounts
    ADD CONSTRAINT reseller_accounts_code_key UNIQUE (code);


--
-- Name: reseller_accounts reseller_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_accounts
    ADD CONSTRAINT reseller_accounts_pkey PRIMARY KEY (id);


--
-- Name: reseller_codes reseller_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_codes
    ADD CONSTRAINT reseller_codes_pkey PRIMARY KEY (id);


--
-- Name: reseller_commission_events reseller_commission_events_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_commission_events
    ADD CONSTRAINT reseller_commission_events_pkey PRIMARY KEY (id);


--
-- Name: reseller_customer_links reseller_customer_links_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_customer_links
    ADD CONSTRAINT reseller_customer_links_pkey PRIMARY KEY (id);


--
-- Name: reseller_customers reseller_customers_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_customers
    ADD CONSTRAINT reseller_customers_pkey PRIMARY KEY (id);


--
-- Name: reseller_referrals reseller_referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_referrals
    ADD CONSTRAINT reseller_referrals_pkey PRIMARY KEY (id);


--
-- Name: restore_validation_runs restore_validation_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.restore_validation_runs
    ADD CONSTRAINT restore_validation_runs_pkey PRIMARY KEY (id);


--
-- Name: retention_policies retention_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.retention_policies
    ADD CONSTRAINT retention_policies_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: rollout_records rollout_records_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.rollout_records
    ADD CONSTRAINT rollout_records_pkey PRIMARY KEY (id);


--
-- Name: runbook_records runbook_records_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.runbook_records
    ADD CONSTRAINT runbook_records_pkey PRIMARY KEY (id);


--
-- Name: sale_lines sale_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.sale_lines
    ADD CONSTRAINT sale_lines_pkey PRIMARY KEY (id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (id);


--
-- Name: secret_references secret_references_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.secret_references
    ADD CONSTRAINT secret_references_pkey PRIMARY KEY (id);


--
-- Name: security_events security_events_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_pkey PRIMARY KEY (id);


--
-- Name: service_versions service_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.service_versions
    ADD CONSTRAINT service_versions_pkey PRIMARY KEY (id);


--
-- Name: slo_definitions slo_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.slo_definitions
    ADD CONSTRAINT slo_definitions_pkey PRIMARY KEY (id);


--
-- Name: stock_balances stock_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.stock_balances
    ADD CONSTRAINT stock_balances_pkey PRIMARY KEY (tenant_id, branch_id, product_id);


--
-- Name: stock_by_warehouse stock_by_warehouse_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.stock_by_warehouse
    ADD CONSTRAINT stock_by_warehouse_pkey PRIMARY KEY (id);


--
-- Name: stock_moves stock_moves_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT stock_moves_pkey PRIMARY KEY (id);


--
-- Name: subscription_payments subscription_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT subscription_payments_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: support_access_sessions support_access_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.support_access_sessions
    ADD CONSTRAINT support_access_sessions_pkey PRIMARY KEY (id);


--
-- Name: support_case_links support_case_links_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.support_case_links
    ADD CONSTRAINT support_case_links_pkey PRIMARY KEY (id);


--
-- Name: support_case_messages support_case_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.support_case_messages
    ADD CONSTRAINT support_case_messages_pkey PRIMARY KEY (id);


--
-- Name: support_case_notes support_case_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.support_case_notes
    ADD CONSTRAINT support_case_notes_pkey PRIMARY KEY (id);


--
-- Name: support_cases support_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.support_cases
    ADD CONSTRAINT support_cases_pkey PRIMARY KEY (id);


--
-- Name: tenant_users tenant_users_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.tenant_users
    ADD CONSTRAINT tenant_users_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: warehouse_transfer_lines warehouse_transfer_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.warehouse_transfer_lines
    ADD CONSTRAINT warehouse_transfer_lines_pkey PRIMARY KEY (id);


--
-- Name: warehouse_transfers warehouse_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.warehouse_transfers
    ADD CONSTRAINT warehouse_transfers_pkey PRIMARY KEY (id);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: ix_hangfire_counter_expireat; Type: INDEX; Schema: hangfire; Owner: loomapos
--

CREATE INDEX ix_hangfire_counter_expireat ON hangfire.counter USING btree (expireat);


--
-- Name: ix_hangfire_counter_key; Type: INDEX; Schema: hangfire; Owner: loomapos
--

CREATE INDEX ix_hangfire_counter_key ON hangfire.counter USING btree (key);


--
-- Name: ix_hangfire_hash_expireat; Type: INDEX; Schema: hangfire; Owner: loomapos
--

CREATE INDEX ix_hangfire_hash_expireat ON hangfire.hash USING btree (expireat);


--
-- Name: ix_hangfire_job_expireat; Type: INDEX; Schema: hangfire; Owner: loomapos
--

CREATE INDEX ix_hangfire_job_expireat ON hangfire.job USING btree (expireat);


--
-- Name: ix_hangfire_job_statename; Type: INDEX; Schema: hangfire; Owner: loomapos
--

CREATE INDEX ix_hangfire_job_statename ON hangfire.job USING btree (statename);


--
-- Name: ix_hangfire_jobparameter_jobidandname; Type: INDEX; Schema: hangfire; Owner: loomapos
--

CREATE INDEX ix_hangfire_jobparameter_jobidandname ON hangfire.jobparameter USING btree (jobid, name);


--
-- Name: ix_hangfire_jobqueue_jobidandqueue; Type: INDEX; Schema: hangfire; Owner: loomapos
--

CREATE INDEX ix_hangfire_jobqueue_jobidandqueue ON hangfire.jobqueue USING btree (jobid, queue);


--
-- Name: ix_hangfire_jobqueue_queueandfetchedat; Type: INDEX; Schema: hangfire; Owner: loomapos
--

CREATE INDEX ix_hangfire_jobqueue_queueandfetchedat ON hangfire.jobqueue USING btree (queue, fetchedat);


--
-- Name: ix_hangfire_list_expireat; Type: INDEX; Schema: hangfire; Owner: loomapos
--

CREATE INDEX ix_hangfire_list_expireat ON hangfire.list USING btree (expireat);


--
-- Name: ix_hangfire_set_expireat; Type: INDEX; Schema: hangfire; Owner: loomapos
--

CREATE INDEX ix_hangfire_set_expireat ON hangfire.set USING btree (expireat);


--
-- Name: ix_hangfire_set_key_score; Type: INDEX; Schema: hangfire; Owner: loomapos
--

CREATE INDEX ix_hangfire_set_key_score ON hangfire.set USING btree (key, score);


--
-- Name: ix_hangfire_state_jobid; Type: INDEX; Schema: hangfire; Owner: loomapos
--

CREATE INDEX ix_hangfire_state_jobid ON hangfire.state USING btree (jobid);


--
-- Name: jobqueue_queue_fetchat_jobid; Type: INDEX; Schema: hangfire; Owner: loomapos
--

CREATE INDEX jobqueue_queue_fetchat_jobid ON hangfire.jobqueue USING btree (queue, fetchedat, jobid);


--
-- Name: ix_abuse_flags_tenant_flag_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_abuse_flags_tenant_flag_created ON public.abuse_flags USING btree (tenant_id, flag_type, created_at DESC);


--
-- Name: ix_accounting_export_items_tenant_status_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_accounting_export_items_tenant_status_created ON public.accounting_export_items USING btree (tenant_id, status, created_at);


--
-- Name: ix_activation_events_tenant_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_activation_events_tenant_created ON public.activation_events USING btree (tenant_id, created_at DESC);


--
-- Name: ix_admin_action_approvals_request_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_admin_action_approvals_request_created ON public.admin_action_approvals USING btree (admin_action_request_id, created_at DESC);


--
-- Name: ix_admin_action_requests_action_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_admin_action_requests_action_created ON public.admin_action_requests USING btree (action_code, created_at DESC);


--
-- Name: ix_alert_events_env_triggered; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_alert_events_env_triggered ON public.alert_events USING btree (environment, triggered_at DESC);


--
-- Name: ix_alert_rules_env_code; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_alert_rules_env_code ON public.alert_rules USING btree (environment, code);


--
-- Name: ix_analytics_report_schedules_tenant_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_analytics_report_schedules_tenant_created ON public.analytics_report_schedules USING btree (tenant_id, created_at DESC);


--
-- Name: ix_analytics_saved_views_tenant_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_analytics_saved_views_tenant_created ON public.analytics_saved_views USING btree (tenant_id, created_at DESC);


--
-- Name: ix_analytics_saved_views_unique; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_analytics_saved_views_unique ON public.analytics_saved_views USING btree (tenant_id, customer_account_id, view_code, name);


--
-- Name: ix_app_releases_platform_channel_version; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_app_releases_platform_channel_version ON public.app_releases USING btree (platform, channel, version);


--
-- Name: ix_audit_logs_tenant_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_audit_logs_tenant_created ON public.audit_logs USING btree (tenant_id, created_at);


--
-- Name: ix_backup_runs_env_type_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_backup_runs_env_type_created ON public.backup_runs USING btree (environment, backup_type, created_at DESC);


--
-- Name: ix_billing_profiles_tenant_email; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_billing_profiles_tenant_email ON public.billing_profiles USING btree (tenant_id, billing_email);


--
-- Name: ix_bom_tenant_product_active; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_bom_tenant_product_active ON public.bill_of_materials USING btree (tenant_id, product_id, is_active);


--
-- Name: ix_capacity_snapshots_env_resource_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_capacity_snapshots_env_resource_created ON public.capacity_snapshots USING btree (environment, resource_type, created_at DESC);


--
-- Name: ix_cash_transactions_tenant_branch_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_cash_transactions_tenant_branch_created ON public.cash_transactions USING btree (tenant_id, branch_id, created_at);


--
-- Name: ix_categories_tenant_name; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_categories_tenant_name ON public.categories USING btree (tenant_id, name);


--
-- Name: ix_checkout_sessions_checkout_reference; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_checkout_sessions_checkout_reference ON public.checkout_sessions USING btree (checkout_reference);


--
-- Name: ix_checkout_sessions_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_checkout_sessions_created ON public.checkout_sessions USING btree (created_at DESC);


--
-- Name: ix_checkout_sessions_idempotency_key; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_checkout_sessions_idempotency_key ON public.checkout_sessions USING btree (idempotency_key);


--
-- Name: ix_checkout_sessions_provider_payment_reference; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_checkout_sessions_provider_payment_reference ON public.checkout_sessions USING btree (provider_payment_reference);


--
-- Name: ix_commissions_reseller_status_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_commissions_reseller_status_created ON public.commissions USING btree (reseller_id, status, created_at DESC);


--
-- Name: ix_contact_ledger_tenant_contact_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_contact_ledger_tenant_contact_created ON public.contact_ledger USING btree (tenant_id, contact_id, created_at);


--
-- Name: ix_contacts_tenant_type_name; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_contacts_tenant_type_name ON public.contacts USING btree (tenant_id, type, name);


--
-- Name: ix_customer_account_entries_tenant_customer_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_customer_account_entries_tenant_customer_created ON public.customer_account_entries USING btree (tenant_id, customer_id, created_at);


--
-- Name: ix_customer_accounts_email; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_customer_accounts_email ON public.customer_accounts USING btree (email);


--
-- Name: ix_customer_accounts_status_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_customer_accounts_status_created ON public.customer_accounts USING btree (account_status, created_at DESC);


--
-- Name: ix_dependency_status_records_env_code; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_dependency_status_records_env_code ON public.dependency_status_records USING btree (environment, dependency_code);


--
-- Name: ix_deployment_records_environment_service_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_deployment_records_environment_service_created ON public.deployment_records USING btree (environment, service_name, created_at DESC);


--
-- Name: ix_device_activations_tenant_revoked; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_device_activations_tenant_revoked ON public.device_activations USING btree (tenant_id, revoked_at);


--
-- Name: ix_devices_tenant_branch_name; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_devices_tenant_branch_name ON public.devices USING btree (tenant_id, branch_id, name);


--
-- Name: ix_download_accesses_tenant_asset; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_download_accesses_tenant_asset ON public.download_accesses USING btree (tenant_id, downloadable_asset_id);


--
-- Name: ix_downloadable_assets_release_platform; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_downloadable_assets_release_platform ON public.downloadable_assets USING btree (app_release_id, platform);


--
-- Name: ix_email_notifications_event_status_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_email_notifications_event_status_created ON public.email_notifications USING btree (event_code, status, created_at DESC);


--
-- Name: ix_environment_configs_env_key; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_environment_configs_env_key ON public.environment_configs USING btree (environment, config_key);


--
-- Name: ix_feature_flags_code; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_feature_flags_code ON public.feature_flags USING btree (code);


--
-- Name: ix_incident_records_env_status_opened; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_incident_records_env_status_opened ON public.incident_records USING btree (environment, status, opened_at DESC);


--
-- Name: ix_incident_timeline_events_incident_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_incident_timeline_events_incident_created ON public.incident_timeline_events USING btree (incident_record_id, created_at DESC);


--
-- Name: ix_internal_sessions_access_token_hash; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_internal_sessions_access_token_hash ON public.internal_sessions USING btree (access_token_hash);


--
-- Name: ix_internal_sessions_user_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_internal_sessions_user_created ON public.internal_sessions USING btree (internal_user_id, created_at DESC);


--
-- Name: ix_internal_user_roles_user_role; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_internal_user_roles_user_role ON public.internal_user_roles USING btree (internal_user_id, role_code);


--
-- Name: ix_internal_users_email; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_internal_users_email ON public.internal_users USING btree (email);


--
-- Name: ix_invoice_lines_tenant_invoice; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_invoice_lines_tenant_invoice ON public.invoice_lines USING btree (tenant_id, invoice_id);


--
-- Name: ix_invoices_tenant_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_invoices_tenant_created ON public.invoices USING btree (tenant_id, created_at DESC);


--
-- Name: ix_license_events_tenant_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_license_events_tenant_created ON public.license_events USING btree (tenant_id, created_at DESC);


--
-- Name: ix_licenses_license_key; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_licenses_license_key ON public.licenses USING btree (license_key);


--
-- Name: ix_licenses_tenant_status_exp; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_licenses_tenant_status_exp ON public.licenses USING btree (tenant_id, status, expires_at DESC);


--
-- Name: ix_migration_runs_env_name_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_migration_runs_env_name_created ON public.migration_runs USING btree (environment, migration_name, created_at DESC);


--
-- Name: ix_ops_audit_logs_actor_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_ops_audit_logs_actor_created ON public.ops_audit_logs USING btree (actor_email, created_at DESC);


--
-- Name: ix_payment_attempts_checkout_attempted; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_payment_attempts_checkout_attempted ON public.payment_attempts USING btree (checkout_session_id, attempted_at DESC);


--
-- Name: ix_payment_transactions_provider_payment_id; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_payment_transactions_provider_payment_id ON public.payment_transactions USING btree (provider_payment_id);


--
-- Name: ix_payment_transactions_tenant_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_payment_transactions_tenant_created ON public.payment_transactions USING btree (tenant_id, created_at DESC);


--
-- Name: ix_payouts_reseller_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_payouts_reseller_created ON public.payouts USING btree (reseller_id, created_at DESC);


--
-- Name: ix_plan_feature_flags_plan_flag; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_plan_feature_flags_plan_flag ON public.plan_feature_flags USING btree (subscription_plan_id, feature_flag_id);


--
-- Name: ix_plan_prices_plan_period_currency; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_plan_prices_plan_period_currency ON public.plan_prices USING btree (subscription_plan_id, billing_period, currency);


--
-- Name: ix_portal_sessions_access_token_hash; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_portal_sessions_access_token_hash ON public.portal_sessions USING btree (access_token_hash);


--
-- Name: ix_portal_sessions_customer_revoked; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_portal_sessions_customer_revoked ON public.portal_sessions USING btree (customer_account_id, revoked_at);


--
-- Name: ix_portal_sessions_refresh_token_hash; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_portal_sessions_refresh_token_hash ON public.portal_sessions USING btree (refresh_token_hash);


--
-- Name: ix_processed_events_tenant_device_processed; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_processed_events_tenant_device_processed ON public.processed_events USING btree (tenant_id, device_id, processed_at);


--
-- Name: ix_product_variants_tenant_barcode; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_product_variants_tenant_barcode ON public.product_variants USING btree (tenant_id, barcode);


--
-- Name: ix_product_variants_tenant_product; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_product_variants_tenant_product ON public.product_variants USING btree (tenant_id, product_id);


--
-- Name: ix_production_orders_tenant_product_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_production_orders_tenant_product_created ON public.production_orders USING btree (tenant_id, finished_product_id, created_at);


--
-- Name: ix_production_orders_tenant_status_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_production_orders_tenant_status_created ON public.production_orders USING btree (tenant_id, status, created_at);


--
-- Name: ix_products_tenant_barcode; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_products_tenant_barcode ON public.products USING btree (tenant_id, barcode);


--
-- Name: ix_products_tenant_category; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_products_tenant_category ON public.products USING btree (tenant_id, category_id);


--
-- Name: ix_purchase_order_lines_order_product; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_purchase_order_lines_order_product ON public.purchase_order_lines USING btree (purchase_order_id, product_id);


--
-- Name: ix_purchase_orders_tenant_status_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_purchase_orders_tenant_status_created ON public.purchase_orders USING btree (tenant_id, status, created_at);


--
-- Name: ix_purchase_orders_tenant_supplier_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_purchase_orders_tenant_supplier_created ON public.purchase_orders USING btree (tenant_id, supplier_id, created_at);


--
-- Name: ix_rate_limit_policies_code; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_rate_limit_policies_code ON public.rate_limit_policies USING btree (policy_code);


--
-- Name: ix_reseller_accounts_email; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_reseller_accounts_email ON public.reseller_accounts USING btree (email);


--
-- Name: ix_reseller_codes_code; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_reseller_codes_code ON public.reseller_codes USING btree (code);


--
-- Name: ix_reseller_commission_events_account_status_event; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_reseller_commission_events_account_status_event ON public.reseller_commission_events USING btree (reseller_account_id, status, event_at DESC);


--
-- Name: ix_reseller_customer_links_account_tenant; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_reseller_customer_links_account_tenant ON public.reseller_customer_links USING btree (reseller_account_id, tenant_id);


--
-- Name: ix_reseller_referrals_checkout_code; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_reseller_referrals_checkout_code ON public.reseller_referrals USING btree (checkout_session_id, referral_code);


--
-- Name: ix_restore_validation_runs_env_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_restore_validation_runs_env_created ON public.restore_validation_runs USING btree (environment, created_at DESC);


--
-- Name: ix_retention_policies_code; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_retention_policies_code ON public.retention_policies USING btree (policy_code);


--
-- Name: ix_rollout_records_env_channel_target; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_rollout_records_env_channel_target ON public.rollout_records USING btree (environment, channel, target_type, target_version);


--
-- Name: ix_runbook_records_code; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_runbook_records_code ON public.runbook_records USING btree (code);


--
-- Name: ix_sales_tenant_branch_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_sales_tenant_branch_created ON public.sales USING btree (tenant_id, branch_id, created_at);


--
-- Name: ix_sales_tenant_receipt; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_sales_tenant_receipt ON public.sales USING btree (tenant_id, receipt_no);


--
-- Name: ix_secret_references_env_name; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_secret_references_env_name ON public.secret_references USING btree (environment, secret_name);


--
-- Name: ix_security_events_env_type_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_security_events_env_type_created ON public.security_events USING btree (environment, event_type, created_at DESC);


--
-- Name: ix_service_versions_environment_service; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_service_versions_environment_service ON public.service_versions USING btree (environment, service_name);


--
-- Name: ix_slo_definitions_env_service_code; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_slo_definitions_env_service_code ON public.slo_definitions USING btree (environment, service_name, slo_code);


--
-- Name: ix_stock_by_warehouse_tenant_product_warehouse; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_stock_by_warehouse_tenant_product_warehouse ON public.stock_by_warehouse USING btree (tenant_id, product_id, warehouse_id);


--
-- Name: ix_stock_by_warehouse_tenant_warehouse_product; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_stock_by_warehouse_tenant_warehouse_product ON public.stock_by_warehouse USING btree (tenant_id, warehouse_id, product_id);


--
-- Name: ix_stock_moves_tenant_branch_product_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_stock_moves_tenant_branch_product_created ON public.stock_moves USING btree (tenant_id, branch_id, product_id, created_at);


--
-- Name: ix_stock_moves_tenant_warehouse_product_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_stock_moves_tenant_warehouse_product_created ON public.stock_moves USING btree (tenant_id, warehouse_id, product_id, created_at);


--
-- Name: ix_sub_payments_payment_ref; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_sub_payments_payment_ref ON public.subscription_payments USING btree (payment_ref);


--
-- Name: ix_sub_payments_tenant_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_sub_payments_tenant_created ON public.subscription_payments USING btree (tenant_id, created_at DESC);


--
-- Name: ix_subscription_plans_code; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_subscription_plans_code ON public.subscription_plans USING btree (code);


--
-- Name: ix_subscription_plans_public_active; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_subscription_plans_public_active ON public.subscription_plans USING btree (is_public, is_active);


--
-- Name: ix_subscriptions_tenant_status_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_subscriptions_tenant_status_created ON public.subscriptions USING btree (tenant_id, status, created_at DESC);


--
-- Name: ix_suppliers_tenant_name; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_suppliers_tenant_name ON public.suppliers USING btree (tenant_id, name);


--
-- Name: ix_support_access_sessions_user_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_support_access_sessions_user_created ON public.support_access_sessions USING btree (internal_user_id, created_at DESC);


--
-- Name: ix_support_case_links_case_entity; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_support_case_links_case_entity ON public.support_case_links USING btree (support_case_id, entity_type, entity_id);


--
-- Name: ix_support_case_messages_case_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_support_case_messages_case_created ON public.support_case_messages USING btree (support_case_id, created_at);


--
-- Name: ix_support_case_notes_case_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_support_case_notes_case_created ON public.support_case_notes USING btree (support_case_id, created_at);


--
-- Name: ix_support_cases_reseller_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_support_cases_reseller_created ON public.support_cases USING btree (reseller_account_id, created_at DESC);


--
-- Name: ix_support_cases_status_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_support_cases_status_created ON public.support_cases USING btree (status, created_at DESC);


--
-- Name: ix_support_cases_tenant_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_support_cases_tenant_created ON public.support_cases USING btree (tenant_id, created_at DESC);


--
-- Name: ix_tenant_users_tenant_customer; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_tenant_users_tenant_customer ON public.tenant_users USING btree (tenant_id, customer_account_id);


--
-- Name: ix_tenant_users_tenant_role; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_tenant_users_tenant_role ON public.tenant_users USING btree (tenant_id, role_code);


--
-- Name: ix_tenants_billing_email; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_tenants_billing_email ON public.tenants USING btree (billing_email);


--
-- Name: ix_tenants_tenant_code; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_tenants_tenant_code ON public.tenants USING btree (tenant_code);


--
-- Name: ix_users_tenant_branch; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_users_tenant_branch ON public.users USING btree (tenant_id, branch_id);


--
-- Name: ix_warehouse_transfer_lines_transfer_product; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_warehouse_transfer_lines_transfer_product ON public.warehouse_transfer_lines USING btree (transfer_id, product_id);


--
-- Name: ix_warehouse_transfers_tenant_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_warehouse_transfers_tenant_created ON public.warehouse_transfers USING btree (tenant_id, created_at);


--
-- Name: ix_warehouse_transfers_tenant_status_created; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE INDEX ix_warehouse_transfers_tenant_status_created ON public.warehouse_transfers USING btree (tenant_id, status, created_at);


--
-- Name: ix_warehouses_tenant_name; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ix_warehouses_tenant_name ON public.warehouses USING btree (tenant_id, name);


--
-- Name: ux_accounting_export_items_source; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ux_accounting_export_items_source ON public.accounting_export_items USING btree (tenant_id, source_type, source_id);


--
-- Name: ux_bom_line_component_unique; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ux_bom_line_component_unique ON public.bill_of_material_lines USING btree (bom_id, component_product_id);


--
-- Name: ux_bom_single_active_per_product; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ux_bom_single_active_per_product ON public.bill_of_materials USING btree (tenant_id, product_id) WHERE (is_active = true);


--
-- Name: ux_bom_tenant_product_version; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ux_bom_tenant_product_version ON public.bill_of_materials USING btree (tenant_id, product_id, version);


--
-- Name: ux_branches_tenant_name; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ux_branches_tenant_name ON public.branches USING btree (tenant_id, name);


--
-- Name: ux_customer_account_entries_idempotency; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ux_customer_account_entries_idempotency ON public.customer_account_entries USING btree (tenant_id, customer_id, type, ref_type, ref_id);


--
-- Name: ux_customer_current_accounts_tenant_customer; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ux_customer_current_accounts_tenant_customer ON public.customer_current_accounts USING btree (tenant_id, customer_id);


--
-- Name: ux_device_activations_tenant_device; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ux_device_activations_tenant_device ON public.device_activations USING btree (tenant_id, device_id);


--
-- Name: ux_payment_webhooks_provider_event; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ux_payment_webhooks_provider_event ON public.payment_webhooks USING btree (provider, event_id);


--
-- Name: ux_products_tenant_barcode_unique; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ux_products_tenant_barcode_unique ON public.products USING btree (tenant_id, barcode) WHERE ((barcode IS NOT NULL) AND (btrim((barcode)::text) <> ''::text));


--
-- Name: ux_products_tenant_sku; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ux_products_tenant_sku ON public.products USING btree (tenant_id, sku);


--
-- Name: ux_reseller_customers_reseller_tenant; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ux_reseller_customers_reseller_tenant ON public.reseller_customers USING btree (reseller_id, tenant_id);


--
-- Name: ux_roles_tenant_name; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ux_roles_tenant_name ON public.roles USING btree (tenant_id, name);


--
-- Name: ux_users_tenant_email; Type: INDEX; Schema: public; Owner: loomapos
--

CREATE UNIQUE INDEX ux_users_tenant_email ON public.users USING btree (tenant_id, email);


--
-- Name: jobparameter jobparameter_jobid_fkey; Type: FK CONSTRAINT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.jobparameter
    ADD CONSTRAINT jobparameter_jobid_fkey FOREIGN KEY (jobid) REFERENCES hangfire.job(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: state state_jobid_fkey; Type: FK CONSTRAINT; Schema: hangfire; Owner: loomapos
--

ALTER TABLE ONLY hangfire.state
    ADD CONSTRAINT state_jobid_fkey FOREIGN KEY (jobid) REFERENCES hangfire.job(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: abuse_flags fk_abuse_flags_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.abuse_flags
    ADD CONSTRAINT fk_abuse_flags_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: accounting_export_items fk_accounting_export_items_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.accounting_export_items
    ADD CONSTRAINT fk_accounting_export_items_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: activation_events fk_activation_events_device; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.activation_events
    ADD CONSTRAINT fk_activation_events_device FOREIGN KEY (device_activation_id) REFERENCES public.device_activations(id) ON DELETE CASCADE;


--
-- Name: activation_events fk_activation_events_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.activation_events
    ADD CONSTRAINT fk_activation_events_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: admin_action_approvals fk_admin_action_approvals_request; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.admin_action_approvals
    ADD CONSTRAINT fk_admin_action_approvals_request FOREIGN KEY (admin_action_request_id) REFERENCES public.admin_action_requests(id) ON DELETE CASCADE;


--
-- Name: admin_action_approvals fk_admin_action_approvals_user; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.admin_action_approvals
    ADD CONSTRAINT fk_admin_action_approvals_user FOREIGN KEY (approved_by_internal_user_id) REFERENCES public.internal_users(id) ON DELETE CASCADE;


--
-- Name: admin_action_requests fk_admin_action_requests_user; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.admin_action_requests
    ADD CONSTRAINT fk_admin_action_requests_user FOREIGN KEY (requested_by_internal_user_id) REFERENCES public.internal_users(id) ON DELETE CASCADE;


--
-- Name: alert_events fk_alert_events_rule; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.alert_events
    ADD CONSTRAINT fk_alert_events_rule FOREIGN KEY (alert_rule_id) REFERENCES public.alert_rules(id) ON DELETE SET NULL;


--
-- Name: analytics_report_schedules fk_analytics_report_schedules_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.analytics_report_schedules
    ADD CONSTRAINT fk_analytics_report_schedules_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: analytics_saved_views fk_analytics_saved_views_customer; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.analytics_saved_views
    ADD CONSTRAINT fk_analytics_saved_views_customer FOREIGN KEY (customer_account_id) REFERENCES public.customer_accounts(id) ON DELETE SET NULL;


--
-- Name: analytics_saved_views fk_analytics_saved_views_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.analytics_saved_views
    ADD CONSTRAINT fk_analytics_saved_views_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: billing_profiles fk_billing_profiles_customer; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.billing_profiles
    ADD CONSTRAINT fk_billing_profiles_customer FOREIGN KEY (customer_account_id) REFERENCES public.customer_accounts(id) ON DELETE SET NULL;


--
-- Name: billing_profiles fk_billing_profiles_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.billing_profiles
    ADD CONSTRAINT fk_billing_profiles_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: bill_of_material_lines fk_bom_line_bom; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.bill_of_material_lines
    ADD CONSTRAINT fk_bom_line_bom FOREIGN KEY (bom_id) REFERENCES public.bill_of_materials(id) ON DELETE CASCADE;


--
-- Name: bill_of_material_lines fk_bom_line_component_product; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.bill_of_material_lines
    ADD CONSTRAINT fk_bom_line_component_product FOREIGN KEY (component_product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: bill_of_materials fk_bom_product; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.bill_of_materials
    ADD CONSTRAINT fk_bom_product FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: bill_of_materials fk_bom_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.bill_of_materials
    ADD CONSTRAINT fk_bom_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: branches fk_branches_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT fk_branches_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: checkout_sessions fk_checkout_sessions_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.checkout_sessions
    ADD CONSTRAINT fk_checkout_sessions_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: commissions fk_commissions_invoice; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.commissions
    ADD CONSTRAINT fk_commissions_invoice FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: commissions fk_commissions_reseller; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.commissions
    ADD CONSTRAINT fk_commissions_reseller FOREIGN KEY (reseller_id) REFERENCES public.reseller_accounts(id) ON DELETE CASCADE;


--
-- Name: commissions fk_commissions_subscription; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.commissions
    ADD CONSTRAINT fk_commissions_subscription FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON DELETE CASCADE;


--
-- Name: commissions fk_commissions_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.commissions
    ADD CONSTRAINT fk_commissions_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: contact_ledger fk_contact_ledger_contact; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.contact_ledger
    ADD CONSTRAINT fk_contact_ledger_contact FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON DELETE CASCADE;


--
-- Name: customer_account_entries fk_customer_account_entries_customer; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.customer_account_entries
    ADD CONSTRAINT fk_customer_account_entries_customer FOREIGN KEY (customer_id) REFERENCES public.contacts(id) ON DELETE CASCADE;


--
-- Name: customer_account_entries fk_customer_account_entries_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.customer_account_entries
    ADD CONSTRAINT fk_customer_account_entries_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: customer_current_accounts fk_customer_current_accounts_customer; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.customer_current_accounts
    ADD CONSTRAINT fk_customer_current_accounts_customer FOREIGN KEY (customer_id) REFERENCES public.contacts(id) ON DELETE CASCADE;


--
-- Name: customer_current_accounts fk_customer_current_accounts_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.customer_current_accounts
    ADD CONSTRAINT fk_customer_current_accounts_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: device_activations fk_device_activations_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.device_activations
    ADD CONSTRAINT fk_device_activations_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: download_accesses fk_download_accesses_asset; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.download_accesses
    ADD CONSTRAINT fk_download_accesses_asset FOREIGN KEY (downloadable_asset_id) REFERENCES public.downloadable_assets(id) ON DELETE CASCADE;


--
-- Name: download_accesses fk_download_accesses_license; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.download_accesses
    ADD CONSTRAINT fk_download_accesses_license FOREIGN KEY (license_id) REFERENCES public.licenses(id) ON DELETE SET NULL;


--
-- Name: download_accesses fk_download_accesses_subscription; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.download_accesses
    ADD CONSTRAINT fk_download_accesses_subscription FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON DELETE SET NULL;


--
-- Name: download_accesses fk_download_accesses_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.download_accesses
    ADD CONSTRAINT fk_download_accesses_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: downloadable_assets fk_downloadable_assets_release; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.downloadable_assets
    ADD CONSTRAINT fk_downloadable_assets_release FOREIGN KEY (app_release_id) REFERENCES public.app_releases(id) ON DELETE CASCADE;


--
-- Name: email_notifications fk_email_notifications_customer; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.email_notifications
    ADD CONSTRAINT fk_email_notifications_customer FOREIGN KEY (customer_account_id) REFERENCES public.customer_accounts(id) ON DELETE SET NULL;


--
-- Name: email_notifications fk_email_notifications_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.email_notifications
    ADD CONSTRAINT fk_email_notifications_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: incident_timeline_events fk_incident_timeline_events_incident; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.incident_timeline_events
    ADD CONSTRAINT fk_incident_timeline_events_incident FOREIGN KEY (incident_record_id) REFERENCES public.incident_records(id) ON DELETE CASCADE;


--
-- Name: internal_sessions fk_internal_sessions_user; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.internal_sessions
    ADD CONSTRAINT fk_internal_sessions_user FOREIGN KEY (internal_user_id) REFERENCES public.internal_users(id) ON DELETE CASCADE;


--
-- Name: internal_user_roles fk_internal_user_roles_user; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.internal_user_roles
    ADD CONSTRAINT fk_internal_user_roles_user FOREIGN KEY (internal_user_id) REFERENCES public.internal_users(id) ON DELETE CASCADE;


--
-- Name: invoice_lines fk_invoice_lines_invoice; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.invoice_lines
    ADD CONSTRAINT fk_invoice_lines_invoice FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_lines fk_invoice_lines_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.invoice_lines
    ADD CONSTRAINT fk_invoice_lines_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: invoices fk_invoices_subscription; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT fk_invoices_subscription FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON DELETE CASCADE;


--
-- Name: invoices fk_invoices_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT fk_invoices_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: license_events fk_license_events_license; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.license_events
    ADD CONSTRAINT fk_license_events_license FOREIGN KEY (license_id) REFERENCES public.licenses(id) ON DELETE CASCADE;


--
-- Name: license_events fk_license_events_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.license_events
    ADD CONSTRAINT fk_license_events_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: licenses fk_licenses_subscription; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.licenses
    ADD CONSTRAINT fk_licenses_subscription FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON DELETE CASCADE;


--
-- Name: licenses fk_licenses_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.licenses
    ADD CONSTRAINT fk_licenses_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: payment_attempts fk_payment_attempts_checkout; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.payment_attempts
    ADD CONSTRAINT fk_payment_attempts_checkout FOREIGN KEY (checkout_session_id) REFERENCES public.checkout_sessions(id) ON DELETE CASCADE;


--
-- Name: payment_attempts fk_payment_attempts_transaction; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.payment_attempts
    ADD CONSTRAINT fk_payment_attempts_transaction FOREIGN KEY (payment_transaction_id) REFERENCES public.payment_transactions(id) ON DELETE SET NULL;


--
-- Name: payment_transactions fk_payment_transactions_checkout; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT fk_payment_transactions_checkout FOREIGN KEY (checkout_session_id) REFERENCES public.checkout_sessions(id) ON DELETE SET NULL;


--
-- Name: payment_transactions fk_payment_transactions_invoice; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT fk_payment_transactions_invoice FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE SET NULL;


--
-- Name: payment_transactions fk_payment_transactions_subscription; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT fk_payment_transactions_subscription FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON DELETE SET NULL;


--
-- Name: payment_transactions fk_payment_transactions_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT fk_payment_transactions_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: payments fk_payments_sale; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT fk_payments_sale FOREIGN KEY (sale_id) REFERENCES public.sales(id) ON DELETE CASCADE;


--
-- Name: payouts fk_payouts_reseller; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.payouts
    ADD CONSTRAINT fk_payouts_reseller FOREIGN KEY (reseller_id) REFERENCES public.reseller_accounts(id) ON DELETE CASCADE;


--
-- Name: plan_feature_flags fk_plan_feature_flags_flag; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.plan_feature_flags
    ADD CONSTRAINT fk_plan_feature_flags_flag FOREIGN KEY (feature_flag_id) REFERENCES public.feature_flags(id) ON DELETE CASCADE;


--
-- Name: plan_feature_flags fk_plan_feature_flags_plan; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.plan_feature_flags
    ADD CONSTRAINT fk_plan_feature_flags_plan FOREIGN KEY (subscription_plan_id) REFERENCES public.subscription_plans(id) ON DELETE CASCADE;


--
-- Name: plan_prices fk_plan_prices_plan; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.plan_prices
    ADD CONSTRAINT fk_plan_prices_plan FOREIGN KEY (subscription_plan_id) REFERENCES public.subscription_plans(id) ON DELETE CASCADE;


--
-- Name: portal_sessions fk_portal_sessions_customer; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.portal_sessions
    ADD CONSTRAINT fk_portal_sessions_customer FOREIGN KEY (customer_account_id) REFERENCES public.customer_accounts(id) ON DELETE CASCADE;


--
-- Name: portal_sessions fk_portal_sessions_reseller; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.portal_sessions
    ADD CONSTRAINT fk_portal_sessions_reseller FOREIGN KEY (reseller_account_id) REFERENCES public.reseller_accounts(id) ON DELETE CASCADE;


--
-- Name: portal_sessions fk_portal_sessions_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.portal_sessions
    ADD CONSTRAINT fk_portal_sessions_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: product_barcodes fk_product_barcodes_product; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.product_barcodes
    ADD CONSTRAINT fk_product_barcodes_product FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_variants fk_product_variants_product; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT fk_product_variants_product FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: product_variants fk_product_variants_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT fk_product_variants_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: production_orders fk_production_order_bom; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.production_orders
    ADD CONSTRAINT fk_production_order_bom FOREIGN KEY (bom_id) REFERENCES public.bill_of_materials(id) ON DELETE SET NULL;


--
-- Name: production_orders fk_production_order_finished_product; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.production_orders
    ADD CONSTRAINT fk_production_order_finished_product FOREIGN KEY (finished_product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: production_orders fk_production_order_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.production_orders
    ADD CONSTRAINT fk_production_order_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: products fk_products_category; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fk_products_category FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: purchase_order_lines fk_purchase_order_lines_order; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT fk_purchase_order_lines_order FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id) ON DELETE CASCADE;


--
-- Name: purchase_order_lines fk_purchase_order_lines_product; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT fk_purchase_order_lines_product FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: purchase_orders fk_purchase_orders_supplier; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT fk_purchase_orders_supplier FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE RESTRICT;


--
-- Name: purchase_orders fk_purchase_orders_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT fk_purchase_orders_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: purchase_orders fk_purchase_orders_warehouse; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT fk_purchase_orders_warehouse FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE RESTRICT;


--
-- Name: reseller_codes fk_reseller_codes_account; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_codes
    ADD CONSTRAINT fk_reseller_codes_account FOREIGN KEY (reseller_account_id) REFERENCES public.reseller_accounts(id) ON DELETE CASCADE;


--
-- Name: reseller_commission_events fk_reseller_commission_events_account; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_commission_events
    ADD CONSTRAINT fk_reseller_commission_events_account FOREIGN KEY (reseller_account_id) REFERENCES public.reseller_accounts(id) ON DELETE CASCADE;


--
-- Name: reseller_commission_events fk_reseller_commission_events_invoice; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_commission_events
    ADD CONSTRAINT fk_reseller_commission_events_invoice FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE SET NULL;


--
-- Name: reseller_commission_events fk_reseller_commission_events_subscription; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_commission_events
    ADD CONSTRAINT fk_reseller_commission_events_subscription FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON DELETE SET NULL;


--
-- Name: reseller_commission_events fk_reseller_commission_events_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_commission_events
    ADD CONSTRAINT fk_reseller_commission_events_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: reseller_customer_links fk_reseller_customer_links_account; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_customer_links
    ADD CONSTRAINT fk_reseller_customer_links_account FOREIGN KEY (reseller_account_id) REFERENCES public.reseller_accounts(id) ON DELETE CASCADE;


--
-- Name: reseller_customer_links fk_reseller_customer_links_customer; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_customer_links
    ADD CONSTRAINT fk_reseller_customer_links_customer FOREIGN KEY (customer_account_id) REFERENCES public.customer_accounts(id) ON DELETE SET NULL;


--
-- Name: reseller_customer_links fk_reseller_customer_links_subscription; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_customer_links
    ADD CONSTRAINT fk_reseller_customer_links_subscription FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON DELETE SET NULL;


--
-- Name: reseller_customer_links fk_reseller_customer_links_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_customer_links
    ADD CONSTRAINT fk_reseller_customer_links_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: reseller_customers fk_reseller_customers_reseller; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_customers
    ADD CONSTRAINT fk_reseller_customers_reseller FOREIGN KEY (reseller_id) REFERENCES public.reseller_accounts(id) ON DELETE CASCADE;


--
-- Name: reseller_customers fk_reseller_customers_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_customers
    ADD CONSTRAINT fk_reseller_customers_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: reseller_referrals fk_reseller_referrals_account; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_referrals
    ADD CONSTRAINT fk_reseller_referrals_account FOREIGN KEY (reseller_account_id) REFERENCES public.reseller_accounts(id) ON DELETE CASCADE;


--
-- Name: reseller_referrals fk_reseller_referrals_checkout; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_referrals
    ADD CONSTRAINT fk_reseller_referrals_checkout FOREIGN KEY (checkout_session_id) REFERENCES public.checkout_sessions(id) ON DELETE CASCADE;


--
-- Name: reseller_referrals fk_reseller_referrals_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.reseller_referrals
    ADD CONSTRAINT fk_reseller_referrals_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: restore_validation_runs fk_restore_validation_runs_backup; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.restore_validation_runs
    ADD CONSTRAINT fk_restore_validation_runs_backup FOREIGN KEY (backup_run_id) REFERENCES public.backup_runs(id) ON DELETE SET NULL;


--
-- Name: roles fk_roles_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT fk_roles_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: sale_lines fk_sale_lines_sale; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.sale_lines
    ADD CONSTRAINT fk_sale_lines_sale FOREIGN KEY (sale_id) REFERENCES public.sales(id) ON DELETE CASCADE;


--
-- Name: stock_by_warehouse fk_stock_by_warehouse_product; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.stock_by_warehouse
    ADD CONSTRAINT fk_stock_by_warehouse_product FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: stock_by_warehouse fk_stock_by_warehouse_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.stock_by_warehouse
    ADD CONSTRAINT fk_stock_by_warehouse_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: stock_by_warehouse fk_stock_by_warehouse_warehouse; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.stock_by_warehouse
    ADD CONSTRAINT fk_stock_by_warehouse_warehouse FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE CASCADE;


--
-- Name: stock_moves fk_stock_moves_warehouse; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.stock_moves
    ADD CONSTRAINT fk_stock_moves_warehouse FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(id) ON DELETE SET NULL;


--
-- Name: subscription_payments fk_sub_payments_invoice; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT fk_sub_payments_invoice FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: subscription_payments fk_sub_payments_subscription; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT fk_sub_payments_subscription FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON DELETE CASCADE;


--
-- Name: subscription_payments fk_sub_payments_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.subscription_payments
    ADD CONSTRAINT fk_sub_payments_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: subscriptions fk_subscriptions_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT fk_subscriptions_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: suppliers fk_suppliers_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT fk_suppliers_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: support_access_sessions fk_support_access_sessions_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.support_access_sessions
    ADD CONSTRAINT fk_support_access_sessions_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: support_access_sessions fk_support_access_sessions_user; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.support_access_sessions
    ADD CONSTRAINT fk_support_access_sessions_user FOREIGN KEY (internal_user_id) REFERENCES public.internal_users(id) ON DELETE CASCADE;


--
-- Name: support_case_links fk_support_case_links_case; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.support_case_links
    ADD CONSTRAINT fk_support_case_links_case FOREIGN KEY (support_case_id) REFERENCES public.support_cases(id) ON DELETE CASCADE;


--
-- Name: support_case_messages fk_support_case_messages_case; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.support_case_messages
    ADD CONSTRAINT fk_support_case_messages_case FOREIGN KEY (support_case_id) REFERENCES public.support_cases(id) ON DELETE CASCADE;


--
-- Name: support_case_messages fk_support_case_messages_customer; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.support_case_messages
    ADD CONSTRAINT fk_support_case_messages_customer FOREIGN KEY (author_customer_account_id) REFERENCES public.customer_accounts(id) ON DELETE SET NULL;


--
-- Name: support_case_messages fk_support_case_messages_internal_user; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.support_case_messages
    ADD CONSTRAINT fk_support_case_messages_internal_user FOREIGN KEY (author_internal_user_id) REFERENCES public.internal_users(id) ON DELETE SET NULL;


--
-- Name: support_case_notes fk_support_case_notes_case; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.support_case_notes
    ADD CONSTRAINT fk_support_case_notes_case FOREIGN KEY (support_case_id) REFERENCES public.support_cases(id) ON DELETE CASCADE;


--
-- Name: support_case_notes fk_support_case_notes_internal_user; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.support_case_notes
    ADD CONSTRAINT fk_support_case_notes_internal_user FOREIGN KEY (internal_user_id) REFERENCES public.internal_users(id) ON DELETE CASCADE;


--
-- Name: support_cases fk_support_cases_customer; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.support_cases
    ADD CONSTRAINT fk_support_cases_customer FOREIGN KEY (customer_account_id) REFERENCES public.customer_accounts(id) ON DELETE SET NULL;


--
-- Name: support_cases fk_support_cases_reseller; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.support_cases
    ADD CONSTRAINT fk_support_cases_reseller FOREIGN KEY (reseller_account_id) REFERENCES public.reseller_accounts(id) ON DELETE SET NULL;


--
-- Name: support_cases fk_support_cases_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.support_cases
    ADD CONSTRAINT fk_support_cases_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: tenant_users fk_tenant_users_customer; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.tenant_users
    ADD CONSTRAINT fk_tenant_users_customer FOREIGN KEY (customer_account_id) REFERENCES public.customer_accounts(id) ON DELETE CASCADE;


--
-- Name: tenant_users fk_tenant_users_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.tenant_users
    ADD CONSTRAINT fk_tenant_users_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: user_roles fk_user_roles_role; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT fk_user_roles_role FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles fk_user_roles_user; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT fk_user_roles_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users fk_users_branch; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_branch FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: users fk_users_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: warehouse_transfer_lines fk_warehouse_transfer_lines_product; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.warehouse_transfer_lines
    ADD CONSTRAINT fk_warehouse_transfer_lines_product FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: warehouse_transfer_lines fk_warehouse_transfer_lines_transfer; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.warehouse_transfer_lines
    ADD CONSTRAINT fk_warehouse_transfer_lines_transfer FOREIGN KEY (transfer_id) REFERENCES public.warehouse_transfers(id) ON DELETE CASCADE;


--
-- Name: warehouse_transfers fk_warehouse_transfers_from_warehouse; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.warehouse_transfers
    ADD CONSTRAINT fk_warehouse_transfers_from_warehouse FOREIGN KEY (from_warehouse_id) REFERENCES public.warehouses(id) ON DELETE RESTRICT;


--
-- Name: warehouse_transfers fk_warehouse_transfers_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.warehouse_transfers
    ADD CONSTRAINT fk_warehouse_transfers_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: warehouse_transfers fk_warehouse_transfers_to_warehouse; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.warehouse_transfers
    ADD CONSTRAINT fk_warehouse_transfers_to_warehouse FOREIGN KEY (to_warehouse_id) REFERENCES public.warehouses(id) ON DELETE RESTRICT;


--
-- Name: warehouses fk_warehouses_tenant; Type: FK CONSTRAINT; Schema: public; Owner: loomapos
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT fk_warehouses_tenant FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 0MCQuMa9HPFSd3ZUHSe7fDt5B9RGCGlchRJ2OCVNkDZjLAsux8Kk7DvVd4PxMwa

